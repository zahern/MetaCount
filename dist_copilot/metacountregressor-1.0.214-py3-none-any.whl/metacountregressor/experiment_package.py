# =======================================================================
# experiment_package.py
# =======================================================================
#
# IMPORT ORDER (critical):
#   import main_hpc_lc_patch          # 1. patches main_hpc in place
#   from experiment_package import ExperimentBuilder   # 2. uses patched hpc
#
# ROLE SCHEME (complete)
# ──────────────────────
#   0  Excluded
#   1  Fixed (constant coefficient, same across sites)
#   2  Random Independent  (individual-level draws, independent)
#   3  Random Correlated   (individual-level draws, joint covariance)
#   4  Grouped             (group-level draws, shared within group)
#   5  Heterogeneity       (modifies means of random effects)
#   6  Zero Inflation      (enters class-prob of zero-excess)
#   7  Membership only     (enters class-membership eq. ONLY; role in outcome = 0)
#   8  Membership + fixed  (enters class-membership eq. AND outcome eq. as fixed)
#
# Roles 7 and 8 are ignored (treated as 0 / 1 respectively) when the
# latent-class code in the decision vector resolves to 1 class.
#
# DECISION VECTOR LAYOUT (dimension = 4·D + 2)
# ─────────────────────────────────────────────
#   [roles(D) | dist_codes(D) | dispersion_bit | lc_code | class_mask(D) | membership_mask(D)]
#
# MEMBERSHIP LOGIC
# ─────────────────
# Role 7 variable:
#   → appears in spec["membership_terms"] (the pooled list)
#   → does NOT appear in any outcome list
#   → membership_mask[i] controls which class(es) it enters (0=all, 1=class2, 2=class3, ...)
#
# Role 8 variable:
#   → appears in spec["membership_terms"] (class-prob equation)
#   → ALSO appears in spec["fixed_terms"]  (outcome equation)
#   → class_mask[i] controls which outcome class(es) it enters
#   → membership_mask[i] controls which membership class(es) it enters
#   → they are INDEPENDENT: a variable can be in Class 2 outcome but Class 3 membership
#
# =======================================================================

from __future__ import annotations

# ── Apply patches FIRST ─────────────────────────────────────────────────
try:
    from . import main_hpc_lc_patch as _patch  # type: ignore[attr-defined]
except ImportError:
    # Relative import can fail either because there is no parent package
    # (flat/top-level use) OR because the inner package does not ship
    # main_hpc_lc_patch and the name cannot be resolved. In both cases the
    # flat top-level module is the correct fallback; only raise the helpful
    # dependency error if that flat import also fails.
    try:
        import main_hpc_lc_patch as _patch   # patches main_hpc in-place
    except ImportError as exc:
        raise ImportError(
            "Unable to import the JAX backend for metacountregressor. "
            "Install package dependencies including 'jax' and 'jaxlib'."
        ) from exc


class FitResult(dict):
    """Dictionary-like wrapper for ``fit_manual_model()`` results.

    Behaves like a regular dict (you can access ``fit["result"]``,
    ``fit["summary"]``, etc.) but produces a formatted model-summary
    table when printed or displayed in a notebook.

    ``fit["result"]`` only carries the RAW (unnamed) parameter vector, so
    callers that needed named estimates used to re-parse the printed
    summary text.  The fit now also publishes the named table directly:

    ``fit["params"]`` / ``fit["bse"]`` / ``fit["tvalues"]`` / ``fit["pvalues"]``
        ``{parameter_name: float}`` mappings, in original (un-standardised)
        data units, covering every reported term (fixed, zi, cor_mean,
        chol, mean/sd, group_mean/group_sd, hetro, dispersion/sigma).
    ``fit["coef_table"]``
        The full ``Parameter/Estimate/Std.Err/z-value/p-value`` DataFrame.
    ``fit["coefficient_names"]``
        Ordered list of the parameter names.
    ``fit["variable_coefs"]``
        The same coefficients grouped by the RAW variable they belong to,
        so a caller can ask for "the coefficient of ``is_rsp``" without
        knowing which role (fixed / random / grouped / zi) the search
        happened to assign.  Each entry carries
        ``coef / se / p / name / role``.

    All of these are also reachable as attributes (``fit.params``).
    ``fit["summary"]`` keeps its original meaning (the fit-stats dict).

    Example
    -------
    >>> fit = builder.fit_manual_model(manual_spec=..., model='nb')
    >>> print(fit)          # shows formatted parameter table + fit stats
    >>> fit["summary"]      # still works as a dict
    >>> fit["params"]["is_rsp"]              # named estimate, no text parsing
    >>> fit["variable_coefs"]["is_rsp"]      # role-agnostic lookup
    """

    def __repr__(self) -> str:
        text = self.get("_summary_text")
        if text:
            return text
        return dict.__repr__(self)

    def __getattr__(self, name):
        # Only reached when normal attribute lookup fails, so methods/properties
        # keep priority.  Lets fit.params / fit.bse mirror fit["params"] etc.
        try:
            return self[name]
        except KeyError:
            raise AttributeError(name) from None


def _ph_families():
    """The proportional-hazards family set, or an empty set if unavailable."""
    try:
        from .survival_models import PH_FAMILIES
    except ImportError:
        try:
            from survival_models import PH_FAMILIES
        except ImportError:
            return set()
    return set(PH_FAMILIES)


def _survival_summary_df(result, objective, data, spec, param_index, family):
    """
    Named coefficient table for a survival/hazard fit.

    Deliberately does NOT reuse the count-oriented print_summary: that path
    applies PARTE shrinkage and delta-method transforms that are only
    defined for the count/linear parameterisations.  Here the parameters are
    already on the model's own scale (log-hazard for PH, latent normal for
    AFT), so the estimate is the parameter itself and the interesting
    column is exp(beta) -- a hazard ratio or a time ratio depending on the
    family.

    The returned DataFrame carries ``attrs["fit_stats"]`` so the caller can
    report LL/AIC/BIC from the same (expensive) objective evaluation.
    """
    from scipy import stats as _st

    params = np.asarray(
        result.params if hasattr(result, "params") else result.x, dtype=float
    )
    names = _param_names_for_spec(spec)
    if len(names) != len(params):
        names = [f"param_{i}" for i in range(len(params))]

    try:
        se = np.asarray(
            _hessian_se(params, objective), dtype=float
        )
    except Exception:
        se = np.full(len(params), np.nan)

    with np.errstate(divide="ignore", invalid="ignore"):
        z = np.where(se > 1e-12, params / np.where(se > 1e-12, se, 1.0), 0.0)
    p = 2.0 * (1.0 - _st.norm.cdf(np.abs(z)))

    ll = float(-objective(params))
    k = len(params)
    n = int(np.asarray(data["y"]).shape[0])
    stats_out = {
        "loglik": ll, "num_parm": k, "n_obs": n,
        "aic": 2 * k - 2 * ll, "bic": k * np.log(n) - 2 * ll,
        "family": family,
    }

    df_out = pd.DataFrame({
        "Parameter": names,
        "Estimate": params,
        "Std.Err": se,
        "z-value": z,
        "p-value": p,
    })
    ratio_col = "hazard_ratio" if family in _ph_families() else "time_ratio"
    with np.errstate(over="ignore"):
        df_out[ratio_col] = np.exp(params)
    # The trailing scale/shape parameter is not a covariate effect.
    for scale in ("sigma", "shape"):
        if scale in names:
            df_out.loc[names.index(scale), ratio_col] = np.nan

    df_out.attrs["fit_stats"] = stats_out
    return df_out


def _hessian_se(params, objective):
    """Standard errors from a numerical Hessian of the objective."""
    import jax as _jax

    hess = np.asarray(_jax.hessian(objective)(_jax.numpy.asarray(params)),
                      dtype=float)
    hess = np.where(np.isfinite(hess), hess, 0.0)
    try:
        eigvals, eigvecs = np.linalg.eigh(0.5 * (hess + hess.T))
    except np.linalg.LinAlgError:
        return np.full(len(params), np.nan)
    mx = float(np.max(np.abs(eigvals)))
    if not np.isfinite(mx) or mx <= 0:
        return np.full(len(params), np.nan)
    ridge = float(np.clip(mx * 1e-6, 1e-12, 1e-4))
    cov = (eigvecs * (1.0 / (eigvals + ridge))) @ eigvecs.T
    var = np.diag(cov)
    var = np.where(var > 0, var, np.nan)
    return np.sqrt(var)


def _param_names_for_spec(spec):
    """Parameter names in flat-vector order, matching build_base_index."""
    names = list(getattr(spec, "fixed_names", ()) or ())
    zi = list(getattr(spec, "zi_names", ()) or ())
    cor = list(getattr(spec, "random_cor_names", ()) or ())
    ind = list(getattr(spec, "random_ind_names", ()) or ())
    grp = list(getattr(spec, "grouped_names", ()) or ())
    het = list(getattr(spec, "hetro_names", ()) or ())
    names += [f"zi({n})" for n in zi]
    names += [f"cor_mean({n})" for n in cor]
    names += [f"chol({cor[i]},{cor[j]})"
              for i in range(len(cor)) for j in range(i + 1)]
    names += [f"mean({n})" for n in ind]
    names += [f"sd({n})" for n in ind]
    names += [f"group_mean({n})" for n in grp]
    names += [f"group_sd({n})" for n in grp]
    rand_total = len(cor) + len(ind)
    if rand_total and het:
        names += [f"hetro({r}|{z})" for r in (cor + ind) for z in het]
    if getattr(spec, "model", None) == "nb":
        names.append("dispersion")
    elif getattr(spec, "model", None) in {
        "lognormal", "gaussian", "tobit", "weibull", "loglogistic", "weibull_ph"
    }:
        names.append("sigma")
    return names


def _fit_stats_from(objective, result, data) -> dict:
    """Rebuild the fit-stats dict that print_summary() returns.

    Used when print_summary could not hand back the named DataFrame (so the
    stats were consumed by the summary call) -- keeps ``fit["summary"]``
    meaning what it always meant.
    """
    try:
        params = np.asarray(
            result.params if hasattr(result, "params") else result.x, dtype=float
        )
        ll = float(-objective(params))
        k = int(params.shape[0])
        n = int(data["y"].shape[0])
    except Exception:
        return {}
    return {
        "loglik": ll,
        "num_parm": k,
        "n_obs": n,
        "aic": 2 * k - 2 * ll,
        "bic": k * np.log(n) - 2 * ll,
    }


def _var_of_param(param_name: str) -> str:
    """Recover the raw variable name from a printed parameter name.

    ``mean(is_rsp)`` -> ``is_rsp``;  ``group_sd(dist_log)`` -> ``dist_log``;
    ``hetro(a|b)`` -> ``a``;  ``chol(a,b)`` -> ``a``;  ``speed_log`` -> ``speed_log``.
    Scalars (dispersion, sigma, __INTERCEPT__) map to themselves.
    """
    name = str(param_name).strip()
    if name.startswith("hetro(") and name.endswith(")"):
        return name[6:-1].split("|")[0].strip()
    if name.startswith("chol(") and name.endswith(")"):
        return name[5:-1].split(",")[0].strip()
    for prefix in ("cor_mean", "group_mean", "group_sd", "mean", "sd", "zi"):
        if name.startswith(prefix + "(") and name.endswith(")"):
            return name[len(prefix) + 1: -1].split(":")[0].strip()
    return name


def _variable_coefs(coefs: dict) -> dict:
    """Group the named coefficients by the raw variable they belong to.

    The search picks each variable's role, so a variable's reported name
    changes with it (``is_rsp`` when Fixed, ``mean(is_rsp)`` when
    Random-Independent, ``group_mean(x)`` when Grouped, ...).  Callers that
    want "the coefficient for is_rsp" should not have to know which role the
    search happened to choose.  Every entry carries its own
    ``coef/se/p/name/role`` so nothing is lost.
    """
    out = {}
    for pname in coefs.get("names", []):
        var = _var_of_param(pname)
        if pname == var:
            role = "fixed"
        elif pname.startswith("mean("):
            role = "random_independent"
        elif pname.startswith("sd("):
            role = "random_independent_sd"
        elif pname.startswith("cor_mean("):
            role = "random_correlated"
        elif pname.startswith("group_mean("):
            role = "grouped"
        elif pname.startswith("group_sd("):
            role = "grouped_sd"
        elif pname.startswith("zi("):
            role = "zero_inflated"
        elif pname.startswith("hetro("):
            role = "heterogeneity"
        else:
            role = "scalar"
        out.setdefault(var, {})[pname] = {
            "name": pname,
            "role": role,
            "coef": coefs["params"].get(pname),
            "se":   coefs["bse"].get(pname),
            "p":    coefs["pvalues"].get(pname),
        }
    return out


def _named_coefs_from_df(df) -> dict:
    """Split a printed-summary DataFrame into four name->float mappings.

    Tolerates the column spellings MCR has used over time (Parameter/index,
    Estimate/Estimate (PARTE)/Estimate_raw, Std.Err/StdErr_raw, z-value,
    p-value) and uses ``None`` for missing columns so callers can tell
    "not reported" from "zero".
    """
    if df is None or not hasattr(df, "columns"):
        return None

    def _pick(*candidates):
        for c in candidates:
            if c in df.columns:
                return c
        return None

    name_col = _pick("Parameter", "parameter", "name")
    if name_col is None:
        return None
    est_col = _pick("Estimate (PARTE)", "Estimate", "Estimate_raw")
    se_col  = _pick("Std.Err", "StdErr", "StdErr_raw", "Std. Error")
    z_col   = _pick("z-value", "zvalue", "t-value", "z")
    p_col   = _pick("p-value", "pvalue", "P>|z|")

    names = [str(n) for n in df[name_col]]

    def _series(col):
        # Key by the *parameter name*, never by the DataFrame index -- the
        # summary frame carries names in a "Parameter" column, so indexing by
        # position would hand back {'0': ..., '1': ...}.
        if col is None:
            return {}
        out = {}
        for nm, val in zip(names, df[col].tolist()):
            try:
                out[nm] = float(val)
            except (TypeError, ValueError):
                out[nm] = None
        return out

    return {
        "names":    names,
        "params":   _series(est_col),
        "bse":      _series(se_col),
        "tvalues":  _series(z_col),
        "pvalues":  _series(p_col),
    }


import numpy as np
import pandas as pd
import jax
import jax.numpy as jnp
import gc
import math
from dataclasses import replace
from functools import partial
import io
import warnings
from contextlib import redirect_stdout
try:
    from jaxopt import LBFGS
except ImportError as _jaxopt_exc:  # pragma: no cover - dependency guard
    raise ImportError(
        "metacountregressor requires the 'jaxopt' package.  "
        "Install the backend with:  pip install jax jaxlib jaxopt"
    ) from _jaxopt_exc
from scipy.optimize import (
    differential_evolution as scipy_differential_evolution,
    minimize as scipy_minimize,
)
from typing import Optional, Dict, List, Union, Any
from pathlib import Path

try:
    from ._jax_config import configure_jax, device_summary
except ImportError:  # flat import (script run from inside the package dir)
    from _jax_config import configure_jax, device_summary
configure_jax()

try:
    from .family_search import (
        CMFFamilySearchProblem,
        DurationSearchProblem,
        LinearSearchProblem,
        MultivariateSearchProblem,
        UnifiedCMFSearchProblem,
    )

    from .main_hpc import (
        StructureEvaluator,
        CountModel,
        build_base_index,
        build_datasets,
        generate_master_halton,
        generate_master_draws,
        fit_em,
        run_nsga,
        MultiStartSA,
        AdaptiveDE,
        DynamicHarmony,
        populate_allowed_roles,
        populate_allowed_distributions,
        decode_best_solution,
        decode_distribution,
        refit_and_print,
        save_run_summary_to_txt,
        check_identification,
        _is_oom_error,
        run_with_oom_recovery,
        _to_f64,
        random_parameter_convergence_diagnostics,
        random_parameter_identification_status,
    )
    from .main_hpc_lc_patch import (
        ModelSpec,
        build_param_index,
        build_model_from_manual_spec,
        mixed_model_loglik,
        mixed_model_loglik_reg,
        print_summary,
        _seed_classes_from_clusters,
        _tobit_ols_init,
    )
    from .genetic_algorithm import MultiStartGA
except ImportError:
    from family_search import (
        CMFFamilySearchProblem,
        DurationSearchProblem,
        LinearSearchProblem,
        MultivariateSearchProblem,
        UnifiedCMFSearchProblem,
    )

    from main_hpc import (
        StructureEvaluator,
        CountModel,
        build_base_index,
        build_datasets,
        generate_master_halton,
        generate_master_draws,
        fit_em,
        run_nsga,
        MultiStartSA,
        AdaptiveDE,
        DynamicHarmony,
        populate_allowed_roles,
        populate_allowed_distributions,
        decode_best_solution,
        decode_distribution,
        refit_and_print,
        save_run_summary_to_txt,
        check_identification,
        _is_oom_error,
        run_with_oom_recovery,
        _to_f64,
        random_parameter_convergence_diagnostics,
        random_parameter_identification_status,
    )
    from main_hpc_lc_patch import (
        ModelSpec,
        build_param_index,
        build_model_from_manual_spec,
        mixed_model_loglik,
        mixed_model_loglik_reg,
        print_summary,
        _seed_classes_from_clusters,
        _tobit_ols_init,
    )
    from genetic_algorithm import MultiStartGA
try:
    from .output_config import (
        SearchOutputConfig,
        save_search_checkpoint,
        save_search_result,
    )
except ImportError:
    from output_config import (
        SearchOutputConfig,
        save_search_checkpoint,
        save_search_result,
    )

__all__ = ["StructureEvaluatorLC", "ExperimentBuilder"]


# ═══════════════════════════════════════════════════════════════════════
# UPDATED ROLE_PROBS  (add slots for roles 7, 8, and 9)
# Applied directly to Solvers_METAJAX.ROLE_PROBS as well.
# ═══════════════════════════════════════════════════════════════════════

try:
    from . import Solvers_METAJAX as _solvers  # type: ignore[attr-defined]
except ImportError:
    import Solvers_METAJAX as _solvers

ROLE_PROBS = np.array([
    0.35,   # 0 – Excluded
    0.12,   # 1 – Fixed
    0.15,   # 2 – Random Independent
    0.14,   # 3 – Random Correlated
    0.00,   # 4 – Grouped
    0.05,   # 5 – Heterogeneity in means
    0.05,   # 6 – Zero Inflation
    0.05,   # 7 – Membership only
    0.05,   # 8 – Membership + fixed outcome
    0.04,   # 9 – Heterogeneity in variances
])
ROLE_PROBS = ROLE_PROBS / ROLE_PROBS.sum()
_solvers.ROLE_PROBS = ROLE_PROBS   # patch the module-level constant


ROLE_GUIDE = """
ROLE CODES
──────────
  0  Excluded          Variable not in the model.
  1  Fixed             Same coefficient across all sites/individuals.
  2  Random Indep.     Site-specific coefficient, independent draws.
  3  Random Corr.      Site-specific coefficient, jointly estimated covariance.
  4  Grouped           Coefficient shared within a group (e.g. road class).
  5  Heterogeneity     Variable that explains variation in random-param MEANS.
  6  Zero Inflation    Enters the zero-inflation probability equation.
  7  Membership only   Enters the CLASS-PROBABILITY equation only.
                       The variable shifts which latent class an individual
                       belongs to, but has no direct effect on the outcome.
                       Ignored (→ excluded) when latent_classes = 1.
  8  Membership+Fixed  Enters BOTH the class-probability equation AND the
                       outcome equation as a fixed covariate.
                       Each class gets its own outcome coefficient for this
                       variable (class-specific), AND the variable influences
                       class membership.
                       Collapsed to Fixed (role 1) when latent_classes = 1.
  9  Het. Variances    Variable that explains variation in random-param
                       VARIANCES (standard deviations). Modifies the scale
                       of random parameters (correlated, independent, grouped).

DISTRIBUTION CODES (roles 2, 3, 4)
────────────────────────────────────
  normal     Symmetric, unbounded.     Good default.
  lognormal  Positive-only.            Use when effect must be one-signed.
  triangular Bounded, symmetric.       Use for bounded/fractional variables.
  uniform    Flat.                     Rarely preferred.

LATENT CLASSES
──────────────
  1 class  Standard mixed model.
  2 classes Two sub-populations with separate parameter vectors.
  3+ classes Richer heterogeneity; BIC penalises extra params heavily.
  The GA selects the number of classes automatically via BIC.
"""


# ═══════════════════════════════════════════════════════════════════════
# StructureEvaluatorLC
# ═══════════════════════════════════════════════════════════════════════

class StructureEvaluatorLC(StructureEvaluator):
    """
    Extends StructureEvaluator with:
      • latent-class gene in the decision vector
      • roles 7 (membership-only) and 8 (membership + fixed outcome)
      • warm-started LC estimation in fitness()
    """

    def __init__(self, *args, max_latent_classes: int = 3, mutual_exclusion=None,
                 event_col: Optional[str] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.max_latent_classes = max(1, int(max_latent_classes))
        self.mutual_exclusion = mutual_exclusion or []
        # Survival/hazard: column holding the 0/1 right-censoring flag.
        # None for every other family, in which case data["event"] is all
        # ones and the count/duration likelihoods ignore it.
        self.event_col = event_col
        # Populated after every fitness() call; read by BanditGuidedSA
        # to avoid a second fit call for identifiability diagnostics.
        self._last_fit_cache: Optional[dict] = None
        # Progressive variable-ban: track how many times each variable
        # was NEWLY activated in a model that subsequently failed to
        # converge.  Only variables whose role changed from 0 → non-zero
        # relative to the last successful fit get counted — established
        # features are never blamed for failures they didn't cause.
        self._variable_failure_counts: Dict[str, int] = {}
        self._banned_variables: set[str] = set()
        self._last_successful_decision: Optional[np.ndarray] = None
        self._BAN_THRESHOLD = 10
        # Variables that MUST appear (role 0 forbidden).  Never banned.
        self._force_included_vars: set[str] = set()
        for var_name, allowed in self.allowed_roles.items():
            if 0 not in allowed:
                self._force_included_vars.add(var_name)
        # Human-readable reason why the last build_spec() call returned None
        # (invalid structure).  None when the last call succeeded.
        self.last_rejection_reason: Optional[str] = None

    # ── survival / hazard single-class fit ────────────────────────

    def _fit_survival_single(self, spec, data, family) -> tuple:
        """
        Fit one single-class survival structure and return ``(bic, params)``.

        Uses SurvivalModel (survival_mixed_model_loglik) instead of
        CountModel (mixed_model_loglik), because the survival likelihood
        needs the right-censoring indicator in ``data["event"]`` and the
        count likelihood has no notion of censoring.  BIC is computed on the
        training split exactly as the count path does, so hazard and count
        structures are ranked on the same footing.
        """
        from .survival_models import SurvivalModel
        from .survival_models import _ALL_SURVIVAL_FAMILIES  # noqa: F401
        try:
            if "event" not in data:
                raise ValueError(
                    "survival spec requires data['event']; pass event_col= to "
                    "ExperimentBuilder/build_search"
                )
            if family not in _ALL_SURVIVAL_FAMILIES:
                raise ValueError(f"unknown survival family {family!r}")
            # No zero-inflation and no latent classes on the survival path:
            # censoring is the only "structural zero" mechanism, and the LC
            # machinery is wired to mixed_model_loglik.
            spec = replace(spec, zero_inflated=False, latent_classes=1)
            sm = SurvivalModel(spec=spec, data=data, family=family,
                               maxiter=200, n_restarts=1)
            sm.fit()
            bic = sm.bic()
            if not np.isfinite(bic):
                raise ValueError("non-finite BIC from survival fit")
            return float(bic), np.asarray(sm.params)
        except Exception as exc:
            # The search treats any failure as an infeasible structure, so a
            # survival head that cannot be fitted simply loses that structure
            # rather than aborting the whole run.
            warnings.warn(
                f"survival fit failed for family={family!r}: {exc}",
                RuntimeWarning,
            )
            return 1e12, None

    # ── build_spec ──────────────────────────────────────────────────
    def build_spec(self, decision) -> Optional[dict]:
        """
        Decode a decision vector into a manual_spec dict.

        Decision layout (dimension = 4·D + 2 for LC, 2·D + 1 for single-class):
          decision[:D]       = role codes  (0–8)
          decision[D:2D]     = dist codes
          decision[2D]       = dispersion bit
          decision[2D+1]     = latent_class_code  (0→1 class, 1→2, …)
          decision[2D+2:3D+2]= class_mask  (per-class outcome variable assignments)
          decision[3D+2:4D+2]= membership_mask  (per-class membership assignments)
               0 = all classes   1 = class 2 only   2 = class 3 only  ...
        """
        D              = len(self.vars)
        roles          = decision[:D]
        dists          = decision[D : 2*D]
        dispersion_bit = int(decision[2*D])
        # LC gene only present when max_latent_classes > 1 (dim = 2*D+2).
        if self.max_latent_classes > 1 and len(decision) > 2*D + 1:
            lc_code = int(decision[2*D + 1])
        else:
            lc_code = 0
        # Per-class outcome masks
        if self.max_latent_classes > 1 and len(decision) > 2*D + 2:
            class_mask = [int(x) for x in decision[2*D + 2 : 3*D + 2]]
        else:
            class_mask = [0] * D
        # Per-class membership masks (NEW)
        if self.max_latent_classes > 1 and len(decision) > 3*D + 2:
            membership_mask = [int(x) for x in decision[3*D + 2 : 4*D + 2]]
        else:
            membership_mask = [0] * D

        use_nb          = dispersion_bit % 2 == 1
        latent_classes  = lc_code % self.max_latent_classes + 1
        # Effective LC count for STRUCTURAL decisions
        struct_lc       = max(latent_classes, self.max_latent_classes) if self.max_latent_classes > 1 else 1

        fixed      = []
        rdm_ind    = []
        rdm_cor    = []
        grouped    = []
        hetero     = []
        hetero_var = []
        zi         = []
        membership = []
        # Per-class variable lists (same categories, partitioned by class_mask)
        class_fixed   = [[] for _ in range(struct_lc)]
        class_rdm_ind = [[] for _ in range(struct_lc)]
        class_rdm_cor = [[] for _ in range(struct_lc)]
        # Per-class membership lists (NEW) — one per non-reference class
        class_membership = [[] for _ in range(struct_lc - 1)]

        # ── Mutual-exclusion check ────────────────────────────────────
        if self.mutual_exclusion:
            for group in self.mutual_exclusion:
                # Count how many variables in this group have role != 0
                active_in_group = 0
                for i, var in enumerate(self.vars):
                    if var in group and int(roles[i]) != 0:
                        active_in_group += 1
                        if active_in_group > 1:
                            self.last_rejection_reason = (
                                f"mutual exclusion violated: more than one of "
                                f"{list(group)} is active"
                            )
                            return None  # more than one active → invalid

        for i, var in enumerate(self.vars):
            role = int(roles[i])
            if role not in self.allowed_roles.get(var, [0]):
                self.last_rejection_reason = (
                    f"variable '{var}' assigned role {role}, but only "
                    f"{self.allowed_roles.get(var, [0])} allowed"
                )
                return None

            if var in self._unidentifiable and role != 0:
                self.last_rejection_reason = (
                    f"variable '{var}' was flagged unidentifiable "
                    f"({getattr(self, '_unid_reason', {}).get(var, 'collinearity')}) "
                    f"but assigned role {role}"
                )
                return None

            cm = class_mask[i] if struct_lc > 1 else 0
            mm = membership_mask[i] if struct_lc > 1 and len(membership_mask) > i else 0
            # Map class_mask to per-class inclusion (outcome equation)
            # 0 = all classes, 1 = class 1 only, 2 = class 2 only, ..., C = class C only
            in_class = []
            if struct_lc <= 1:
                in_class = [True]
            else:
                in_class = [
                    (cm == 0 or cm == c + 1) for c in range(struct_lc)
                ]

            if role == 0:
                pass  # excluded

            elif role == 1:
                fixed.append(var)
                for c, inc in enumerate(in_class):
                    if inc:
                        class_fixed[c].append(var)

            elif role == 2:
                dist = decode_distribution(
                    dists[i], self.allowed_distributions.get(var, ["normal"])
                )
                rdm_ind.append(f"{var}:{dist}")
                for c, inc in enumerate(in_class):
                    if inc:
                        class_rdm_ind[c].append(f"{var}:{dist}")

            elif role == 3:
                dist = decode_distribution(
                    dists[i], self.allowed_distributions.get(var, ["normal"])
                )
                rdm_cor.append(f"{var}:{dist}")
                for c, inc in enumerate(in_class):
                    if inc:
                        class_rdm_cor[c].append(f"{var}:{dist}")

            elif role == 4:
                dist = decode_distribution(
                    dists[i], self.allowed_distributions.get(var, ["normal"])
                )
                grouped.append(f"{var}:{dist}")

            elif role == 5:
                hetero.append(var)

            elif role == 6:
                zi.append(var)

            elif role == 7:
                if struct_lc > 1:
                    membership.append(var)
                    # Per-class membership: mm=0 → all non-reference classes; mm=c+1 → class c+1 only
                    for _c in range(struct_lc - 1):
                        if mm == 0 or mm == _c + 2:  # _c=0 → class 2, etc.
                            class_membership[_c].append(var)

            elif role == 8:
                if struct_lc > 1:
                    membership.append(var)
                    for _c in range(struct_lc - 1):
                        if mm == 0 or mm == _c + 2:
                            class_membership[_c].append(var)
                fixed.append(var)
                for c, inc in enumerate(in_class):
                    if inc:
                        class_fixed[c].append(var)

            elif role == 9:
                hetero_var.append(var)

        # ── Force at least one membership variable for LC models ──────
        # If no variable has been assigned a membership role (7 or 8),
        # the logit equation collapses to a constant intercept and classes
        # cannot be distinguished by covariate profiles.  Force-assign
        # one variable that is already in the outcome equation to also
        # enter the membership equation (effectively promoting it to role 8).
        if struct_lc > 1 and len(membership) == 0:
            eligible_mem = [
                v for v in self.vars
                if v in fixed
                and self.allowed_roles.get(v, [0]) != [0]
                and v not in self._unidentifiable
            ]
            if not eligible_mem:
                eligible_mem = [
                    v for v in self.vars
                    if self.allowed_roles.get(v, [0]) != [0]
                    and v not in self._unidentifiable
                ]
            if eligible_mem:
                seed = abs(hash(tuple(int(x) for x in decision))) % (2 ** 32)
                rng = np.random.default_rng(seed)
                mem_var = eligible_mem[int(rng.integers(len(eligible_mem)))]
                membership.append(mem_var)
                if mem_var not in fixed:
                    fixed.append(mem_var)
                    for c in range(struct_lc):
                        class_fixed[c].append(mem_var)

        # Single correlated var → demote to independent
        if len(rdm_cor) == 1:
            rdm_ind.extend(rdm_cor)
            rdm_cor = []
            for c in range(struct_lc):
                if len(class_rdm_cor[c]) == 1:
                    class_rdm_ind[c].extend(class_rdm_cor[c])
                    class_rdm_cor[c] = []

        # ── Force structural uniqueness across classes ────────────────
        # Every LC spec MUST differentiate the classes — identical
        # variable sets collapse the EM into a single-class solution.
        # When classes share all variables, deterministically move
        # variables so that each class has at least one unique variable.
        # The RNG is seeded from the decision vector so the same decision
        # always decodes to the same forced spec.
        if struct_lc > 1:
            class_var_sets = [
                frozenset(class_fixed[c])
                | frozenset(t.split(":")[0] for t in class_rdm_ind[c])
                | frozenset(t.split(":")[0] for t in class_rdm_cor[c])
                for c in range(struct_lc)
            ]
            all_vars = set().union(*class_var_sets) if class_var_sets else set()
            seed = abs(hash(tuple(int(x) for x in decision))) % (2 ** 32)
            rng = np.random.default_rng(seed)

            if class_var_sets[0] and all(s == class_var_sets[0] for s in class_var_sets[1:]):
                # All classes identical — force at least 2 differences if possible
                eligible = sorted(class_var_sets[0])
                n_diff = min(2, len(eligible))
                for d in range(n_diff):
                    avail = sorted(set(eligible) & class_var_sets[0])
                    if not avail:
                        break
                    var = avail[int(rng.integers(len(avail)))]
                    drop_class = (d + int(rng.integers(struct_lc))) % struct_lc
                    class_fixed[drop_class] = [v for v in class_fixed[drop_class] if v != var]
                    class_rdm_ind[drop_class] = [
                        t for t in class_rdm_ind[drop_class] if t.split(":")[0] != var
                    ]
                    class_rdm_cor[drop_class] = [
                        t for t in class_rdm_cor[drop_class] if t.split(":")[0] != var
                    ]
                    class_var_sets[drop_class] = class_var_sets[drop_class] - {var}

            # ── Force membership uniqueness across classes ──────────
            # When all non-reference classes share identical membership
            # variable sets, deterministically differentiate them to
            # avoid a constant class-probability model.
            if struct_lc > 1 and class_membership and len(class_membership) >= 2:
                mem_var_sets = [frozenset(cm) for cm in class_membership]
                if mem_var_sets[0] and all(s == mem_var_sets[0] for s in mem_var_sets[1:]):
                    eligible = sorted(mem_var_sets[0])
                    n_diff = min(2, len(eligible))
                    for d in range(n_diff):
                        avail = sorted(set(eligible) & mem_var_sets[0])
                        if not avail:
                            break
                        var = avail[int(rng.integers(len(avail)))]
                        drop_class = (d + int(rng.integers(len(class_membership)))) % len(class_membership)
                        class_membership[drop_class] = [
                            v for v in class_membership[drop_class] if v != var
                        ]
                        mem_var_sets[drop_class] = mem_var_sets[drop_class] - {var}

        spec = {
            "fixed_terms":       fixed,
            "rdm_terms":         rdm_ind,
            "rdm_cor_terms":     rdm_cor,
            "grouped_terms":     grouped,
            "hetro_in_means":    hetero,
            "hetro_in_variances": hetero_var,
            "zi_terms":          zi,
            "membership_terms":  membership,
            "class_membership":  class_membership if struct_lc > 1 else None,
            "dispersion":        1 if use_nb else 0,
            "latent_classes":    latent_classes,
            "group_id_col":      self.group_id_col,
        }
        # Per-class terms: only include when classes actually differ
        if struct_lc > 1:
            spec["class_fixed"]   = class_fixed
            spec["class_rdm_ind"] = class_rdm_ind
            spec["class_rdm_cor"] = class_rdm_cor

        self.last_rejection_reason = None  # structure decoded successfully
        return spec

    # ── structural_signature ────────────────────────────────────────

    def structural_signature(self, spec_dict) -> Optional[tuple]:
        if spec_dict is None:
            return None

        total_random = (
            len(spec_dict["rdm_terms"]) +
            len(spec_dict["rdm_cor_terms"]) +
            len(spec_dict["grouped_terms"])
        )
        hetero_eff = (
            tuple(sorted(spec_dict["hetro_in_means"]))
            if total_random > 0 else ()
        )
        hetero_var_eff = (
            tuple(sorted(spec_dict.get("hetro_in_variances", [])))
            if total_random > 0 else ()
        )

        return (
            tuple(sorted(spec_dict["fixed_terms"])),
            tuple(sorted(spec_dict["rdm_terms"])),
            tuple(sorted(spec_dict["rdm_cor_terms"])),
            tuple(sorted(spec_dict["grouped_terms"])),
            hetero_eff,
            hetero_var_eff,
            tuple(sorted(spec_dict["zi_terms"])),
            tuple(sorted(spec_dict.get("membership_terms", []))),
            tuple(
                tuple(sorted(cf)) for cf in spec_dict.get("class_fixed", [])
            ),
            spec_dict["dispersion"],
            spec_dict.get("latent_classes", 1),
        )

    # ── build_data ──────────────────────────────────────────────────

    def build_data(self, df, spec_dict, master_halton):
        """
        Extends parent build_data to pass membership_cols through to
        build_jax_data (handled by main_hpc_lc_patch), plus event_col for
        survival/hazard specs.
        """
        _ev = self.event_col
        data_tmp, spec = build_model_from_manual_spec(
            df=df,
            manual_spec=spec_dict,
            id_col=self.id_col,
            y_col=self.y_col,
            offset_col=self.offset_col,
            draw_method=getattr(self, 'draw_method', 'sobol'),
            R=self.R,
            event_col=_ev,
        )

        var_index = {v: i for i, v in enumerate(self.vars)}

        ind_idx = [var_index[v] for v in spec.random_ind_names]
        cor_idx = [var_index[v] for v in spec.random_cor_names]
        g_idx   = [var_index[v] for v in spec.grouped_names]

        draws_ind = _to_f64(master_halton[:, ind_idx, :]) if spec.Kr_ind > 0 else None
        draws_cor = _to_f64(master_halton[:, cor_idx, :]) if spec.Kr_cor > 0 else None
        draws_g   = None

        if spec.Kg > 0:
            if self.group_id_col is None:
                raise ValueError("Grouped effects require group_id_col")
            G = df[self.group_id_col].nunique()
            mh_g    = self._grouped_master_draws(
                G, seed=999,
                draw_method=getattr(self, 'draw_method', 'halton'))
            draws_g = _to_f64(mh_g[:, g_idx, :])

        # Rebuild with correct draws (membership_cols flows through spec_dict)
        data, spec = build_model_from_manual_spec(
            df=df,
            manual_spec=spec_dict,
            id_col=self.id_col,
            y_col=self.y_col,
            offset_col=self.offset_col,
            draws_ind=draws_ind,
            draws_cor=draws_cor,
            draws_g=draws_g,
            draw_method=getattr(self, 'draw_method', 'sobol'),
            R=self.R,
            event_col=_ev,
        )

        return data, spec

    def make_manual_spec_unified(
        self,
        fixed_terms: Optional[list[str]] = None,
        rdm_terms: Optional[list[str]] = None,
        rdm_cor_terms: Optional[list[str]] = None,
        grouped_terms: Optional[list[str]] = None,
        heterogeneity: Optional[dict[str, list[str]]] = None,
        zi_terms: Optional[list[str]] = None,
        membership_terms: Optional[list[str]] = None,
        class_membership: Optional[dict[int, list[str]]] = None,
        class_fixed: Optional[dict[int, list[str]]] = None,
        class_rdm_ind: Optional[dict[int, list[str]]] = None,
        class_rdm_cor: Optional[dict[int, list[str]]] = None,
        dispersion: int = 0,
        latent_classes: int = 1,
    ) -> dict[str, Any]:
        """
        Unified manual specification with structured heterogeneity.
        
        Parameters
        ----------
        fixed_terms : list of fixed effect variable names
        rdm_terms : list of independent random terms (format: "var:dist")
        rdm_cor_terms : list of correlated random terms (format: "var:dist")
        grouped_terms : list of grouped random terms (format: "var:dist")
        heterogeneity : dict with keys 'means', 'variances', and/or 'both'
            heterogeneity = {
                'means': ['z1', 'z2'],        # variables affecting random param MEANS
                'variances': ['z2', 'z3'],    # variables affecting random param VARIANCES
                'both': ['z4']                # affects both means and variances
            }
        zi_terms : list of zero-inflation variables
        membership_terms : list of class-membership variables
        class_membership : per-class membership variables {class_idx: [vars]}
        class_fixed : per-class fixed variables {class_idx: [vars]}
        class_rdm_ind : per-class independent random {class_idx: [vars]}
        class_rdm_cor : per-class correlated random {class_idx: [vars]}
        """
        hetro_in_means = []
        hetro_in_variances = []
        
        if heterogeneity:
            if 'means' in heterogeneity:
                hetro_in_means.extend(heterogeneity['means'])
            if 'variances' in heterogeneity:
                hetro_in_variances.extend(heterogeneity['variances'])
            if 'both' in heterogeneity:
                hetro_in_means.extend(heterogeneity['both'])
                hetro_in_variances.extend(heterogeneity['both'])
        
        # Convert per-class dicts to lists
        def _to_list(per_class_dict, n_classes):
            if per_class_dict is None:
                return None
            return [per_class_dict.get(c, []) for c in range(n_classes)]
        
        return {
            "fixed_terms": fixed_terms or [],
            "rdm_terms": rdm_terms or [],
            "rdm_cor_terms": rdm_cor_terms or [],
            "grouped_terms": grouped_terms or [],
            "hetro_in_means": hetro_in_means,
            "hetro_in_variances": hetro_in_variances,
            "zi_terms": zi_terms or [],
            "membership_terms": membership_terms or [],
            "class_membership": _to_list(class_membership, latent_classes - 1) if class_membership else None,
            "class_fixed": _to_list(class_fixed, latent_classes) if class_fixed else None,
            "class_rdm_ind": _to_list(class_rdm_ind, latent_classes) if class_rdm_ind else None,
            "class_rdm_cor": _to_list(class_rdm_cor, latent_classes) if class_rdm_cor else None,
            "dispersion": int(dispersion),
            "latent_classes": int(latent_classes),
        }

    # ── fitness ─────────────────────────────────────────────────────

    def fitness(self, decision) -> Union[float, np.ndarray]:
        """
        Evaluate a decision vector.

        For LC models (C > 1):
          1. Fit single-class (C=1) model for warm initialisation.
          2. Perturb θ₁ to seed each class.
          3. Run EM (≤30 steps) then MLE polish.

        Adaptive identifiability guard
        --------------------------------
        After every successful single-class fit the raw parameter vector is
        screened for near-zero coefficients (|estimate| < _id_zero_tol).
        Any active variable (role != 0) whose coefficient is essentially zero
        is recorded as a failure in the role memory so that sample_allowed_role()
        progressively avoids proposing that (variable, role) pair again.

        For membership variables specifically, the gamma params in the
        warm start are initialised to zero (constant class probs), which
        is the natural neutral starting point.
        """
        key = tuple(decision.tolist())
        if key in self.cache:
            return self.cache[key]

        spec_dict = self.build_spec(decision)
        if spec_dict is None:
            _rej = np.array([1e12, 1e12]) if self.mode == "multi" else 1e12
            self._cache_put(key, _rej)
            return _rej

        sig = self.structural_signature(spec_dict)
        if sig is None:
            return np.array([1e12, 1e12]) if self.mode == "multi" else 1e12

        if sig in self._failed_structures:
            return np.array([1e12, 1e12]) if self.mode == "multi" else 1e12

        if sig in self.structure_cache:
            return np.array([1e12, 1e12]) if self.mode == "multi" else 1e12

        self.structure_cache.clear()
        self.structure_cache.add(sig)

        C = spec_dict.get("latent_classes", 1)

        try:
            data_train, spec = self.build_data(
                self.df_train, spec_dict, self.master_halton_train
            )
            if spec_dict.get("model") is not None:
                spec = replace(spec, model=spec_dict["model"])

            # ── Single-class path ──────────────────────────────────
            if C == 1:
                # Survival/hazard families cannot go through CountModel,
                # which is hard-wired to mixed_model_loglik.  Route them to
                # SurvivalModel, which uses survival_mixed_model_loglik and
                # therefore reads data["event"] (the censoring indicator).
                fam = _survival_family_for(spec.model)
                if fam is not None:
                    bic, surv_params = self._fit_survival_single(spec, data_train, fam)
                    result_1 = None
                else:
                    model = CountModel(spec, data_train)
                    result_1 = model.fit()
                    bic = model.bic()
                    surv_params = np.asarray(result_1.params)

                    # ── Adaptive identifiability guard + cache ─────────
                # Store the fit so BanditGuidedSA can read t-stats
                # without a second fit call.
                self._last_fit_cache = {
                    "params": surv_params,
                    "spec":   spec,
                    "data":   data_train,
                    "bic":    float(bic),
                }
                # Export SPF report after successful fit
                try:
                    spf_results = export_spf_report(
                        self._last_fit_cache, self.df, 
                        output_dir="spf_exports", class_col="FC"
                    )
                    print(f"  [SPF Export] Generated SPF report for {len(spf_results)} classes")
                except Exception as e:
                    print(f"  [SPF Export] Warning: {e}")
                self._update_role_memory_from_fit(
                    params   = self._last_fit_cache["params"],
                    spec     = spec,
                    decision = decision,
                )

            # ── Multi-class path with warm start ───────────────────
            else:
                K_mem  = spec.K_membership
                C_fit  = spec_dict.get("latent_classes", 1)
                # ── Compute per-class gamma sizes from class_membership ──
                if hasattr(spec, 'class_membership_idx') and spec.class_membership_idx:
                    per_class_gamma_sizes = [len(idx) + 1 for idx in spec.class_membership_idx]
                else:
                    per_class_gamma_sizes = [K_mem + 1] * (C_fit - 1) if C_fit > 1 else []
                gamma_total = sum(per_class_gamma_sizes)
                spec_1 = replace(spec, latent_classes=1)

                # Step 1 — fit single-class
                model_1   = CountModel(spec_1, data_train)
                result_1  = model_1.fit()
                theta_1   = np.array(result_1.params)
                K_base    = build_param_index(spec_1)["total_params"]

                # Pre-build spec_c and pindex for per-class sizes
                spec_c = replace(spec, latent_classes=C,
                                 l2_penalty=0.1)
                pindex_c = build_param_index(spec_c)
                _class_K_base = list(pindex_c.get("class_K_base", [K_base] * C))

                # Step 2 — cluster-based seeding for well-separated class starts
                rng = np.random.default_rng(abs(hash(sig)) % (2**31))
                try:
                    per_class_thetas = _seed_classes_from_clusters(
                        theta_1, data_train, spec_1, C, K_base, rng,
                        class_K_base=_class_K_base,
                    )
                    theta_init = np.concatenate(per_class_thetas)
                except Exception:
                    theta_init = np.concatenate([
                        theta_1[:k] + rng.normal(0, 0.05, k)
                        if len(theta_1) >= k
                        else np.pad(theta_1, (0, k - len(theta_1))) + rng.normal(0, 0.05, k)
                        for k in _class_K_base
                    ])

                # gamma init: zeros → equal class probs, membership coeffs=0
                gamma_init = np.zeros(gamma_total)
                init_params = np.concatenate([theta_init, gamma_init])

                # Step 3 — EM
                try:
                    params_em = run_with_oom_recovery(
                        fit_em,
                        init_params=init_params,
                        data=data_train,
                        spec=spec_c,
                        max_iter=30,
                        tol=1e-4,
                        verbose=False,
                        label="fitness EM",
                    )
                except Exception:
                    params_em = init_params

                # Step 4 — MLE polish (JAX-native optimizer with L2 penalty)
                polish = LBFGS(
                    fun=lambda p: mixed_model_loglik_reg(p, data_train, spec_c),
                    maxiter=500,
                )
                result_c = run_with_oom_recovery(
                    polish.run, jnp.array(params_em), label="fitness LC polish"
                )
                params_c = np.array(result_c.params)
                ll  = -float(mixed_model_loglik(params_c, data_train, spec_c))  # unregularised LL
                n   = data_train["y"].shape[0]
                k   = len(params_c)
                bic = k * np.log(n) - 2.0 * ll

                # ── Store fit cache so BanditGuidedSA can read t-stats ──
                self._last_fit_cache = {
                    "params": params_c,
                    "spec":   spec_c,
                    "data":   data_train,
                    "bic":    float(bic),
                }
                # Export SPF report after successful fit
                try:
                    spf_results = export_spf_report(
                        self._last_fit_cache, self.df, 
                        output_dir="spf_exports", class_col="FC"
                    )
                    print(f"  [SPF Export] Generated SPF report for {len(spf_results)} classes")
                except Exception as e:
                    print(f"  [SPF Export] Warning: {e}")
                # Adaptive guard on the LC params (per-class fixed effects)
                self._update_role_memory_from_fit(
                    params   = params_c,
                    spec     = spec_c,
                    decision = decision,
                )

                class _Model:
                    params = params_c
                model = _Model()

            # ── Single-objective return ────────────────────────────
            if self.mode == "single":
                value = float(bic)
                self._cache_put(key, value)
                self._last_successful_decision = decision.copy()
                return value

            # ── Multi-objective return (BIC + test RMSE) ──────────
            data_test, _ = self.build_data(
                self.df_test, spec_dict, self.master_halton_test
            )
            model_test        = CountModel(spec, data_test)
            model_test.params = np.array(model.params)
            preds   = model_test.predict()
            y_true  = np.array(data_test["y"]).squeeze()
            rmse    = np.sqrt(np.mean((preds - y_true) ** 2))

            value = np.array([float(bic), float(rmse)])
            self._cache_put(key, value)
            self._last_successful_decision = decision.copy()
            return value

        except Exception as e:
            import traceback
            print(f"  [fitness error] {e}")

            # ── GPU OOM is transient, not structural ─────────────────
            # A structure that failed only because the device ran out of
            # memory must NOT be blacklisted: run_with_oom_recovery has
            # already retried on CPU, so reaching this branch means both
            # attempts failed.  Free caches and reject without banning.
            if _is_oom_error(e):
                try:
                    jax.clear_caches()
                except Exception:
                    pass
                gc.collect()
                return np.array([1e12, 1e12]) if self.mode == "multi" else 1e12

            traceback.print_exc()
            if sig is not None:
                self._failed_structures.add(sig)
                # Cap at 2000 entries to prevent unbounded growth during
                # long searches (the older structures are re-tested).
                if len(self._failed_structures) > 2000:
                    self._failed_structures.clear()
                    print("  [fitness] cleared convergence-failure cache"
                          " (2000 entries); will re-test previously"
                          " failed structures.")
            # ── Progressive variable ban ──────────────────────────
            # Only increment failure counts for variables that were
            # NEWLY activated in this iteration (role went from 0 in
            # the last successful fit to non-zero now).  Variables
            # that were already active and working should not be
            # blamed for a failure they didn't cause.
            D = len(self.vars)
            if (self._last_successful_decision is not None
                    and len(decision) >= D
                    and len(self._last_successful_decision) >= D):
                for i in range(min(D, len(decision))):
                    new_role = int(decision[i])
                    old_role = int(self._last_successful_decision[i])
                    # Only count if this variable was just added (0→non-zero)
                    if old_role == 0 and new_role != 0:
                        var = self.vars[i]
                        if var not in self._force_included_vars:
                            cnt = self._variable_failure_counts.get(var, 0) + 1
                            self._variable_failure_counts[var] = cnt
                            if cnt >= self._BAN_THRESHOLD and var not in self._banned_variables:
                                self._banned_variables.add(var)
                                print(f"  [ban] '{var}' excluded from future"
                                      f" candidates ({cnt} failure{'' if cnt == 1 else 's'}"
                                      f" when newly added); threshold = {self._BAN_THRESHOLD}")
                # Cap and clear if too many bans
                if len(self._banned_variables) > 50:
                    self._banned_variables.clear()
                    self._variable_failure_counts.clear()
                    print("  [ban] cleared variable-ban cache (50+ variables);"
                          " will re-test previously banned variables.")
            fail_val = np.array([1e12, 1e12]) if self.mode == "multi" else 1e12
            self._cache_put(key, fail_val)
            if _is_oom_error(e):
                # A GPU OOM here means the device is at/near capacity. Free
                # whatever JAX can free immediately so the *next* candidate
                # in the search isn't doomed by the same exhaustion (left
                # unhandled, this previously caused every remaining
                # generation in a 500-gen SA run to fail identically).
                print("  [fitness error] GPU out-of-memory; "
                      "clearing JAX caches before continuing search.")
                jax.clear_caches()
                gc.collect()
            return fail_val

    # ── Adaptive identifiability helper ─────────────────────────────

    _id_zero_tol: float = 1e-3   # |coef| below this → treat as zero-effect

    def _update_role_memory_from_fit(
        self,
        params:   np.ndarray,
        spec,
        decision: np.ndarray,
    ) -> None:
        """
        Inspect fixed-effect coefficients and update the sign_violation counters
        that sample_allowed_role() reads to down-weight bad (variable, role) pairs.

        A variable is flagged as 'bad' when its fixed-effect estimate is
        effectively zero (|β| < _id_zero_tol) AND it has a non-zero role —
        meaning it is wasting a degree of freedom without contributing to fit.
        This populates the _sign_visit_counts / _sign_violation_counts dicts
        that already exist in the Solvers_METAJAX bandit hook.
        """
        if not (hasattr(self, "_sign_violation_counts")
                and hasattr(self, "_sign_visit_counts")):
            # Initialise lazily so vanilla SA still works without the memory
            self._sign_violation_counts: Dict[str, int] = {}
            self._sign_visit_counts:     Dict[str, int] = {}

        try:
            fixed_names = list(getattr(spec, "fixed_names", []))
            n_vars = len(self.vars)
            D = min(n_vars, len(decision))

            # Map fixed_name → param index (skip __INTERCEPT__)
            name_to_param_idx = {
                nm: i for i, nm in enumerate(fixed_names)
                if nm != "__INTERCEPT__"
            }

            for var_idx in range(D):
                role = int(decision[var_idx])
                if role == 0:
                    continue
                var_name = self.vars[var_idx]
                pidx = name_to_param_idx.get(var_name)
                if pidx is None or pidx >= len(params):
                    continue

                coef = float(params[pidx])
                self._sign_visit_counts[var_name] = (
                    self._sign_visit_counts.get(var_name, 0) + 1
                )
                if abs(coef) < self._id_zero_tol:
                    # Record as a violation so the bandit down-weights this role
                    self._sign_violation_counts[var_name] = (
                        self._sign_violation_counts.get(var_name, 0) + 1
                    )
        except Exception:
            pass  # Never let this crash a fitness evaluation


class ForcedModelStructureEvaluatorLC(StructureEvaluatorLC):
    def __init__(self, *args, forced_model: str, **kwargs):
        super().__init__(*args, **kwargs)
        self.forced_model = forced_model

    def build_spec(self, decision) -> Optional[dict]:
        spec = super().build_spec(decision)
        if spec is None:
            return None
        spec["model"] = self.forced_model
        if self.forced_model in {"lognormal", "gaussian", "tobit"}:
            spec["dispersion"] = 0
        # Survival families carry a scale/shape parameter, not a
        # Poisson/NB dispersion bit, and have no zero-inflation block.
        if _survival_family_for(self.forced_model) is not None:
            spec["dispersion"] = 0
            spec["zi_terms"] = []
        return spec


# ═══════════════════════════════════════════════════════════════════════
# SOLVER PATCH  — generate_neighbor supports tail genes (dispersion + LC)
# and the new roles 7 / 8.  Replace AdvancedSimulatedAnnealing.generate_neighbor.
# ═══════════════════════════════════════════════════════════════════════

def _generate_neighbor_patched(self, solution, T=None, max_attempts=20, min_active=2):
    """
    Extended generate_neighbor that mutates ALL gene slots AND uses
    classical analyst-inspired moves (forward-selection, backward-elimination,
    stepwise-swap, role promotion/demotion, distribution-change, etc.)
    alongside random exploration.

    Move probabilities (temperature-adaptive):
      - Forward selection  : 0.18   (excluded → active)
      - Backward elimination: 0.18   (active → excluded)
      - Stepwise swap      : 0.10   (remove one active, add one excluded)
      - Role promotion     : 0.12   (upgrade role, e.g. fixed→random)
      - Role demotion      : 0.12   (downgrade role, e.g. random→fixed)
      - Distribution change: 0.08   (try a different distribution)
      - Dispersion flip    : 0.04   (Poisson ↔ NB)
      - LC step            : 0.03   (change latent class count)
      - Random exploration : 0.15   (current behaviour)
    """
    D = self.dim_core
    roles = solution[:D].astype(int)

    if T is not None and self.T0 is not None:
        mut_rate = self.mutation_rate * (T / self.T0)
    else:
        mut_rate = self.mutation_rate
    mut_rate = float(np.clip(mut_rate, 0.0, 1.0))

    # ── Build helper maps ─────────────────────────────────────────────
    var_names    = self.evaluator.vars
    active_idx   = [i for i in range(D) if roles[i] != 0]
    banned_vars  = getattr(self.evaluator, "_banned_variables", set())
    force_inc    = getattr(self.evaluator, "_force_included_vars", set())
    excluded_idx = [
        i for i in range(D)
        if roles[i] == 0 and var_names[i] not in (banned_vars - force_inc)
    ]
    allowed_map  = self.evaluator.allowed_roles
    has_lc       = getattr(self.evaluator, "max_latent_classes", 1) > 1

    # ── Move-type weights ─────────────────────────────────────────────
    explore_w    = 0.14
    fwd_w         = 0.17
    bwd_w         = 0.17
    swap_w        = 0.10
    promote_w     = 0.11
    demote_w      = 0.11
    dist_change_w = 0.07
    disp_flip_w   = 0.04
    lc_step_w     = 0.03
    het_var_w     = 0.03  # NEW: dedicated move for heterogeneity in variances

    move_names = ["explore",   "forward",    "backward",  "stepwise",
                  "promote",   "demote",     "dist",      "dispersion",
                  "lc_step",   "het_var"]
    move_probs = np.array([explore_w, fwd_w, bwd_w, swap_w,
                           promote_w, demote_w, dist_change_w,
                           disp_flip_w, lc_step_w, het_var_w])
    move_probs = move_probs / move_probs.sum()

    for _attempt in range(max_attempts):
        neighbor = solution.copy()
        move = np.random.choice(move_names, p=move_probs)

        # ── FORWARD SELECTION ─────────────────────────────────────
        if move == "forward" and excluded_idx:
            i = np.random.choice(excluded_idx)
            allowed = allowed_map.get(var_names[i], [0])
            non_zero = [r for r in allowed if r != 0]
            if non_zero:
                neighbor[i] = np.random.choice(non_zero)
            else:
                neighbor[i] = 1  # default to fixed

        # ── BACKWARD ELIMINATION ──────────────────────────────────
        elif move == "backward" and active_idx:
            i = np.random.choice(active_idx)
            neighbor[i] = 0

        # ── STEPWISE SWAP ─────────────────────────────────────────
        elif move == "stepwise" and active_idx and excluded_idx:
            i_out = np.random.choice(active_idx)
            i_in  = np.random.choice(excluded_idx)
            neighbor[i_out] = 0
            allowed_in = allowed_map.get(var_names[i_in], [0])
            non_zero_in = [r for r in allowed_in if r != 0]
            neighbor[i_in] = np.random.choice(non_zero_in) if non_zero_in else 1

        # ── ROLE PROMOTION (upgrade complexity) ───────────────────
        elif move == "promote" and active_idx:
            i = np.random.choice(active_idx)
            role = int(neighbor[i])
            allowed = allowed_map.get(var_names[i], range(10))
            # Analyst hierarchy: excluded(0) < fixed(1) < rdm-ind(2) < rdm-cor(3)
            #                  < grouped(4) < hetero(5) < ZI(6) < het-var(9)
            # Also allow jump from fixed(1) to ZI(6)
            promotions = {
                1: [2, 3, 6, 9],       # fixed → random-ind/cor or ZI or het-var
                2: [3, 5, 9],          # rdm-ind → rdm-cor or hetero or het-var
                3: [2, 3, 9],          # rdm-cor → (already high) or het-var
                4: [9],                # grouped → het-var
                6: [2, 3, 9],          # ZI → random or het-var
            }
            candidates = promotions.get(role, [])
            candidates = [c for c in candidates if c in allowed]
            if candidates:
                neighbor[i] = np.random.choice(candidates)

        # ── ROLE DEMOTION (simplify) ──────────────────────────────
        elif move == "demote" and active_idx:
            i = np.random.choice(active_idx)
            role = int(neighbor[i])
            allowed = allowed_map.get(var_names[i], range(10))
            demotions = {
                2: [1, 0],           # rdm-ind → fixed or excluded
                3: [2, 1],           # rdm-cor → rdm-ind or fixed
                4: [2, 1, 0],        # grouped → rdm-ind or fixed or excluded
                5: [0],              # hetero → excluded (unlikely to be useful alone)
                6: [1, 0],           # ZI → fixed or excluded
                7: [0],              # membership → excluded
                8: [1, 0],           # membership+fixed → fixed or excluded
                9: [0],              # het-var → excluded
            }
            candidates = demotions.get(role, [])
            # Always allow downgrade to excluded (0) or fixed (1) from any non-zero role
            if role not in (0, 1):
                candidates.extend([0, 1])
            candidates = sorted(set(c for c in candidates if c in allowed))
            if candidates:
                neighbor[i] = np.random.choice(candidates)

        # ── DISTRIBUTION CHANGE ───────────────────────────────────
        elif move == "dist" and active_idx:
            # Find random variables (roles 2,3,4) and change their dist
            rdm_idx = [i for i in active_idx if int(neighbor[i]) in (2, 3, 4)]
            if rdm_idx:
                i = np.random.choice(rdm_idx)
                dist_idx = D + i  # distribution genes offset by D
                old_dist = int(neighbor[dist_idx])
                possible = [d for d in range(5) if d != old_dist]
                neighbor[dist_idx] = np.random.choice(possible) if possible else 0

        # ── DISPERSION FLIP ───────────────────────────────────────
        elif move == "dispersion":
            disp_idx = 2 * D
            neighbor[disp_idx] = 1 - int(neighbor[disp_idx])

        # ── LATENT CLASS STEP ─────────────────────────────────────
        elif move == "lc_step" and has_lc:
            lc_idx = 2 * D + 1
            max_code = self.evaluator.max_latent_classes - 1
            step = np.random.choice([-1, 1])
            neighbor[lc_idx] = int(np.clip(int(neighbor[lc_idx]) + step, 0, max_code))
            # When stepping to LC=1, clear membership roles (7,8) and het-var (9)
            if neighbor[lc_idx] == 0:
                for i in range(D):
                    if int(neighbor[i]) in (7, 8, 9):
                        neighbor[i] = 0
            # When stepping from LC=1 to LC>=2, also randomise class masks
            if neighbor[lc_idx] > 0 and has_lc and len(neighbor) > 2 * D + 2:
                max_lc = getattr(self.evaluator, "max_latent_classes", 2)
                for idx in range(2 * D + 2, min(3 * D + 2, len(neighbor))):
                    neighbor[idx] = np.random.randint(0, max_lc + 1)

        # ── HETEROGENEITY IN VARIANCES (role 9) ─────────────────
        elif move == "het_var":
            # Toggle or assign role 9
            # Can add het-var to variables that are random-capable (allowed roles include 2,3,4)
            random_capable = [i for i in range(D)
                              if 9 in allowed_map.get(var_names[i], []) and
                              any(r in allowed_map.get(var_names[i], []) for r in (2, 3, 4))]
            # Can also add het-var to excluded variables that could become random
            excluded_het = [i for i in excluded_idx
                            if 9 in allowed_map.get(var_names[i], []) and
                            any(r in allowed_map.get(var_names[i], []) for r in (2, 3, 4))]
            candidates = random_capable + excluded_het
            if candidates:
                i = np.random.choice(candidates)
                if int(neighbor[i]) == 9:
                    # Demote from het-var following hierarchy: 9 → 4 → 3 → 2 → 1 → 0
                    allowed = allowed_map.get(var_names[i], range(10))
                    # Prefer demotion to random roles if available
                    preferred = [r for r in [4, 3, 2, 1, 0] if r in allowed]
                    if preferred:
                        neighbor[i] = np.random.choice(preferred)
                    else:
                        neighbor[i] = 0
                else:
                    neighbor[i] = 9

        # ── RANDOM EXPLORATION (classic behavior) ─────────────────
        else:
            n_changes = np.random.randint(self.min_changes, self.max_changes + 1)
            indices   = list(np.random.choice(self.dim, size=n_changes, replace=False))

            # Force at least one class_mask mutation when LC is enabled
            if has_lc:
                mask_start = 2 * D + 2
                mask_end   = 3 * D + 1
                mask_ii = list(range(mask_start, min(mask_end + 1, self.dim)))
                if mask_ii and not any(i in indices for i in mask_ii):
                    ri = np.random.choice(range(len(indices)))
                    indices[ri] = int(np.random.choice(mask_ii))
                if mask_ii and np.random.rand() < 0.8:
                    extra = int(np.random.choice(mask_ii))
                    if extra not in indices:
                        indices.append(extra)
            indices = np.asarray(indices, dtype=int)

            for idx in indices:
                if np.random.rand() < mut_rate:
                    if idx < D:
                        neighbor[idx] = self.sample_allowed_role(idx)
                    elif idx < 2 * D:
                        # Distribution genes: 5 distributions (0-4)
                        neighbor[idx] = np.random.randint(0, 5)
                    else:
                        tail_pos = idx - 2 * D
                        if tail_pos == 0:
                            neighbor[idx] = 1 - int(neighbor[idx])
                        elif tail_pos == 1:
                            max_code = self.evaluator.max_latent_classes - 1
                            step = np.random.choice([-1, 1])
                            neighbor[idx] = int(np.clip(int(neighbor[idx]) + step, 0, max_code))
                        else:
                            max_lc2 = getattr(self.evaluator, "max_latent_classes", 2)
                            old_val = int(neighbor[idx])
                            choices = [v for v in range(max_lc2 + 1) if v != old_val]
                            if choices:
                                neighbor[idx] = int(np.random.choice(choices))

        # ── Enforce min-active ────────────────────────────────────────
        n_roles = neighbor[:D]
        active_now = np.sum(n_roles != 0)
        if active_now < min_active:
            zeros = np.where(n_roles == 0)[0]
            if len(zeros) > 0:
                activate = np.random.choice(
                    zeros, size=min_active - active_now, replace=False
                )
                for j in activate:
                    neighbor[j] = self.sample_allowed_role(j, force_active=True)

        # ── Verify LC consistency: if LC=1, strip membership roles ────
        if has_lc and len(neighbor) > 2 * D + 1:
            if int(neighbor[2 * D + 1]) == 0:
                for i in range(D):
                    if int(neighbor[i]) in (7, 8, 9):
                        neighbor[i] = 0

        neighbor = self.repair(neighbor)
        if self.is_same(neighbor, solution):
            continue
        return neighbor

    # Fallback — always return something different
    neighbor = solution.copy()
    if len(active_idx) > 0 and len(excluded_idx) > 0:
        # Swap one active for one excluded
        neighbor[np.random.choice(active_idx)] = 0
        in_idx = np.random.choice(excluded_idx)
        allowed = allowed_map.get(var_names[in_idx], [0])
        non_zero = [r for r in allowed if r != 0]
        neighbor[in_idx] = np.random.choice(non_zero) if non_zero else 1
    elif len(active_idx) >= 2:
        # Toggle the role of one active variable
        i = np.random.choice(active_idx)
        allowed = allowed_map.get(var_names[i], range(10))
        old = int(neighbor[i])
        possible = [r for r in allowed if r != old]
        neighbor[i] = np.random.choice(possible) if possible else 0
    else:
        # Activate at least min_active
        zero_idx = np.where(neighbor[:D] == 0)[0]
        activate = np.random.choice(zero_idx, size=min_active, replace=False)
        neighbor[activate] = np.random.randint(1, 10, size=len(activate))
    return neighbor


_solvers.AdvancedSimulatedAnnealing.generate_neighbor = _generate_neighbor_patched


def _survival_family_for(model: Optional[str]) -> Optional[str]:
    """
    Map a ``spec.model`` string to a survival family name, or None.

    Survival specs carry the family name in ``spec.model`` itself
    ("weibull_ph", "lognormal", ...), so this is an identity lookup guarded
    by membership in the survival family set.  Imported lazily: the survival
    module pulls in main_hpc, and importing it at module scope would make
    experiment_package's import order significant.
    """
    if not model:
        return None
    try:
        from .survival_models import ALL_SURVIVAL_FAMILIES
    except ImportError:                       # flat import (script in package dir)
        try:
            from survival_models import ALL_SURVIVAL_FAMILIES
        except ImportError:
            return None
    return model if model in ALL_SURVIVAL_FAMILIES else None


# ═══════════════════════════════════════════════════════════════════════
# ExperimentBuilder
# ═══════════════════════════════════════════════════════════════════════

class ExperimentBuilder:
    """
    Inspects any DataFrame and guides you through setting up an experiment.

    Quick-start
    ───────────
    from experiment_package import ExperimentBuilder
    import pandas as pd

    df      = pd.read_csv("my_data.csv")
    builder = ExperimentBuilder(df, id_col="SITE_ID", y_col="CRASHES")

    builder.describe()          # data + variable stats
    builder.suggest_config()    # auto role/dist suggestions with explanation

    evaluator = builder.build_evaluator(
        fixed_override      = {"OFFSET": [1]},   # force OFFSET → fixed
        exclude             = ["YEAR"],           # always exclude YEAR
        mode                = "single",           # BIC only
        max_latent_classes  = 2,                  # allow up to 2 LC classes
        membership_override = {"URB": [7]},       # allow URB as membership-only
        R                   = 200,
    )

    result = builder.run(evaluator, algo="sa", max_iter=3000)
    """

    _ROLE_NAMES = {
        0: "Excluded", 1: "Fixed", 2: "Rnd-Ind", 3: "Rnd-Cor",
        4: "Grouped",  5: "Hetero", 6: "ZI", 7: "Membership", 8: "Mem+Fixed",
    }

    def __init__(
        self,
        df:           pd.DataFrame,
        id_col:       str,
        y_col:        str,
        offset_col:   Optional[str] = None,
        group_id_col: Optional[str] = None,
        default_model_family: str = "count",
        default_engine: str = "jax",
        event_col:    Optional[str] = None,
    ):
        self.df           = df.copy()
        self.id_col       = id_col
        self.y_col        = y_col
        self.offset_col   = offset_col
        self.group_id_col = group_id_col
        # Survival/hazard only: column of 0/1 right-censoring flags.  When
        # set, y_col must hold a strictly positive DURATION, not a count.
        self.event_col    = event_col
        self.default_model_family = default_model_family.lower()
        self.default_engine = default_engine.lower()
        self._evaluator: Optional[StructureEvaluatorLC] = None

        if self.default_model_family != "count":
            raise ValueError("ExperimentBuilder defaults must remain count-first. Use build_search(model_family=...) for alternative families.")
        if self.default_engine not in {"jax", "numba", "numba-rp"}:
            raise ValueError("default_engine must be 'jax', 'numba' or 'numba-rp'")

        self._ensure_columns_exist([id_col, y_col], "ExperimentBuilder")
        if offset_col is not None:
            self._ensure_columns_exist([offset_col], "ExperimentBuilder")
        if group_id_col is not None:
            self._ensure_columns_exist([group_id_col], "ExperimentBuilder")

        reserved = {id_col, y_col}
        if offset_col:   reserved.add(offset_col)
        if group_id_col: reserved.add(group_id_col)
        self._candidate_vars = [c for c in df.columns if c not in reserved]

    def _ensure_columns_exist(self, columns: List[str], context: str = "builder") -> None:
        missing = [column for column in columns if column not in self.df.columns]
        if missing:
            formatted = ", ".join(sorted(missing))
            raise ValueError(f"{context} received columns that are not in the dataframe: {formatted}")

    def _normalize_variables(self, variables: Optional[List[str]], exclude: Optional[List[str]] = None) -> List[str]:
        chosen = list(self._candidate_vars if variables is None else variables)
        self._ensure_columns_exist(chosen, "variables")
        filtered = [var for var in chosen if var not in set(exclude or [])]
        if not filtered:
            raise ValueError("No searchable variables remain after applying exclude.")
        return list(dict.fromkeys(filtered))

    def _normalize_override_map(self, mapping: Optional[Dict[str, list]], label: str) -> Dict[str, list]:
        normalized = mapping or {}
        self._ensure_columns_exist(list(normalized.keys()), label)
        return normalized

    @staticmethod
    def _raise_on_unused_kwargs(kwargs: Dict[str, Any], context: str) -> None:
        if not kwargs:
            return
        unused = ", ".join(sorted(kwargs.keys()))
        raise ValueError(f"Unexpected arguments for {context}: {unused}")

    @staticmethod
    def _continuous_de_warm_start(
        objective,
        init_params: np.ndarray,
        *,
        enabled: bool,
        maxiter: int,
        popsize: int,
        rel_span: float,
        abs_span: float,
        seed: int,
    ) -> tuple[np.ndarray, dict[str, Any]]:
        """Refine an initial parameter vector with bounded continuous DE."""
        init = np.asarray(init_params, dtype=float).reshape(-1)
        if (not enabled) or init.size == 0:
            return init, {
                "ran": False,
                "accepted": False,
                "reason": "disabled_or_empty",
            }

        safe_init = np.where(np.isfinite(init), init, 0.0)
        span = np.maximum(abs_span, np.abs(safe_init) * rel_span)
        bounds = [(c - s, c + s) for c, s in zip(safe_init, span)]

        def _obj_np(x):
            try:
                value = float(objective(jnp.array(x)))
            except Exception:
                return 1e20
            if not np.isfinite(value):
                return 1e20
            return value

        incumbent = safe_init
        incumbent_obj = _obj_np(incumbent)
        report: dict[str, Any] = {
            "ran": True,
            "accepted": False,
            "seed": int(seed),
            "maxiter": int(maxiter),
            "popsize": int(popsize),
            "start_obj": float(incumbent_obj),
            "de_obj": None,
            "delta_obj": None,
            "reason": "not_improved",
        }

        try:
            de_result = scipy_differential_evolution(
                _obj_np,
                bounds=bounds,
                maxiter=int(maxiter),
                popsize=int(popsize),
                seed=int(seed),
                polish=False,
                updating="deferred",
                workers=1,
            )
            candidate = np.asarray(de_result.x, dtype=float)
            candidate_obj = float(de_result.fun)
            report["de_obj"] = candidate_obj
            report["delta_obj"] = float(incumbent_obj - candidate_obj) if np.isfinite(candidate_obj) else None
            if np.isfinite(candidate_obj) and candidate_obj < incumbent_obj:
                report["accepted"] = True
                report["reason"] = "improved"
                return candidate, report
        except Exception as exc:
            warnings.warn(
                f"Continuous DE warm-start skipped due to: {exc}",
                RuntimeWarning,
                stacklevel=2,
            )
            report["reason"] = f"exception: {exc}"

        return incumbent, report

    @staticmethod
    def _is_cmf_local_name(name: str) -> bool:
        return str(name).startswith("__cmf_local__")

    def _build_cmf_local_bounds(
        self,
        spec,
        lower_level_param_bounds,
    ) -> tuple[list[tuple[Optional[float], Optional[float]]], int]:
        lo, hi = float(lower_level_param_bounds[0]), float(lower_level_param_bounds[1])
        if lo >= hi:
            raise ValueError("lower_level_param_bounds must be (lower, upper) with lower < upper.")

        full_index = build_param_index(spec)
        total_params = int(full_index["total_params"])
        bounds: list[tuple[Optional[float], Optional[float]]] = [(None, None)] * total_params

        base_spec = replace(spec, latent_classes=1)
        base_index = build_base_index(base_spec)

        base_target_idx: list[int] = []

        fixed_rng = base_index.get("fixed")
        if fixed_rng is not None:
            fs, _ = fixed_rng
            for i, name in enumerate(getattr(base_spec, "fixed_names", ())):
                if self._is_cmf_local_name(name):
                    base_target_idx.append(fs + i)

        cor_rng = base_index.get("cor_mean")
        if cor_rng is not None:
            cs, _ = cor_rng
            for i, name in enumerate(getattr(base_spec, "random_cor_names", ())):
                if self._is_cmf_local_name(name):
                    base_target_idx.append(cs + i)

        ind_rng = base_index.get("ind_mean")
        if ind_rng is not None:
            is_, _ = ind_rng
            for i, name in enumerate(getattr(base_spec, "random_ind_names", ())):
                if self._is_cmf_local_name(name):
                    base_target_idx.append(is_ + i)

        grp_rng = base_index.get("group_mean")
        if grp_rng is not None:
            gs, _ = grp_rng
            for i, name in enumerate(getattr(base_spec, "grouped_names", ())):
                if self._is_cmf_local_name(name):
                    base_target_idx.append(gs + i)

        base_target_idx = sorted(set(base_target_idx))
        if not base_target_idx:
            return bounds, 0

        if int(getattr(spec, "latent_classes", 1)) > 1:
            k_base = int(base_index["total_params"])
            C = int(spec.latent_classes)
            for c in range(C):
                offset = c * k_base
                for idx in base_target_idx:
                    bounds[offset + idx] = (lo, hi)
            return bounds, len(base_target_idx) * C

        for idx in base_target_idx:
            bounds[idx] = (lo, hi)
        return bounds, len(base_target_idx)

    @staticmethod
    def _bounded_refit(objective, start_params, bounds, maxiter: int = 500) -> np.ndarray:
        x0 = np.asarray(start_params, dtype=float).reshape(-1)
        if x0.size == 0:
            return x0

        from jaxopt import ScipyBoundedMinimize

        def _obj_val(x):
            try:
                value = float(objective(jnp.array(x, dtype=jnp.float64)))
            except Exception:
                return 1e20
            return value if np.isfinite(value) else 1e20

        start_val = _obj_val(x0)

        try:
            solver = ScipyBoundedMinimize(
                fun=objective,
                method="SLSQP",
                tol=1e-8,
                maxiter=int(maxiter),
            )
            # Convert unconstrained entries to +/-inf for JAXopt's bounded API.
            lb = jnp.asarray(
                [-np.inf if b[0] is None else float(b[0]) for b in bounds],
                dtype=jnp.float64,
            )
            ub = jnp.asarray(
                [np.inf if b[1] is None else float(b[1]) for b in bounds],
                dtype=jnp.float64,
            )
            result = solver.run(jnp.array(x0, dtype=jnp.float64), (lb, ub))
            cand = np.asarray(result.params, dtype=float)
            cand_val = _obj_val(cand)
            if np.isfinite(cand_val) and cand_val <= start_val:
                return cand
        except Exception as exc:
            warnings.warn(
                f"Bounded lower-level refit skipped due to: {exc}",
                RuntimeWarning,
                stacklevel=2,
            )

        return x0

    @staticmethod
    def get_search_argument_guide() -> Dict[str, Dict[str, str]]:
        return {
            "shared": {
                "algo": "Metaheuristic driver. Use 'sa', 'hc', 'de', or 'hs'.",
                "R": "Number of simulation draws for JAX mixed-model estimation.",
                "max_iter": "Search iterations for the metaheuristic driver.",
                "max_latent_classes": "Upper bound on latent classes for the count-family architecture.",
            },
            "count": {
                "variables": "Candidate columns to search over.",
                "default_roles": "Allowed structural roles per variable.",
                "fixed_override": "Force or restrict roles for specific variables.",
                "membership_override": "Allow or restrict latent-class membership roles for specific variables.",
            },
            "cmf": {
                "aadt_col": "AADT column used to build the CMF elasticity term.",
                "baseline_vars": "Baseline CMF variables entering outside log(AADT).",
                "local_vars": "CMF local variables entering as var * log(AADT).",
                "cmf_driver": "Use 'jax_count' for the main JAX architecture or 'ga' for the legacy GA route.",
            },
            "linear": {
                "objective_kwargs": "Options forwarded to the linear metaheuristic objective.",
            },
            "duration": {
                "budget_col": "Budget column used by the duration helper objective.",
                "objective": "Duration objective: 'independent' or 'budget_penalty'.",
            },
            "survival": {
                "family": "Survival parameterisation: 'weibull_ph' (default, "
                          "exp(beta) is a hazard ratio), 'weibull', "
                          "'lognormal' or 'loglogistic' (AFT, exp(beta) is a "
                          "time ratio).",
                "default_roles": "Allowed structural roles per variable. "
                                 "Roles 6 (ZI), 7 and 8 (LC membership) are "
                                 "structurally excluded for survival.",
                "fixed_override": "Force or restrict roles for specific variables.",
            },
        }

    @staticmethod
    def get_family_capabilities() -> Dict[str, Dict[str, bool]]:
        return {
            "count": {
                "jax_solver": True,
                "metaheuristic_search": True,
                "random_parameters": True,
                "heterogeneity_in_means": True,
                "zero_inflation": True,
                "latent_classes": True,
                "distribution_assumptions": True,
            },
            "cmf": {
                "jax_solver": True,
                "metaheuristic_search": True,
                "random_parameters": True,
                "heterogeneity_in_means": True,
                "zero_inflation": True,
                "latent_classes": True,
                "distribution_assumptions": True,
            },
            "duration": {
                "jax_solver": True,
                "metaheuristic_search": True,
                "random_parameters": True,
                "heterogeneity_in_means": True,
                "zero_inflation": True,
                "latent_classes": True,
                "distribution_assumptions": True,
            },
            "linear": {
                "jax_solver": True,
                "metaheuristic_search": True,
                "random_parameters": True,
                "heterogeneity_in_means": True,
                "zero_inflation": True,
                "latent_classes": True,
                "distribution_assumptions": True,
            },
            "survival": {
                "jax_solver": True,
                "metaheuristic_search": True,
                "random_parameters": True,
                "heterogeneity_in_means": True,
                # Censoring is the structural-zero mechanism, so there is no
                # zero-inflation block.
                "zero_inflation": False,
                # Latent classes are forced off (the LC estimation path is
                # count-specific); the survival likelihood itself supports
                # them, but the search does not yet wire them up.
                "latent_classes": False,
                "distribution_assumptions": True,
            },
            "hazard": {
                "jax_solver": True,
                "metaheuristic_search": True,
                "random_parameters": True,
                "heterogeneity_in_means": True,
                "zero_inflation": False,
                "latent_classes": False,
                "distribution_assumptions": True,
            },
            "aft": {
                "jax_solver": True,
                "metaheuristic_search": True,
                "random_parameters": True,
                "heterogeneity_in_means": True,
                "zero_inflation": False,
                "latent_classes": False,
                "distribution_assumptions": True,
            },
        }

    def make_manual_spec(
        self,
        fixed_terms: Optional[List[str]] = None,
        rdm_terms: Optional[List[str]] = None,
        rdm_cor_terms: Optional[List[str]] = None,
        grouped_terms: Optional[List[str]] = None,
        hetro_in_means: Optional[List[str]] = None,
        zi_terms: Optional[List[str]] = None,
        membership_terms: Optional[List[str]] = None,
        dispersion: int = 0,
        latent_classes: int = 1,
        group_id_col: Optional[str] = None,
    ) -> Dict[str, Any]:
        role_columns = {
            "fixed_terms": fixed_terms or [],
            "rdm_terms": rdm_terms or [],
            "rdm_cor_terms": rdm_cor_terms or [],
            "grouped_terms": grouped_terms or [],
            "hetro_in_means": hetro_in_means or [],
            "zi_terms": zi_terms or [],
            "membership_terms": membership_terms or [],
        }

        for label, terms in role_columns.items():
            stripped = [term.split(":")[0] for term in terms]
            self._ensure_columns_exist(stripped, label)

        if latent_classes < 1:
            raise ValueError("latent_classes must be at least 1.")

        if group_id_col is not None and group_id_col not in self.df.columns:
            raise ValueError(f"group_id_col '{group_id_col}' is not in the dataframe.")

        return {
            **role_columns,
            "dispersion": int(dispersion),
            "latent_classes": int(latent_classes),
            "group_id_col": group_id_col if group_id_col is not None else self.group_id_col,
        }

    def fit_manual_model(
        self,
        manual_spec: Dict[str, Any],
        model: str = "poisson",
        df: Optional[pd.DataFrame] = None,
        R: int = 200,
        print_report: bool = False,
        use_prefit_start: bool = True,
        continuous_de_warm_start: bool = True,
        use_slsqp: bool = True,
        de_maxiter: int = 12,
        de_popsize: int = 8,
        de_rel_span: float = 1.5,
        de_abs_span: float = 1.0,
        de_seed: int = 0,
        latent_fast_mode: bool = False,
        latent_random_start: bool = False,
        lower_level_param_bounds: Optional[tuple[float, float]] = None,
        _lc_fallback_applied: bool = False,
    ) -> Dict[str, Any]:
        de_report: dict[str, Any] = {
            "enabled": bool(continuous_de_warm_start),
            "single_class": None,
            "latent_class_seed": None,
            "latent_class_attempts": [],
        }

        df_fit = self.df if df is None else df
        data, spec = build_model_from_manual_spec(
            df=df_fit,
            manual_spec=manual_spec,
            id_col=self.id_col,
            y_col=self.y_col,
            offset_col=self.offset_col,
            R=R,
            event_col=self.event_col,
        )
        spec = replace(spec, model=model)

        # ── Survival / hazard: entirely separate fitting path ──────────
        # The count machinery below is hard-wired to CountModel /
        # mixed_model_loglik, which has no notion of right-censoring (it
        # raises "Unknown model: weibull_ph" and would silently treat every
        # censored row as an event if it did not).  Branch out before any
        # of that runs rather than patching the objective later.
        _surv_family = _survival_family_for(spec.model)
        if _surv_family is not None:
            if self.event_col is None:
                raise ValueError(
                    "survival/hazard refit needs an event_col on the builder "
                    "(ExperimentBuilder(..., event_col='<0/1 flag column>'))"
                )
            if "event" not in data:
                raise ValueError("data['event'] missing for a survival spec")
            from .survival_models import SurvivalModel
            from .survival_models import survival_mixed_model_loglik as _smll

            # No zero-inflation and no latent classes: censoring is the only
            # structural-zero mechanism, and the LC path is count-specific.
            spec = replace(spec, zero_inflated=False, latent_classes=1)
            _sm = SurvivalModel(spec=spec, data=data, family=_surv_family,
                                maxiter=1500, n_restarts=2)
            _sm.fit()
            _obj = partial(_smll, data=data, spec=spec, family=_surv_family)
            _pidx = build_param_index(spec)

            buf_s = io.StringIO()
            with redirect_stdout(buf_s):
                _named = _survival_summary_df(
                    result=_sm, objective=_obj, data=data, spec=spec,
                    param_index=_pidx, family=_surv_family,
                )
            summary_text = buf_s.getvalue()
            if print_report:
                print(summary_text, end="")
            _co = _named_coefs_from_df(_named)
            _stats = _named.attrs.get("fit_stats", {})
            return FitResult({
                "result": _sm,
                "data": data,
                "spec": spec,
                "manual_spec": manual_spec,
                "summary": _stats,
                "param_index": _pidx,
                "predictions": None,
                "de_warm_start_report": {},
                "coef_table": _named,
                "coefficient_names": _co["names"],
                "params": _co["params"],
                "bse": _co["bse"],
                "tvalues": _co["tvalues"],
                "pvalues": _co["pvalues"],
                "variable_coefs": _variable_coefs(_co),
                "survival_family": _surv_family,
                "ratio_kind": (
                    "hazard_ratio" if _surv_family in _ph_families()
                    else "time_ratio"
                ),
                "random_parameter_diagnostics": {},
                "random_parameter_identified": True,
                "random_parameter_identification_reason": "",
                "optimization_trace": None,
                "_summary_text": summary_text,
            })

        # Harden latent-class estimation with warm start + EM + polish retries.
        if spec.latent_classes > 1:
            C = int(spec.latent_classes)
            K_mem = int(spec.K_membership)
            spec_1 = replace(spec, latent_classes=1)
            K_base = build_param_index(spec_1)["total_params"]
            spec_c = replace(spec, latent_classes=C)
            pindex_c = build_param_index(spec_c)
            _class_K_base_fit = list(pindex_c.get("class_K_base", [K_base] * C))

            has_random_structure = any([
                bool(manual_spec.get("rdm_terms")),
                bool(manual_spec.get("rdm_cor_terms")),
                bool(manual_spec.get("grouped_terms")),
                bool(manual_spec.get("hetro_in_means")),
            ])

            if latent_random_start:
                rng0 = np.random.default_rng(int(de_seed))
                theta_1 = rng0.normal(0.0, 0.1, int(K_base))  # single-class warm-start size
                de_report["single_class"] = {
                    "ran": False,
                    "accepted": False,
                    "reason": "latent_random_start",
                    "start_obj": None,
                    "de_obj": None,
                    "delta_obj": None,
                    "final_obj": None,
                }
            else:
                model_1 = CountModel(spec_1, data)
                try:
                    if model == "tobit":
                        # Bypass Poisson-style prefit: use OLS starting values
                        # and a direct LBFGS on the single-class Tobit likelihood.
                        _K1 = build_base_index(spec_1)["total_params"]
                        _p0, de_report_single = self._continuous_de_warm_start(
                            objective=lambda p: mixed_model_loglik(p, data, spec_1),
                            init_params=_tobit_ols_init(data, _K1),
                            enabled=continuous_de_warm_start,
                            maxiter=de_maxiter,
                            popsize=de_popsize,
                            rel_span=de_rel_span,
                            abs_span=de_abs_span,
                            seed=de_seed,
                        )
                        de_report["single_class"] = de_report_single
                        _sol = LBFGS(
                            fun=lambda p: mixed_model_loglik(p, data, spec_1),
                            maxiter=1000,
                        ).run(jnp.array(_p0))
                        result_1 = _sol
                    else:
                        model_1._use_slsqp = use_slsqp
                        result_1 = model_1.fit(
                            use_prefit=use_prefit_start,
                            use_continuous_de=continuous_de_warm_start,
                            de_maxiter=de_maxiter,
                            de_popsize=de_popsize,
                            de_rel_span=de_rel_span,
                            de_abs_span=de_abs_span,
                            de_seed=de_seed,
                        )
                        de_report["single_class"] = getattr(model_1, "last_de_report", None)
                except Exception as exc:
                    if (not _lc_fallback_applied) and has_random_structure:
                        fallback_spec = dict(manual_spec)
                        fallback_spec["rdm_terms"] = []
                        fallback_spec["rdm_cor_terms"] = []
                        fallback_spec["grouped_terms"] = []
                        fallback_spec["hetro_in_means"] = []
                        warnings.warn(
                            "Latent-class warm-start failed on random-effect structure; "
                            "retrying with fixed-only latent-class fallback.",
                            RuntimeWarning,
                            stacklevel=2,
                        )
                        return self.fit_manual_model(
                            manual_spec=fallback_spec,
                            model=model,
                            df=df,
                            R=R,
                            print_report=print_report,
                            use_prefit_start=use_prefit_start,
                            continuous_de_warm_start=continuous_de_warm_start,
                            de_maxiter=de_maxiter,
                            de_popsize=de_popsize,
                            de_rel_span=de_rel_span,
                            de_abs_span=de_abs_span,
                            de_seed=de_seed,
                            latent_fast_mode=latent_fast_mode,
                            latent_random_start=latent_random_start,
                            lower_level_param_bounds=lower_level_param_bounds,
                            _lc_fallback_applied=True,
                        )
                    raise

                theta_1 = np.asarray(result_1.params)

            best_result = None
            best_value = np.inf
            last_error: Optional[Exception] = None

            # Attempt 0 uses cluster-based seeding; remaining attempts fall
            # back to decreasing noise perturbations of the single-class fit.

            # Always guarantee at least some noise for all but the last fallback
            if latent_fast_mode:
                retry_configs = [("random", 0)] if latent_random_start else [(0.02, 0)]
                em_max_iter = 10
                polish_maxiter = 200
            else:
                retry_configs = [
                    ("cluster", 0),
                    (0.05, 1),
                    (0.02, 2),
                    (0.01, 3),  # never zero noise except as a last fallback
                    ("force_min_noise", 4),  # last fallback: forcibly add small noise if all else fails
                ]
                em_max_iter = 40
                polish_maxiter = 800

            for noise_scale, seed in retry_configs:
                try:
                    rng = np.random.default_rng(seed)
                    if noise_scale == "random":
                        theta_init = np.concatenate([
                            rng.normal(0.0, 0.1, k) + 1e-3 * (i + 1)
                            for i, k in enumerate(_class_K_base_fit)
                        ])
                    elif noise_scale == "cluster":
                        try:
                            per_class = _seed_classes_from_clusters(
                                theta_1, data, spec_1, C, K_base, rng,
                                class_K_base=_class_K_base_fit,
                            )
                            theta_init = np.concatenate(per_class)
                        except Exception:
                            # fallback: add moderate noise
                            theta_init = np.concatenate([
                                theta_1[:k] + rng.normal(0.0, 0.05, k)
                                if len(theta_1) >= k
                                else np.pad(theta_1, (0, k - len(theta_1))) + rng.normal(0.0, 0.05, k)
                                for k in _class_K_base_fit
                            ])
                    elif noise_scale == "force_min_noise":
                        # forcibly guarantee different initializations
                        theta_init = np.concatenate([
                            (theta_1[:k] if len(theta_1) >= k else np.pad(theta_1, (0, k - len(theta_1))))
                            + rng.normal(0.0, 0.01, k) + 0.01 * (i+1)
                            for i, k in enumerate(_class_K_base_fit)
                        ])
                    else:
                        # always add noise, never allow all classes to be identical
                        theta_init = np.concatenate([
                            (theta_1[:k] if len(theta_1) >= k else np.pad(theta_1, (0, k - len(theta_1))))
                            + rng.normal(0.0, noise_scale, k) + 1e-4 * (i+1)
                            for i, k in enumerate(_class_K_base_fit)
                        ])

                    # Check: if all classes are still identical, forcibly add small offset
                    # (only works when all classes have same K_base)
                    if len(set(_class_K_base_fit)) == 1:
                        theta_blocks = np.split(theta_init, C)
                        if all(np.allclose(theta_blocks[0], tb) for tb in theta_blocks[1:]):
                            for i in range(1, C):
                                theta_blocks[i] = theta_blocks[i] + 1e-3 * i
                            theta_init = np.concatenate(theta_blocks)

                    gamma_init = np.zeros((C - 1) * (K_mem + 1), dtype=float)
                    init_params = np.concatenate([theta_init, gamma_init])

                    try:
                        init_obj = float(mixed_model_loglik(jnp.array(init_params), data, spec_c))
                    except Exception:
                        init_obj = None

                    try:
                        params_em = run_with_oom_recovery(
                            fit_em,
                            init_params=init_params,
                            data=data,
                            spec=spec_c,
                            max_iter=em_max_iter,
                            tol=1e-4,
                            verbose=False,
                            label="manual CMF EM",
                        )
                    except Exception:
                        params_em = init_params

                    polish_seed, de_report_lc = self._continuous_de_warm_start(
                        objective=lambda p: mixed_model_loglik(p, data, spec_c),
                        init_params=np.asarray(params_em),
                        enabled=continuous_de_warm_start,
                        maxiter=de_maxiter,
                        popsize=de_popsize,
                        rel_span=de_rel_span,
                        abs_span=de_abs_span,
                        seed=de_seed + int(seed),
                    )
                    de_report_lc["attempt"] = int(seed)
                    de_report_lc["noise_scale"] = str(noise_scale)
                    de_report_lc["init_obj"] = init_obj
                    try:
                        de_report_lc["seed_obj"] = float(mixed_model_loglik(jnp.array(polish_seed), data, spec_c))
                    except Exception:
                        de_report_lc["seed_obj"] = None
                    de_report["latent_class_attempts"].append(de_report_lc)

                    polish = LBFGS(
                        fun=lambda p: mixed_model_loglik(p, data, spec_c),
                        maxiter=polish_maxiter,
                    )
                    candidate = polish.run(jnp.array(polish_seed))

                    params_np = np.asarray(candidate.params)
                    value = float(mixed_model_loglik(jnp.array(params_np), data, spec_c))
                    de_report_lc["final_obj"] = value

                    if not np.all(np.isfinite(params_np)):
                        continue
                    if not np.isfinite(value):
                        continue

                    if value < best_value:
                        best_value = value
                        best_result = candidate
                        de_report["latent_class_seed"] = de_report_lc

                except Exception as exc:
                    last_error = exc

            if best_result is None:
                if not _lc_fallback_applied:
                    if has_random_structure:
                        fallback_spec = dict(manual_spec)
                        fallback_spec["rdm_terms"] = []
                        fallback_spec["rdm_cor_terms"] = []
                        fallback_spec["grouped_terms"] = []
                        fallback_spec["hetro_in_means"] = []
                        warnings.warn(
                            "Latent-class manual fit failed on random-effect structure; "
                            "retrying with fixed-only latent-class fallback.",
                            RuntimeWarning,
                            stacklevel=2,
                        )
                        return self.fit_manual_model(
                            manual_spec=fallback_spec,
                            model=model,
                            df=df,
                            R=R,
                            print_report=print_report,
                            use_prefit_start=use_prefit_start,
                            continuous_de_warm_start=continuous_de_warm_start,
                            de_maxiter=de_maxiter,
                            de_popsize=de_popsize,
                            de_rel_span=de_rel_span,
                            de_abs_span=de_abs_span,
                            de_seed=de_seed,
                            lower_level_param_bounds=lower_level_param_bounds,
                            _lc_fallback_applied=True,
                        )

                if last_error is not None:
                    raise RuntimeError(
                        "Latent-class manual fit failed after robust retries. "
                        "Try simpler random-effects structure or fewer latent classes."
                    ) from last_error
                raise RuntimeError(
                    "Latent-class manual fit failed after robust retries with non-finite objective/parameters."
                )

            result = best_result
            fitted = CountModel(spec_c, data)
            fitted.params = np.asarray(result.params)
            spec = spec_c
        else:
            fitted = CountModel(spec, data)
            if model == "tobit":
                # OLS warm-start + direct LBFGS — bypasses Poisson-style prefit.
                _K = build_base_index(spec)["total_params"]
                _p0, de_report_single = self._continuous_de_warm_start(
                    objective=lambda p: mixed_model_loglik(p, data, spec),
                    init_params=_tobit_ols_init(data, _K),
                    enabled=continuous_de_warm_start,
                    maxiter=de_maxiter,
                    popsize=de_popsize,
                    rel_span=de_rel_span,
                    abs_span=de_abs_span,
                    seed=de_seed,
                )
                de_report["single_class"] = de_report_single
                _sol = LBFGS(
                    fun=lambda p: mixed_model_loglik(p, data, spec),
                    maxiter=1500,
                ).run(jnp.array(_p0))
                result = _sol
                fitted.params = np.asarray(_sol.params)
            else:
                result = fitted.fit(
                    use_prefit=use_prefit_start,
                    use_continuous_de=continuous_de_warm_start,
                    de_maxiter=de_maxiter,
                    de_popsize=de_popsize,
                    de_rel_span=de_rel_span,
                    de_abs_span=de_abs_span,
                    de_seed=de_seed,
                )
                de_report["single_class"] = getattr(fitted, "last_de_report", None)

        if lower_level_param_bounds is not None:
            cmf_bounds, constrained = self._build_cmf_local_bounds(spec, lower_level_param_bounds)
            if constrained > 0:
                current_params = np.asarray(
                    result.params if hasattr(result, "params") else fitted.params,
                    dtype=float,
                )
                bounded_params = self._bounded_refit(
                    objective=lambda p: mixed_model_loglik(p, data, spec),
                    start_params=current_params,
                    bounds=cmf_bounds,
                    maxiter=600,
                )
                fitted.params = np.asarray(bounded_params)

                class _BoundedResult:
                    pass

                bounded_result = _BoundedResult()
                bounded_result.params = np.asarray(bounded_params)
                result = bounded_result

        objective = partial(mixed_model_loglik, data=data, spec=spec)
        param_index = build_param_index(spec)
        random_parameter_diagnostics = random_parameter_convergence_diagnostics(
            result.params,
            objective,
            spec,
            param_index,
        )
        (
            random_parameter_identified,
            random_parameter_identification_reason,
        ) = random_parameter_identification_status(random_parameter_diagnostics)

        buf = io.StringIO()
        with redirect_stdout(buf):
            named = None
            if _surv_family is not None:
                # The generic print_summary applies PARTE shrinkage and
                # count-model delta transforms, neither of which is defined
                # for a log-hazard parameterisation.  Build the named table
                # straight from the survival objective instead, and add an
                # explicit hazard/time-ratio column.
                named = _survival_summary_df(
                    result=result, objective=objective, data=data,
                    spec=spec, param_index=param_index,
                    family=_surv_family,
                )
                summary = named.attrs.get("fit_stats", {})
            else:
                try:
                    named = print_summary(
                        result=result,
                        objective=objective,
                        data=data,
                        spec=spec,
                        param_index=param_index,
                        return_df=True,
                    )
                    summary = named
                except TypeError:
                    # print_summary variant without return_df support
                    summary = print_summary(
                        result=result,
                        objective=objective,
                        data=data,
                        spec=spec,
                        param_index=param_index,
                    )
        summary_text = buf.getvalue()
        if print_report:
            print(summary_text, end="")

        if isinstance(summary, dict):
            summary["random_parameter_identified"] = bool(
                random_parameter_identified
            )
            summary["random_parameter_identification_reason"] = (
                random_parameter_identification_reason
            )

        # Named estimates/SEs/p-values so callers never have to scrape
        # summary_text.  print_summary returns the fit-stats dict unless
        # return_df is honoured, so tolerate either shape here.  fit["summary"]
        # keeps its original meaning (the fit-stats dict) either way.
        named_df = named if hasattr(named, "columns") else None
        if named_df is not None:
            stashed = named_df.attrs.get("fit_stats")
            summary = stashed if isinstance(stashed, dict) and stashed else \
                _fit_stats_from(objective, result, data)
        coefs = _named_coefs_from_df(named_df)
        if coefs is None:
            coefs = {"names": [], "params": {}, "bse": {},
                     "tvalues": {}, "pvalues": {}}

        return FitResult({
            "result": result,
            "data": data,
            "spec": spec,
            "manual_spec": manual_spec,
            "summary": summary,
            "param_index": param_index,
            "predictions": (
                np.asarray(fitted.predict()).squeeze() if fitted is not None
                else np.asarray(
                    _smll(result.params if hasattr(result, "params") else result.x,
                          data, spec, _surv_family)
                ).squeeze() if _surv_family is not None else None
            ),
            "de_warm_start_report": de_report,
            "coef_table": named_df,
            "coefficient_names": coefs["names"],
            "params": coefs["params"],
            "bse": coefs["bse"],
            "tvalues": coefs["tvalues"],
            "pvalues": coefs["pvalues"],
            "variable_coefs": _variable_coefs(coefs),
            "survival_family": _surv_family,
            "ratio_kind": (
                "hazard_ratio" if (_surv_family in _ph_families() or _surv_family is None)
                else "time_ratio"
            ) if _surv_family is not None else None,
            "random_parameter_diagnostics": random_parameter_diagnostics,
            "random_parameter_identified": bool(random_parameter_identified),
            "random_parameter_identification_reason": (
                random_parameter_identification_reason
            ),
            "optimization_trace": getattr(fitted, "last_optimization_trace", None),
            "_summary_text": summary_text,
        })

    def compute_latent_class_probabilities(
        self,
        fit_result: Dict[str, Any],
        true_class_col: Optional[str] = None,
    ) -> pd.DataFrame:
        spec = fit_result["spec"]
        if spec.latent_classes <= 1:
            raise ValueError("Latent class probabilities require a fit with latent_classes > 1.")

        data = fit_result["data"]
        params = np.asarray(fit_result["result"].params)
        C = spec.latent_classes
        K_mem = spec.K_membership
        base_spec = replace(spec, latent_classes=1)
        pindex = build_param_index(spec)
        class_offsets = list(pindex.get("class_offsets", [i * build_param_index(base_spec)["total_params"] for i in range(C)]))
        class_K_base  = list(pindex.get("class_K_base", [build_param_index(base_spec)["total_params"]] * C))
        total_theta = class_offsets[-1] + class_K_base[-1] if C > 0 else 0
        gamma_size = (C - 1) * (K_mem + 1)
        gamma_raw = params[total_theta : total_theta + gamma_size]
        if len(gamma_raw) >= gamma_size:
            gamma = gamma_raw[:gamma_size].reshape(C - 1, K_mem + 1)
        else:
            gamma = np.zeros((C - 1, K_mem + 1))
            if len(gamma_raw) > 0:
                gamma.flat[:len(gamma_raw)] = gamma_raw

        n = data["y"].shape[0]
        if K_mem > 0:
            z = np.mean(np.asarray(data["Xmem"]), axis=1)
            z_full = np.concatenate([np.ones((n, 1)), z], axis=1)
        else:
            z_full = np.ones((n, 1))

        logits = z_full @ gamma.T
        logits_full = np.concatenate([np.zeros((n, 1)), logits], axis=1)
        logits_full = logits_full - logits_full.max(axis=1, keepdims=True)
        probs = np.exp(logits_full)
        probs = probs / probs.sum(axis=1, keepdims=True)

        ids = np.asarray(data.get("ids", self.df[[self.id_col]].drop_duplicates()[self.id_col].to_numpy()))
        out = pd.DataFrame({self.id_col: ids})
        for idx in range(C):
            out[f"class_{idx + 1}_prob"] = probs[:, idx]
        out = out.drop_duplicates(subset=[self.id_col]).reset_index(drop=True)

        if true_class_col is not None:
            self._ensure_columns_exist([true_class_col], "true_class_col")
            truth = self.df[[self.id_col, true_class_col]].drop_duplicates(subset=[self.id_col])
            out = out.merge(truth, on=self.id_col, how="left")
        return out

    def print_coefficients(self, fit_result: Dict[str, Any]) -> pd.DataFrame:
        """
        Efficiently print model coefficients from a fitted model.

        After calling fit_manual_model(), pass the result to this method to
        display a clean coefficient table with estimates and standard errors.

        Parameters
        ----------
        fit_result
            Dictionary returned by fit_manual_model()

        Returns
        -------
        pd.DataFrame
            Coefficient table as a DataFrame

        Example
        -------
        best_spec = evaluator.build_spec(result_full["best_solution"])
        fit_full = builder.fit_manual_model(manual_spec=best_spec, model="nb")
        coef_table = builder.print_coefficients(fit_full)
        print(coef_table)
        """
        spec = fit_result["spec"]
        result = fit_result["result"]
        param_index = fit_result["param_index"]
        params = np.asarray(result.params)

        # Build coefficient table with fixed, random, and dispersion parameters
        coef_rows = []

        def _add_rows(index_map: Dict[str, Any], local_params: np.ndarray, class_label: Optional[str] = None) -> None:
            label_suffix = f" [{class_label}]" if class_label else ""

            # ── Fixed coefficients ─────────────────────────────────────
            if spec.Kf > 0 and "fixed" in index_map:
                fixed_names = list(spec.fixed_names)
                fixed_start, fixed_end = index_map["fixed"]
                for name, value in zip(fixed_names, local_params[fixed_start:fixed_end]):
                    coef_rows.append({
                        "Parameter": f"{name}{label_suffix}",
                        "Type": "Fixed" if class_label is None else f"Fixed ({class_label})",
                        "Estimate": value,
                    })

            # ── Random independent (means) ─────────────────────────────
            if spec.Kr_ind > 0:
                ind_names = list(spec.random_ind_names)
                if "ind_mean" in index_map:
                    mean_start, mean_end = index_map["ind_mean"]
                    for name, value in zip(ind_names, local_params[mean_start:mean_end]):
                        coef_rows.append({
                            "Parameter": f"{name} (ind. mean){label_suffix}",
                            "Type": "Random-Ind" if class_label is None else f"Random-Ind ({class_label})",
                            "Estimate": value,
                        })

                if "ind_sd" in index_map:
                    sd_start, sd_end = index_map["ind_sd"]
                    for name, value in zip(ind_names, local_params[sd_start:sd_end]):
                        coef_rows.append({
                            "Parameter": f"{name} (ind. SD){label_suffix}",
                            "Type": "Random-Ind" if class_label is None else f"Random-Ind ({class_label})",
                            "Estimate": value,
                        })

            # ── Random correlated (means) ──────────────────────────────
            if spec.Kr_cor > 0:
                cor_names = list(spec.random_cor_names)
                if "cor_mean" in index_map:
                    mean_start, mean_end = index_map["cor_mean"]
                    for name, value in zip(cor_names, local_params[mean_start:mean_end]):
                        coef_rows.append({
                            "Parameter": f"{name} (cor. mean){label_suffix}",
                            "Type": "Random-Cor" if class_label is None else f"Random-Cor ({class_label})",
                            "Estimate": value,
                        })

            # ── Grouped effects ────────────────────────────────────────
            if spec.Kg > 0:
                grouped_names = list(spec.grouped_names)
                if "group_mean" in index_map:
                    mean_start, mean_end = index_map["group_mean"]
                    for name, value in zip(grouped_names, local_params[mean_start:mean_end]):
                        coef_rows.append({
                            "Parameter": f"{name} (group mean){label_suffix}",
                            "Type": "Grouped" if class_label is None else f"Grouped ({class_label})",
                            "Estimate": value,
                        })

                if "group_sd" in index_map:
                    sd_start, sd_end = index_map["group_sd"]
                    for name, value in zip(grouped_names, local_params[sd_start:sd_end]):
                        coef_rows.append({
                            "Parameter": f"{name} (group SD){label_suffix}",
                            "Type": "Grouped" if class_label is None else f"Grouped ({class_label})",
                            "Estimate": value,
                        })

            # ── Dispersion parameter (for negative binomial) ───────────
            if spec.model == "nb" and "dispersion" in index_map:
                disp_idx = index_map["dispersion"]
                coef_rows.append({
                    "Parameter": f"Dispersion{label_suffix}",
                    "Type": "Dispersion" if class_label is None else f"Dispersion ({class_label})",
                    "Estimate": local_params[disp_idx],
                })

        if spec.latent_classes > 1 and "class_params" in param_index:
            base_spec = replace(spec, latent_classes=1)
            C = int(spec.latent_classes)
            _class_offsets = param_index.get("class_offsets", tuple(i * param_index.get("K_base", param_index["total_params"] // C) for i in range(C)))
            _class_K_base  = param_index.get("class_K_base", (param_index.get("K_base", param_index["total_params"] // C),) * C)

            for c in range(C):
                oc = _class_offsets[c]
                kc = _class_K_base[c]
                class_slice = params[oc:oc + kc]
                _base_idx_c = build_base_index(base_spec, model=param_index.get("class_models", (base_spec.model,) * C)[c])
                _add_rows(_base_idx_c, class_slice, class_label=f"Class {c + 1}")

            class_params_end = param_index["class_params"][1]
            logits_tail = params[class_params_end:]
            if logits_tail.size > 0:
                for idx, value in enumerate(logits_tail, start=1):
                    coef_rows.append({
                        "Parameter": f"Class logit gamma {idx}",
                        "Type": "Class-Logits",
                        "Estimate": value,
                    })
        else:
            _add_rows(param_index, params)

        # Build DataFrame and print
        coef_df = pd.DataFrame(coef_rows)

        print("\n" + "=" * 80)
        print(f"  MODEL COEFFICIENTS  —  {spec.model.upper()} MODEL")
        print("=" * 80 + "\n")

        if len(coef_df) > 0:
            # Group by type for better readability
            for type_name in ["Fixed", "Random-Ind", "Random-Cor", "Grouped", "Dispersion", "Class-Logits"]:
                subset = coef_df[coef_df["Type"] == type_name]
                if len(subset) > 0:
                    print(f"  {type_name.upper()} PARAMETERS:")
                    print(f"  {'-' * 76}")
                    for _, row in subset.iterrows():
                        print(f"    {row['Parameter']:30s} = {row['Estimate']:+.6f}")
                    print()

            # Print latent-class blocks when present.
            class_types = [t for t in coef_df["Type"].unique() if "Class" in str(t) and t != "Class-Logits"]
            for type_name in class_types:
                subset = coef_df[coef_df["Type"] == type_name]
                if len(subset) > 0:
                    print(f"  {str(type_name).upper()} PARAMETERS:")
                    print(f"  {'-' * 76}")
                    for _, row in subset.iterrows():
                        print(f"    {row['Parameter']:30s} = {row['Estimate']:+.6f}")
                    print()

        print("=" * 80 + "\n")

        return coef_df[["Parameter", "Type", "Estimate"]]

    # ── print_cmf_interpretation ────────────────────────────────────

    def print_cmf_interpretation(self, fit_result: Dict[str, Any], aadt_col: Optional[str] = None, aadt_median: Optional[float] = None) -> pd.DataFrame:
        """
        Print CMF (Crash Modification Factor) interpretations for fitted model coefficients.

        For each fixed coefficient, this method computes and displays:
        - The coefficient value (β)
        - The CMF for a one-unit increase: CMF = exp(β)
        - The percent change: 100 × (exp(β) - 1)
        - Plain-language interpretation

        Parameters
        ----------
        fit_result
            Dictionary returned by fit_manual_model()
        aadt_col
            Optional: Column name containing AADT values for context.
            If provided, AADT-dependent interpretations are generated.
        aadt_median
            Optional: Median AADT value for computing traffic-dependent effects.
            If not provided, will compute from aadt_col if available.

        Returns
        -------
        pd.DataFrame
            CMF interpretation table with columns:
            - Parameter: Coefficient name
            - Coefficient: Estimated value (β)
            - CMF (+1): exp(β) for one-unit increase
            - Percent Change: 100 × (exp(β) - 1)
            - Interpretation: Plain-language explanation

        Example
        -------
        cmf_table = builder.print_cmf_interpretation(
            fit_result=fit_result,
            aadt_col='AADT',
            aadt_median=23771
        )
        print(cmf_table)
        """
        import math
        
        spec = fit_result["spec"]
        result = fit_result["result"]
        param_index = fit_result["param_index"]
        params = np.asarray(result.params)

        # Compute AADT median if provided column but no explicit median
        if aadt_col is not None and aadt_col in self.df.columns and aadt_median is None:
            aadt_median = self.df[aadt_col].median()

        cmf_rows = []

        def _extract_fixed_coefs(index_map: Dict[str, Any], local_params: np.ndarray, class_label: Optional[str] = None) -> None:
            label_suffix = f" [{class_label}]" if class_label else ""

            if spec.Kf > 0 and "fixed" in index_map:
                fixed_names = list(spec.fixed_names)
                fixed_start, fixed_end = index_map["fixed"]
                
                for name, value in zip(fixed_names, local_params[fixed_start:fixed_end]):
                    try:
                        if str(name) == "__INTERCEPT__":
                            continue

                        coef_value = float(value)
                        
                        # Compute CMF for one-unit change
                        if math.isfinite(coef_value):
                            cmf_one_unit = math.exp(max(min(coef_value, 700.0), -700.0))
                            percent_change = 100.0 * (cmf_one_unit - 1.0)
                            
                            # Generate interpretation
                            lower_name = str(name).lower()
                            is_cmf_local_term = "__cmf_local__" in lower_name
                            is_log_aadt_term = "__cmf_log_aadt" in lower_name or lower_name == "aadt"

                            aadt_context = ""
                            if is_log_aadt_term:
                                interpretation = (
                                    f"{name}: traffic elasticity = {coef_value:+.4f}; "
                                    f"1% AADT change implies about {coef_value:+.2f}% crash change"
                                )
                            elif is_cmf_local_term and aadt_median is not None and aadt_median > 0:
                                try:
                                    exponent = max(min(coef_value * math.log(aadt_median), 700.0), -700.0)
                                    aadt_effect = 100.0 * (math.exp(exponent) - 1.0)
                                    aadt_context = f" (at median AADT {aadt_median:,.0f}: {aadt_effect:+.2f}%)"
                                except (ValueError, OverflowError):
                                    pass
                                interpretation = f"{name} +1 adjusts AADT-response scaling{aadt_context}"
                            else:
                                if percent_change < 0:
                                    interpretation = f"{name} +1 → {percent_change:.2f}% crashes (safer)"
                                elif percent_change > 0:
                                    interpretation = f"{name} +1 → +{percent_change:.2f}% crashes (riskier)"
                                else:
                                    interpretation = f"{name} +1 → No change (neutral)"
                            
                            cmf_rows.append({
                                "Parameter": f"{name}{label_suffix}",
                                "Type": "Fixed" if class_label is None else f"Fixed ({class_label})",
                                "Coefficient": coef_value,
                                "CMF(+1)": cmf_one_unit,
                                "Percent Change": percent_change,
                                "Interpretation": interpretation,
                            })
                    except (ValueError, OverflowError):
                        pass

        if spec.latent_classes > 1 and "class_params" in param_index:
            base_spec = replace(spec, latent_classes=1)
            C = int(spec.latent_classes)
            _class_offsets = param_index.get("class_offsets", tuple(i * param_index.get("K_base", param_index["total_params"] // C) for i in range(C)))
            _class_K_base  = param_index.get("class_K_base", (param_index.get("K_base", param_index["total_params"] // C),) * C)

            for c in range(C):
                oc = _class_offsets[c]
                kc = _class_K_base[c]
                class_slice = params[oc:oc + kc]
                _base_idx_c = build_base_index(base_spec, model=param_index.get("class_models", (base_spec.model,) * C)[c])
                _extract_fixed_coefs(_base_idx_c, class_slice, class_label=f"Class {c + 1}")
        else:
            _extract_fixed_coefs(param_index, params)

        cmf_df = pd.DataFrame(cmf_rows)

        print("\n" + "=" * 100)
        print(f"  CMF INTERPRETATIONS  —  {spec.model.upper()} MODEL")
        print("=" * 100 + "\n")

        if len(cmf_df) > 0:
            for _, row in cmf_df.iterrows():
                print(f"  {row['Parameter']:25s}")
                print(f"    Coefficient (β)     : {row['Coefficient']:+.6f}")
                print(f"    CMF for +1 unit     : {row['CMF(+1)']:.4f}")
                print(f"    Percent Change      : {row['Percent Change']:+.2f}%")
                print(f"    ➜ {row['Interpretation']}")
                print()
        else:
            print("  (No fixed coefficients found for CMF interpretation)")
            print()

        print("=" * 100)
        print("  INTERPRETATION GUIDE:")
        print("  ─────────────────────────────────────────────────────────────────────────────────────────────────────")
        print("  CMF < 1.0  (Percent Change < 0)  →  Safer treatment (crashes decrease)")
        print("  CMF = 1.0  (Percent Change = 0)  →  Neutral effect (no change)")
        print("  CMF > 1.0  (Percent Change > 0)  →  Riskier treatment (crashes increase)")
        print("=" * 100 + "\n")

        return cmf_df[["Parameter", "Type", "Coefficient", "CMF(+1)", "Percent Change", "Interpretation"]]

    # ── validate_before_fit ─────────────────────────────────────────

    def validate_before_fit(
        self,
        variables: Optional[List[str]] = None,
        aadt_col: Optional[str] = None,
        vif_threshold: float = 10.0,
        raw_aadt_threshold: float = 500.0,
    ) -> dict:
        """
        Pre-fit data quality checks. Warns on:

          1. AADT / exposure columns that appear un-logged
             (median > raw_aadt_threshold → likely raw vehicle counts).
          2. High collinearity: VIF > vif_threshold for any variable pair.
          3. Near-constant or all-zero columns (zero-variance).
          4. Outcome variable: variance-to-mean ratio (overdispersion flag).

        Returns a dict with keys 'warnings' (list[str]) and 'vif_table'
        (pd.DataFrame or None).
        """
        cols = variables or self._candidate_vars
        warnings_out: List[str] = []

        print("\n" + "=" * 70)
        print("  PRE-FIT VALIDATION")
        print("=" * 70)

        # ── 1. AADT / exposure log-transform check ──────────────────
        aadt_candidates = []
        if aadt_col is not None:
            aadt_candidates = [aadt_col]
        else:
            aadt_candidates = [c for c in cols
                               if any(kw in c.upper()
                                      for kw in ("AADT", "ADT", "VOLUME", "EXPO", "FLOW"))]

        for col in aadt_candidates:
            if col not in self.df.columns:
                continue
            med = self.df[col].median()
            mn  = self.df[col].min()
            if med > raw_aadt_threshold and mn >= 0:
                msg = (
                    f"  [WARN] '{col}': median={med:,.0f}  min={mn:.2f}  "
                    f"→ looks like RAW traffic volume (not log-transformed). "
                    f"If this is AADT, apply log({col}) before fitting."
                )
                warnings.warn(msg, UserWarning, stacklevel=2)
                print(msg)
                warnings_out.append(msg)
            elif med < 0:
                print(f"  [OK]   '{col}': median={med:.3f}  (looks log-transformed)")
            else:
                print(f"  [OK]   '{col}': median={med:.3f}  "
                      f"(within reasonable range for a log-transformed or standardised variable)")

        # ── 2. Near-constant / zero-variance ────────────────────────
        for col in cols:
            if col not in self.df.columns:
                continue
            s = self.df[col]
            if s.nunique() <= 1:
                msg = f"  [WARN] '{col}': near-constant (nunique={s.nunique()}) — will be excluded automatically."
                warnings.warn(msg, UserWarning, stacklevel=2)
                print(msg)
                warnings_out.append(msg)

        # ── 3. VIF collinearity check ────────────────────────────────
        numeric_cols = [c for c in cols
                        if c in self.df.columns
                        and pd.api.types.is_numeric_dtype(self.df[c])
                        and self.df[c].nunique() > 1]

        vif_table = None
        if len(numeric_cols) >= 2:
            try:
                from statsmodels.stats.outliers_influence import variance_inflation_factor
                X = self.df[numeric_cols].dropna()
                X = (X - X.mean()) / X.std().replace(0, 1)  # standardise for VIF stability
                X_np = X.values
                vif_vals = [
                    variance_inflation_factor(X_np, i)
                    for i in range(X_np.shape[1])
                ]
                vif_table = pd.DataFrame({"variable": numeric_cols, "VIF": vif_vals})
                vif_table = vif_table.sort_values("VIF", ascending=False)

                print(f"\n  Variance Inflation Factors  (threshold={vif_threshold}):")
                print(f"  {'Variable':<25}  {'VIF':>8}")
                print("  " + "-" * 36)
                for _, row in vif_table.iterrows():
                    flag = "  ← HIGH COLLINEARITY" if row["VIF"] > vif_threshold else ""
                    print(f"  {row['variable']:<25}  {row['VIF']:>8.2f}{flag}")
                    if row["VIF"] > vif_threshold:
                        msg = (
                            f"  [WARN] '{row['variable']}': VIF={row['VIF']:.1f} > {vif_threshold} "
                            f"— consider dropping or orthogonalising this variable."
                        )
                        warnings.warn(msg, UserWarning, stacklevel=2)
                        warnings_out.append(msg)
            except ImportError:
                print("  [INFO] statsmodels not available — skipping VIF check.")
            except Exception as exc:
                print(f"  [INFO] VIF check skipped: {exc}")

        # ── 4. Outcome overdispersion ────────────────────────────────
        y = self.df[self.y_col]
        vr = y.var() / y.mean() if y.mean() > 0 else 0.0
        zero_pct = 100.0 * (y == 0).mean()
        print(f"\n  Outcome '{self.y_col}':  mean={y.mean():.3f}  "
              f"var/mean={vr:.2f}  zeros={zero_pct:.1f}%")
        if vr > 1.5:
            print("  [OK]   Overdispersed → NB2 (dispersion=1) recommended.")
        elif vr < 0.8:
            msg = (f"  [WARN] '{self.y_col}': var/mean={vr:.2f} < 1 "
                   f"— underdispersed; verify this is a count outcome.")
            warnings.warn(msg, UserWarning, stacklevel=2)
            print(msg)
            warnings_out.append(msg)
        else:
            print("  [OK]   Near-Poisson dispersion.")

        if len(warnings_out) == 0:
            print("\n  No issues found.")
        else:
            print(f"\n  {len(warnings_out)} warning(s) raised — review before fitting.")

        print("=" * 70 + "\n")

        return {"warnings": warnings_out, "vif_table": vif_table}

    # ── smoke_test ───────────────────────────────────────────────────

    def smoke_test(
        self,
        fixed_terms: Optional[List[str]] = None,
        model: str = "nb",
        latent_classes: int = 2,
        R: int = 50,
    ) -> bool:
        """
        Quick end-to-end smoke test of the fitting pipeline.

        Fits a small 2-class NB model on the first 3 fixed_terms (or
        the first 3 candidate variables) to verify the full chain:
          data prep → warm start → EM → LBFGS polish → summary

        Returns True on success, False on any exception.

        Usage::

            ok = builder.smoke_test()
            assert ok, "Fitting pipeline smoke test failed"
        """
        print("\n" + "=" * 70)
        print("  SMOKE TEST  —  fitting pipeline")
        print("=" * 70)

        terms = fixed_terms or self._candidate_vars[:3]
        terms = [t for t in terms if t in self.df.columns][:3]
        if len(terms) < 1:
            print("  [SKIP] No candidate variables available for smoke test.")
            return False

        spec = self.make_manual_spec(
            fixed_terms=terms,
            dispersion=1 if model == "nb" else 0,
            latent_classes=latent_classes,
        )

        print(f"  Spec: model={model}  classes={latent_classes}  "
              f"fixed_terms={terms}  R={R}")

        try:
            fit = self.fit_manual_model(manual_spec=spec, model=model, R=R,
                                        print_report=False)
            summary = fit.get("summary", {})
            ll  = summary.get("loglik", float("nan"))
            bic = summary.get("bic",    float("nan"))
            k   = summary.get("num_parm", "?")
            print(f"  Result : LL={ll:.2f}  k={k}  BIC={bic:.2f}")
            if not np.isfinite(bic):
                print("  [WARN] Non-finite BIC — optimizer may have diverged.")
                return False
            print("  PASS — fitting pipeline is operational.")
            print("=" * 70 + "\n")
            return True
        except Exception as exc:
            print(f"  FAIL — {exc}")
            print("=" * 70 + "\n")
            return False

    # ── fit_split_class_models ──────────────────────────────────────

    def fit_split_class_models(
        self,
        split_col: str,
        fixed_terms: List[str],
        model: str = "nb",
        dispersion: int = 1,
        membership_terms: Optional[List[str]] = None,
        R: int = 200,
        hypothesis_label: str = "split-class hypothesis",
    ) -> dict:
        """
        Parallel validation of a latent-class hypothesis via observed splits.

        Fits:
          (a) A joint LC-2 model on the full dataset  (split_col as membership)
          (b) A separate NB model on each level of split_col  (stratified fit)

        This answers: "does an observed grouping variable (e.g. urban/rural)
        explain latent class membership as well as the joint LC model?"

        If the split-class models together achieve lower joint BIC than the
        LC model (BIC_split_A + BIC_split_B < BIC_lc), the observed split is
        informationally sufficient and the LC structure may be redundant.
        Conversely, if the LC model has much lower BIC, the latent structure
        captures heterogeneity that the observed split misses.

        Parameters
        ----------
        split_col : str
            Binary or low-cardinality column defining the observed groups
            (e.g. 'URB', 'FC', 'road_class').
        fixed_terms : list[str]
            Outcome-equation variables for all models.
        model : str
            Model family — 'nb' or 'poisson'.
        dispersion : int
            1 for NB2, 0 for Poisson.
        membership_terms : list[str], optional
            Additional membership variables for the joint LC model.
            split_col is always included.
        R : int
            Halton draws.
        hypothesis_label : str
            Label printed in the report header.

        Returns
        -------
        dict with keys:
            'lc_fit'      — full LC fit result
            'split_fits'  — {level: fit_result} for each observed class
            'comparison'  — pd.DataFrame ranked by BIC
        """
        self._ensure_columns_exist([split_col], "fit_split_class_models")

        levels = sorted(self.df[split_col].dropna().unique())
        if len(levels) < 2:
            raise ValueError(f"split_col '{split_col}' must have at least 2 distinct values.")
        if len(levels) > 6:
            raise ValueError(
                f"split_col '{split_col}' has {len(levels)} levels — "
                "use a binary or low-cardinality column."
            )

        print("\n" + "=" * 72)
        print(f"  SPLIT-CLASS HYPOTHESIS VALIDATION")
        print(f"  Hypothesis : {hypothesis_label}")
        print(f"  Split col  : '{split_col}'  levels={levels}")
        print(f"  Fixed terms: {fixed_terms}")
        print("=" * 72)

        results = {}
        comparison_rows = []

        # ── (a) Joint LC model with split_col as membership ──────────
        mem_terms = list(dict.fromkeys([split_col] + list(membership_terms or [])))
        print(f"\n  [LC]   Fitting joint {len(levels)}-class model "
              f"(membership={mem_terms}) ...")
        try:
            lc_spec = self.make_manual_spec(
                fixed_terms=fixed_terms,
                membership_terms=mem_terms,
                dispersion=dispersion,
                latent_classes=len(levels),
            )
            lc_fit = self.fit_manual_model(
                manual_spec=lc_spec, model=model, R=R, print_report=False
            )
            lc_summary = lc_fit.get("summary", {})
            lc_ll  = lc_summary.get("loglik", float("nan"))
            lc_bic = lc_summary.get("bic",    float("nan"))
            lc_k   = lc_summary.get("num_parm", "?")
            print(f"         LL={lc_ll:.2f}  k={lc_k}  BIC={lc_bic:.2f}")
            results["lc_fit"] = lc_fit
            comparison_rows.append({
                "Model": f"LC-{len(levels)} joint  (membership={split_col})",
                "N": len(self.df),
                "LL": lc_ll,
                "k": lc_k,
                "BIC": lc_bic,
                "type": "lc",
            })
        except Exception as exc:
            print(f"  [LC]   FAILED: {exc}")
            results["lc_fit"] = None
            comparison_rows.append({
                "Model": f"LC-{len(levels)} joint", "N": len(self.df),
                "LL": float("nan"), "k": "?", "BIC": float("nan"), "type": "lc",
            })

        # ── (b) Stratified models per observed class ─────────────────
        split_fits = {}
        split_bic_sum = 0.0
        split_ll_sum  = 0.0

        for level in levels:
            mask = self.df[split_col] == level
            df_sub = self.df[mask].reset_index(drop=True)
            n_sub  = df_sub[self.id_col].nunique()
            label  = f"{split_col}={level}"
            print(f"\n  [SPLIT] Fitting {model.upper()} on '{label}' "
                  f"(n_ids={n_sub}) ...")
            try:
                sub_builder = ExperimentBuilder(
                    df=df_sub,
                    id_col=self.id_col,
                    y_col=self.y_col,
                    offset_col=self.offset_col,
                )
                sub_spec = sub_builder.make_manual_spec(
                    fixed_terms=fixed_terms,
                    dispersion=dispersion,
                    latent_classes=1,
                )
                sub_fit = sub_builder.fit_manual_model(
                    manual_spec=sub_spec, model=model, R=R, print_report=False
                )
                sub_summary = sub_fit.get("summary", {})
                sub_ll  = sub_summary.get("loglik", float("nan"))
                sub_bic = sub_summary.get("bic",    float("nan"))
                sub_k   = sub_summary.get("num_parm", "?")
                print(f"         LL={sub_ll:.2f}  k={sub_k}  BIC={sub_bic:.2f}")
                split_fits[level] = sub_fit
                split_bic_sum += sub_bic if np.isfinite(sub_bic) else 0.0
                split_ll_sum  += sub_ll  if np.isfinite(sub_ll)  else 0.0
                comparison_rows.append({
                    "Model": f"Single-class {model.upper()} | {label}",
                    "N": n_sub,
                    "LL": sub_ll,
                    "k": sub_k,
                    "BIC": sub_bic,
                    "type": "split",
                })
            except Exception as exc:
                print(f"  [SPLIT] '{label}' FAILED: {exc}")
                split_fits[level] = None
                comparison_rows.append({
                    "Model": f"Single-class | {label}", "N": n_sub,
                    "LL": float("nan"), "k": "?", "BIC": float("nan"), "type": "split",
                })

        results["split_fits"] = split_fits

        # ── Summary table ────────────────────────────────────────────
        print("\n\n" + "=" * 72)
        print(f"  SPLIT-CLASS COMPARISON  —  {hypothesis_label}")
        print("=" * 72)
        df_cmp = pd.DataFrame(comparison_rows)
        df_cmp = df_cmp.sort_values("BIC")
        results["comparison"] = df_cmp

        best_bic = df_cmp["BIC"].min()
        hdr = (f"  {'Model':<46}  {'N':>6}  {'LL':>10}  {'k':>4}  "
               f"{'BIC':>10}  {'dBIC':>8}")
        print(hdr)
        print("  " + "-" * (len(hdr) - 2))
        for _, row in df_cmp.iterrows():
            dbic = row["BIC"] - best_bic if np.isfinite(row["BIC"]) else float("nan")
            ll_s  = f"{row['LL']:>10.1f}"  if np.isfinite(row["LL"])  else f"{'—':>10}"
            bic_s = f"{row['BIC']:>10.1f}" if np.isfinite(row["BIC"]) else f"{'FAILED':>10}"
            dbi_s = f"{dbic:>+8.1f}"       if np.isfinite(dbic)        else f"{'—':>8}"
            print(f"  {row['Model']:<46}  {row['N']:>6}  {ll_s}  "
                  f"{row['k']:>4}  {bic_s}  {dbi_s}")

        # ── Interpretation ────────────────────────────────────────────
        if np.isfinite(split_bic_sum) and split_bic_sum > 0:
            lc_bic_val = next(
                (r["BIC"] for r in comparison_rows if r["type"] == "lc"),
                float("nan"),
            )
            print(f"\n  Summed BIC (stratified splits) : {split_bic_sum:.1f}")
            if np.isfinite(lc_bic_val):
                print(f"  Joint LC BIC                   : {lc_bic_val:.1f}")
                delta = split_bic_sum - lc_bic_val
                if delta > 0:
                    print(f"  → LC model preferred by ΔBIC={delta:.1f}: "
                          "latent structure captures heterogeneity the observed "
                          "split misses.")
                else:
                    print(f"  → Observed split preferred by ΔBIC={-delta:.1f}: "
                          f"'{split_col}' fully explains the class structure; "
                          "LC may be redundant.")

        print("=" * 72 + "\n")
        return results

    # ── describe ────────────────────────────────────────────────────

    def describe(self):
        print("\n" + "=" * 70)
        print("  EXPERIMENT BUILDER  —  Data Summary")
        print("=" * 70)
        print(f"\n  ID column      : {self.id_col}")
        print(f"  Outcome column : {self.y_col}")
        print(f"  Offset column  : {self.offset_col or '(none)'}")
        print(f"  Group column   : {self.group_id_col or '(none)'}")
        print(f"\n  Observations   : {len(self.df):,}")
        print(f"  Unique IDs     : {self.df[self.id_col].nunique():,}")

        y = self.df[self.y_col]
        vr = y.var() / y.mean() if y.mean() > 0 else 0
        print(f"\n  Outcome ({self.y_col}):")
        print(f"    mean     = {y.mean():.4f}")
        print(f"    std      = {y.std():.4f}")
        print(f"    zeros    = {(y == 0).sum()} ({(y==0).mean()*100:.1f}%)")
        print(f"    max      = {y.max()}")
        print(f"    var/mean = {vr:.3f}  "
              f"({'overdispersed → consider NB' if vr > 1.5 else 'near-Poisson'})")

        print(f"\n  Candidate variables ({len(self._candidate_vars)}):\n")
        print(f"  {'Variable':<20} {'Type':<12} {'Unique':>7} "
              f"{'Min':>10} {'Max':>10} {'Mean':>10} {'Zeros%':>8}")
        print("  " + "-" * 80)

        for col in self._candidate_vars:
            s = self.df[col]
            print(f"  {col:<20} {self._infer_type(s):<12} {s.nunique():>7} "
                  f"{s.min():>10.3g} {s.max():>10.3g} "
                  f"{s.mean():>10.3g} {(s==0).mean()*100:>7.1f}%")

        print("\n" + ROLE_GUIDE)

    # ── suggest_config ───────────────────────────────────────────────

    def suggest_config(self,
                       max_latent_classes: int = 1) -> Dict:
        suggestions = {}

        print("\n" + "=" * 70)
        print("  SUGGESTED VARIABLE CONFIGURATION")
        if max_latent_classes > 1:
            print(f"  Latent classes: up to {max_latent_classes}  "
                  f"(roles 7 and 8 are available)")
        print("=" * 70 + "\n")

        for col in self._candidate_vars:
            s        = self.df[col]
            vtype    = self._infer_type(s)
            roles, dists, reason = self._suggest_roles_dists(
                col, s, vtype, max_latent_classes
            )
            roles_str = ", ".join(
                f"{r}={self._ROLE_NAMES[r]}" for r in roles
            )
            print(f"  {col}")
            print(f"    Roles  : [{roles_str}]")
            print(f"    Dists  : {', '.join(dists) if dists else '—'}")
            print(f"    Reason : {reason}\n")

            suggestions[col] = {"roles": roles, "dists": dists}

        return suggestions

    # ── build_evaluator ─────────────────────────────────────────────

    def build_evaluator(
        self,
        variables:           Optional[List[str]]       = None,
        fixed_override:      Optional[Dict[str, list]] = None,
        membership_override: Optional[Dict[str, list]] = None,
        exclude:             Optional[List[str]]       = None,
        mutual_exclusion:    Optional[List[List[str]]] = None,
        mode:                str                       = "single",
        max_latent_classes:  int                       = 1,
        R:                   int                       = 200,
        default_roles:       Optional[list]            = None,
        model_family:        Optional[str]             = None,
        engine:              Optional[str]             = None,
        constraints=None,
        draw_dtype:          str                       = "float32",
        **family_kwargs: Any,
    ):
        """
        Build a StructureEvaluatorLC ready for the search.

        Parameters
        ----------
        variables
            Columns to search over (default: all candidate columns).
        fixed_override
            {col: [allowed_roles]} — override for specific variables.
            Example: {"EXPOSURE": [1]} forces EXPOSURE to fixed-only.
        membership_override
            {col: [allowed_roles]} — used to allow/restrict membership
            roles (7, 8).
            Example: {"URB": [0, 1, 7]} allows URB to be excluded, fixed,
            or membership-only.
        exclude
            Columns to always exclude from the search.
        mode
            "single" (BIC) or "multi" (BIC + test RMSE).
        max_latent_classes
            Maximum number of latent classes.  Set to 1 to disable LC.
        R
            Number of Halton simulation draws.
        draw_dtype
            Storage dtype ("float32" or "float64") for the long-lived master
            draws. float32 halves master-draw memory (e.g. ~3.3 GB to ~1.6 GB
            at 200k rows x 26 vars x R=80); slices are cast back to float64
            for estimation, so fit precision is unchanged.
        default_roles
            Roles available to most variables.
            Defaults to [0,1,2,3,5] when max_latent_classes = 1,
            or [0,1,2,3,5,7,8] when max_latent_classes > 1.
        model_family
            Search family to build. One of: "count", "cmf", "linear",
            "duration", "tobit", "multivariate", "survival" (aliases
            "hazard", "aft").  The survival family needs
            ExperimentBuilder(..., event_col=...) and supports the same
            metaheuristic role search over roles 0-5; roles 6/7/8 and
            latent classes are structurally excluded.
        engine
            Execution engine. Use ``jax`` for the full model or ``numba`` for
            single-class fixed-effects Poisson/NB2 search.
        """
        model_family = (model_family or self.default_model_family).lower()
        engine = (engine or self.default_engine).lower()

        if engine not in {"jax", "numba", "numba-rp"}:
            raise ValueError("engine must be 'jax', 'numba' or 'numba-rp' for count models")
        if engine in {"numba", "numba-rp"} and model_family != "count":
            raise ValueError("engine='numba' is implemented for count models only")

        if model_family != "count":
            return self.build_search(
                model_family=model_family,
                variables=variables,
                exclude=exclude,
                mode=mode,
                max_latent_classes=max_latent_classes,
                R=R,
                default_roles=default_roles,
                fixed_override=fixed_override,
                membership_override=membership_override,
                engine=engine,
                **family_kwargs,
            )

        # Merge ModelConstraints (if supplied) with explicit override kwargs.
        # Explicit kwargs always win over constraint-derived defaults.
        if constraints is not None:
            _ckw = constraints.to_evaluator_kwargs()
            fixed_override = {
                **_ckw.get("fixed_override", {}),
                **(fixed_override or {}),
            }
            membership_override = {
                **_ckw.get("membership_override", {}),
                **(membership_override or {}),
            }
            _c_exclude = _ckw.get("exclude", [])
            exclude = list(dict.fromkeys(list(_c_exclude) + list(exclude or [])))
            # Mutual exclusion groups from constraints (merged, explicit wins)
            _c_mutex = _ckw.get("mutual_exclusion", [])
            if _c_mutex:
                mutual_exclusion = (_c_mutex + (mutual_exclusion or [])) if mutual_exclusion else _c_mutex
            # Distribution overrides from constraints (merged, explicit wins)
            if "dist_override" in _ckw:
                family_kwargs.setdefault("dist_override", {})
                family_kwargs["dist_override"] = {
                    **_ckw["dist_override"],
                    **family_kwargs["dist_override"],
                }

        variables = self._normalize_variables(variables, exclude)
        fixed_override = self._normalize_override_map(fixed_override, "fixed_override")
        membership_override = self._normalize_override_map(membership_override, "membership_override")

        if default_roles is None:
            if max_latent_classes > 1:
                default_roles = [0, 1, 2, 3, 5, 7, 8]
            else:
                default_roles = [0, 1, 2, 3, 5]

        # Merge overrides: membership_override takes priority for those vars
        merged_override = {**fixed_override, **membership_override}

        allowed_roles = populate_allowed_roles(
            variables, merged_override, default_roles=default_roles
        )
        # ── Single-class searches must not offer membership roles ──────
        # Roles 7 (membership-only) and 8 (membership + fixed) are latent-class
        # constructs. With max_latent_classes == 1 there is no membership
        # equation, so build_spec treats them as degenerate: role 7 silently
        # drops the variable from every list, and role 8 appends it to
        # `fixed` with the membership half discarded. Both are reachable
        # because ModelConstraints.to_evaluator_kwargs() derives
        # fixed_override from _ALL_ROLES (0..8) and no_random()/no_zi() only
        # discard the random and ZI codes, leaving 7 and 8 allowed.
        #
        # The effect is not a wrong model -- a single-variable role 8 still
        # decodes to the fixed term it claims to be, and the BIC is computed
        # on the same structure that is later refitted -- but the search burns
        # evaluations on genes that are not real degrees of freedom, and the
        # printed structure table shows "Unknown" for them (role_map in
        # main_hpc.decode_best_solution has no 7/8 entries). Strip them so the
        # search space matches the model that can actually be expressed.
        if max_latent_classes <= 1:
            _MEMBERSHIP_CODES = (7, 8)
            for _v, _roles in allowed_roles.items():
                _kept = [r for r in _roles if r not in _MEMBERSHIP_CODES]
                # Never leave a variable with an empty role set: it would fail
                # the `role not in allowed_roles` check in build_spec for every
                # candidate, making the variable unsearchable rather than absent.
                allowed_roles[_v] = _kept if _kept else [0]

        allowed_dists = populate_allowed_distributions(variables, None)

        if engine == "numba":
            from .numba_count import NumbaFixedCountEvaluator
            self._evaluator = NumbaFixedCountEvaluator(
                df                  = self.df,
                id_col              = self.id_col,
                y_col               = self.y_col,
                all_variables       = variables,
                allowed_roles       = allowed_roles,
                allowed_distributions=allowed_dists,
                mode                = mode,
                group_id_col        = None,
                offset_col          = self.offset_col,
                R                   = R,
                max_latent_classes  = max_latent_classes,
            )
            D = len(variables)
            print("\n  Numba fixed-effects count evaluator ready:")
            print(f"    Variables          : {D}")
            print(f"    Decision dimension : {2 * D + 1}")
            print("    Models             : single-class Poisson/NB2")
            print("    Random/grouped/ZI  : disabled")
            return self._evaluator

        if engine == "numba-rp":
            try:
                from .numba_rp import NumbaRandomCountEvaluator
            except ImportError:
                from numba_rp import NumbaRandomCountEvaluator
            self._evaluator = NumbaRandomCountEvaluator(
                df                  = self.df,
                id_col              = self.id_col,
                y_col               = self.y_col,
                all_variables       = variables,
                allowed_roles       = allowed_roles,
                allowed_distributions=allowed_dists,
                mode                = mode,
                group_id_col        = self.group_id_col,
                offset_col          = self.offset_col,
                R                   = R,
                max_latent_classes  = max_latent_classes,
            )
            D = len(variables)
            print("\n  Numba RP count evaluator ready (Phase-1 prototype):")
            print(f"    Variables          : {D}")
            print(f"    Decision dimension : {2 * D + 1}")
            print("    Models             : single-class Poisson/NB2 + independent RP")
            print("    Correlated/grouped/ZI/LC : disabled (return None -> search skips)")
            return self._evaluator

        self._evaluator = StructureEvaluatorLC(
            df                    = self.df,
            id_col                = self.id_col,
            y_col                 = self.y_col,
            offset_col            = self.offset_col,
            all_variables         = variables,
            allowed_roles         = allowed_roles,
            allowed_distributions = allowed_dists,
            mutual_exclusion      = mutual_exclusion,
            group_id_col          = self.group_id_col,
            mode                  = mode,
            R                     = R,
            max_latent_classes    = max_latent_classes,
            draw_dtype            = draw_dtype,
            event_col             = self.event_col,
        )

        D   = len(variables)
        _dim = 3 * D + 2 if max_latent_classes > 1 else 2 * D + 1
        _dim_note = f"3×{D} + 2  (roles+dists+dispersion+LC+class_masks)" if max_latent_classes > 1 else f"2×{D} + 1  (roles+dists+dispersion)"
        print(f"\n  Evaluator ready:")
        print(f"    Variables          : {D}")
        print(f"    Decision dimension : {_dim}  ({_dim_note})")
        print(f"    Max latent classes : {max_latent_classes}")
        print(f"    Mode               : {mode}")
        print(f"    Draws (R)          : {R}  [{draw_dtype} master]")
        if max_latent_classes > 1:
            print(f"\n  Membership roles 7 and 8 are active.")
            print(f"  Role 7 = membership-only  (no outcome effect)")
            print(f"  Role 8 = membership + fixed outcome (class-specific beta)")
            print(f"  LC models are warm-started from the single-class solution.\n")

        return self._evaluator

    def build_search(
        self,
        model_family: Optional[str] = None,
        variables: Optional[List[str]] = None,
        exclude: Optional[List[str]] = None,
        engine: Optional[str] = None,
        **kwargs,
    ):
        model_family = (model_family or self.default_model_family).lower()
        engine = (engine or self.default_engine).lower()
        explicit_variables = variables

        if engine not in {"jax", "numba", "numba-rp"}:
            raise ValueError("engine must be 'jax', 'numba' or 'numba-rp' for count models")
        if engine in {"numba", "numba-rp"} and model_family != "count":
            raise ValueError("engine='numba' is implemented for count models only")

        variables = self._normalize_variables(variables, exclude)

        if model_family == "count":
            return self.build_evaluator(
                variables=variables,
                exclude=exclude,
                model_family="count",
                engine=engine,
                **kwargs,
            )

        if model_family == "linear":
            linear_driver = str(kwargs.pop("linear_driver", "jax_hierarchical")).lower()
            objective_kwargs = kwargs.pop("objective_kwargs", {})
            if linear_driver in {"jax", "jax_hierarchical", "main"}:
                mode = kwargs.pop("mode", "single")
                max_latent_classes = kwargs.pop("max_latent_classes", 2)
                R = kwargs.pop("R", 200)
                default_roles = kwargs.pop("default_roles", None)
                fixed_override = self._normalize_override_map(kwargs.pop("fixed_override", None), "fixed_override")
                membership_override = self._normalize_override_map(kwargs.pop("membership_override", None), "membership_override")
                if default_roles is None:
                    default_roles = [0, 1, 2, 3, 4, 5, 6]
                    if max_latent_classes > 1:
                        default_roles.extend([7, 8])
                evaluator = ForcedModelStructureEvaluatorLC(
                    df=self.df,
                    id_col=self.id_col,
                    y_col=self.y_col,
                    offset_col=self.offset_col,
                    all_variables=variables,
                    allowed_roles=populate_allowed_roles(variables, {**fixed_override, **membership_override}, default_roles=default_roles),
                    allowed_distributions=populate_allowed_distributions(variables, None),
                    group_id_col=self.group_id_col,
                    mode=mode,
                    R=R,
                    max_latent_classes=max_latent_classes,
                    forced_model="gaussian",
                    event_col=self.event_col,
                )
                self._raise_on_unused_kwargs(kwargs, "linear search")
                return LinearSearchProblem(
                    builder=self,
                    evaluator=evaluator,
                    metadata={"model": "gaussian", "variables": variables, "max_latent_classes": max_latent_classes},
                )
            self._raise_on_unused_kwargs(kwargs, "legacy linear search")
            return LinearSearchProblem(
                df=self.df,
                y_col=self.y_col,
                variables=variables,
                objective_kwargs=objective_kwargs,
            )

        if model_family == "duration":
            budget_col = kwargs.pop("budget_col", "B")
            if budget_col not in self.df.columns:
                raise ValueError(f"Duration search requires budget_col='{budget_col}' in the dataframe.")
            duration_driver = str(kwargs.pop("duration_driver", "jax_hierarchical")).lower()
            if duration_driver in {"jax", "jax_hierarchical", "main"}:
                mode = kwargs.pop("mode", "single")
                max_latent_classes = kwargs.pop("max_latent_classes", 2)
                R = kwargs.pop("R", 200)
                default_roles = kwargs.pop("default_roles", None)
                fixed_override = self._normalize_override_map(kwargs.pop("fixed_override", None), "fixed_override")
                membership_override = self._normalize_override_map(kwargs.pop("membership_override", None), "membership_override")
                duration_variables = list(dict.fromkeys([*variables, budget_col]))
                if default_roles is None:
                    default_roles = [0, 1, 2, 3, 4, 5, 6]
                    if max_latent_classes > 1:
                        default_roles.extend([7, 8])
                evaluator = ForcedModelStructureEvaluatorLC(
                    df=self.df,
                    id_col=self.id_col,
                    y_col=self.y_col,
                    offset_col=self.offset_col,
                    all_variables=duration_variables,
                    allowed_roles=populate_allowed_roles(duration_variables, {**fixed_override, **membership_override}, default_roles=default_roles),
                    allowed_distributions=populate_allowed_distributions(duration_variables, None),
                    group_id_col=self.group_id_col,
                    mode=mode,
                    R=R,
                    max_latent_classes=max_latent_classes,
                    forced_model="lognormal",
                )
                self._raise_on_unused_kwargs(kwargs, "duration search")
                return DurationSearchProblem(
                    builder=self,
                    evaluator=evaluator,
                    metadata={"model": "lognormal", "variables": duration_variables, "budget_col": budget_col, "max_latent_classes": max_latent_classes},
                )
            self._raise_on_unused_kwargs(kwargs, "duration search")
            return DurationSearchProblem(
                df=self.df.copy(),
                y_col=self.y_col,
                variables=variables,
                id_col=self.id_col,
                budget_col=budget_col,
            )

        if model_family == "tobit":
            # Left-censored (at 0) linear model — random-parameters and
            # latent-class variants are fully supported.
            mode               = kwargs.pop("mode", "single")
            max_latent_classes = kwargs.pop("max_latent_classes", 2)
            R                  = kwargs.pop("R", 200)
            default_roles      = kwargs.pop("default_roles", None)
            fixed_override     = self._normalize_override_map(
                kwargs.pop("fixed_override", None), "fixed_override")
            membership_override = self._normalize_override_map(
                kwargs.pop("membership_override", None), "membership_override")
            if default_roles is None:
                default_roles = [0, 1, 2, 3, 4, 5, 6]
                if max_latent_classes > 1:
                    default_roles.extend([7, 8])
            evaluator = ForcedModelStructureEvaluatorLC(
                df=self.df,
                id_col=self.id_col,
                y_col=self.y_col,
                offset_col=self.offset_col,
                all_variables=variables,
                allowed_roles=populate_allowed_roles(
                    variables,
                    {**fixed_override, **membership_override},
                    default_roles=default_roles,
                ),
                allowed_distributions=populate_allowed_distributions(variables, None),
                group_id_col=self.group_id_col,
                mode=mode,
                R=R,
                max_latent_classes=max_latent_classes,
                forced_model="tobit",
            )
            self._raise_on_unused_kwargs(kwargs, "tobit search")
            # Re-use LinearSearchProblem as the search wrapper (same SA driver)
            return LinearSearchProblem(
                builder=self,
                evaluator=evaluator,
                metadata={
                    "model": "tobit",
                    "variables": variables,
                    "max_latent_classes": max_latent_classes,
                },
            )

        if model_family in ("survival", "hazard", "aft"):
            # Survival / hazard structure search.  Runs the same SA driver
            # over the same role space as every other family; the only
            # difference is the likelihood, which reads the right-censoring
            # indicator data["event"] instead of a count.
            #
            #   family="weibull_ph" (default) -> exp(beta) is a HAZARD ratio
            #   family="weibull"/"lognormal"/"loglogistic" -> exp(beta) is a
            #                                          TIME ratio (AFT)
            surv_family = str(kwargs.pop("family", "weibull_ph")).lower()
            try:
                from .survival_models import ALL_SURVIVAL_FAMILIES, PH_FAMILIES
            except ImportError:
                from survival_models import ALL_SURVIVAL_FAMILIES, PH_FAMILIES
            if surv_family not in ALL_SURVIVAL_FAMILIES:
                raise ValueError(
                    f"survival family {surv_family!r} not in "
                    f"{sorted(ALL_SURVIVAL_FAMILIES)}"
                )
            if self.event_col is None:
                raise ValueError(
                    "survival/hazard search needs an event_col: pass "
                    "ExperimentBuilder(..., event_col='<0/1 flag column>') so "
                    "the censoring indicator reaches the likelihood."
                )
            if not surv_family.startswith(("lognormal", "weibull", "loglogistic")):
                raise ValueError(
                    f"{surv_family!r} is not a continuous-time survival family"
                )
            # Latent classes are not wired into the survival likelihood, and
            # "multi" Pareto mode assumes a count objective.  Both are forced
            # rather than rejected, so a caller can pass the same kwargs it
            # uses for every other family without special-casing survival.
            kwargs.pop("max_latent_classes", None)
            kwargs.pop("mode", None)
            max_latent_classes = 1
            mode = "single"
            R = kwargs.pop("R", 200)
            default_roles = kwargs.pop("default_roles", None) or [0, 1, 2, 3, 4, 5]
            fixed_override = self._normalize_override_map(
                kwargs.pop("fixed_override", None), "fixed_override")
            membership_override = self._normalize_override_map(
                kwargs.pop("membership_override", None), "membership_override")
            # Role space for survival.  Roles 6 (ZI), 7 and 8 (latent-class
            # membership) are STRUCTURALLY meaningless here, not merely
            # unselected: censoring is the only structural-zero mechanism,
            # and latent classes are forced off (see below).  If the SA were
            # allowed to propose them, build_spec would have to silently drop
            # them and the structure actually fitted would differ from the
            # structure described -- a quieter, worse failure than exclusion.
            _allow = populate_allowed_roles(
                variables,
                {**fixed_override, **membership_override},
                default_roles=default_roles,
            )
            _DROP = {6, 7, 8}
            allowed_roles = {}
            for _v, _r in _allow.items():
                try:
                    allowed_roles[_v] = [r for r in _r if r not in _DROP]
                except TypeError:
                    allowed_roles[_v] = _r
            evaluator = ForcedModelStructureEvaluatorLC(
                df=self.df,
                id_col=self.id_col,
                y_col=self.y_col,
                offset_col=self.offset_col,
                all_variables=variables,
                allowed_roles=allowed_roles,
                allowed_distributions=populate_allowed_distributions(variables, None),
                group_id_col=self.group_id_col,
                mode=mode,
                R=R,
                max_latent_classes=max_latent_classes,
                forced_model=surv_family,
                event_col=self.event_col,
            )
            self._raise_on_unused_kwargs(kwargs, "survival search")
            # LinearSearchProblem is the generic "builder + evaluator" SA
            # wrapper; only the reported family label differs.
            return LinearSearchProblem(
                builder=self,
                evaluator=evaluator,
                metadata={
                    "model": surv_family,
                    "family": model_family,
                    "event_col": self.event_col,
                    "ratio": ("hazard_ratio" if surv_family in PH_FAMILIES
                              else "time_ratio"),
                    "variables": variables,
                    "max_latent_classes": max_latent_classes,
                },
            )

        if model_family == "cmf":
            try:
                from .cmf_package import CMFExperimentBuilder
            except ImportError:
                from cmf_package import CMFExperimentBuilder

            cmf_driver = str(kwargs.pop("cmf_driver", "jax_count")).lower()
            aadt_col = kwargs.pop("aadt_col", None)
            baseline_vars = kwargs.pop("baseline_vars", None)
            local_vars = kwargs.pop("local_vars", None)

            if aadt_col is None or baseline_vars is None or local_vars is None:
                raise ValueError("CMF search requires aadt_col, baseline_vars, and local_vars.")

            cmf_builder = CMFExperimentBuilder(
                df=self.df,
                y_col=self.y_col,
                aadt_col=aadt_col,
                baseline_vars=baseline_vars,
                local_vars=local_vars,
            )
            if cmf_driver in {"jax", "jax_count", "count", "main"}:
                general_builder, evaluator, metadata = cmf_builder.build_jax_count_evaluator(
                    id_col=self.id_col,
                    offset_col=self.offset_col,
                    group_id_col=self.group_id_col,
                    variables=explicit_variables,
                    fixed_override=kwargs.pop("fixed_override", None),
                    membership_override=kwargs.pop("membership_override", None),
                    exclude=exclude,
                    mode=kwargs.pop("mode", "single"),
                    max_latent_classes=kwargs.pop("max_latent_classes", 1),
                    R=kwargs.pop("R", 200),
                    default_roles=kwargs.pop("default_roles", None),
                )
                self._raise_on_unused_kwargs(kwargs, "cmf search")
                return UnifiedCMFSearchProblem(
                    builder=general_builder,
                    evaluator=evaluator,
                    metadata=metadata,
                )

            if cmf_driver not in {"ga", "legacy_ga", "metaheuristic"}:
                raise ValueError(
                    "cmf_driver must be one of: 'jax_count' (default), 'ga', 'legacy_ga', 'metaheuristic'."
                )
            kwargs.pop("mode", None)
            kwargs.pop("max_latent_classes", None)
            kwargs.pop("R", None)
            kwargs.pop("default_roles", None)
            kwargs.pop("fixed_override", None)
            kwargs.pop("membership_override", None)
            self._raise_on_unused_kwargs(kwargs, "legacy cmf search")
            return CMFFamilySearchProblem(
                builder=cmf_builder,
                id_col=self.id_col,
                offset_col=self.offset_col,
                group_id_col=self.group_id_col,
            )

        if model_family == "multivariate":
            try:
                from .family_search import MultivariateSearchProblem
            except ImportError:
                from family_search import MultivariateSearchProblem

            activity_cols = kwargs.pop("activity_cols", None)
            if activity_cols is None:
                raise ValueError(
                    "multivariate search requires activity_cols=<list of outcome columns>."
                )
            # All activity columns must be present in the dataframe
            self._ensure_columns_exist(activity_cols, "multivariate activity_cols")

            offset_col_mv   = kwargs.pop("offset_col",            self.offset_col)
            maxiter         = kwargs.pop("maxiter",                500)
            verbose         = kwargs.pop("verbose",                False)
            search_copula   = kwargs.pop("search_copula",          False)
            search_marginal = kwargs.pop("search_marginal",        False)
            fixed_copula    = kwargs.pop("fixed_copula",           "gaussian")
            fixed_marginal  = kwargs.pop("fixed_marginal",         "nb")
            min_vars        = kwargs.pop("min_vars_per_activity",  1)
            add_intercept   = kwargs.pop("add_intercept",          True)
            self._raise_on_unused_kwargs(kwargs, "multivariate search")

            return MultivariateSearchProblem(
                df=self.df,
                activity_cols=activity_cols,
                covariate_cols=variables,          # variables already normalised above
                offset_col=offset_col_mv,
                maxiter=maxiter,
                verbose=verbose,
                search_copula=search_copula,
                search_marginal=search_marginal,
                fixed_copula=fixed_copula,
                fixed_marginal=fixed_marginal,
                min_vars_per_activity=min_vars,
                add_intercept=add_intercept,
                metadata={
                    "activity_cols":  activity_cols,
                    "covariate_cols": variables,
                },
            )

        raise ValueError("model_family must be one of: count, cmf, linear, duration, multivariate")

    def build_count_evaluator(self, **kwargs):
        kwargs.setdefault("model_family", "count")
        kwargs.setdefault("engine", self.default_engine)
        return self.build_evaluator(**kwargs)

    def build_bayesian_model(self, search_result, *, evaluator=None,
                             event_col=None, priors=None, initvals=None):
        """Compile a completed search result into an optional PyMC model."""
        try:
            from .bayesian_model import build_bayesian_model
        except ImportError:
            from bayesian_model import build_bayesian_model
        return build_bayesian_model(
            search_result,
            builder=self,
            evaluator=evaluator,
            event_col=event_col,
            priors=priors,
            initvals=initvals,
        )

    # ── run ─────────────────────────────────────────────────────────

    def _make_checkpoint_callback(
        self,
        output_config: SearchOutputConfig,
        evaluator,
        algo: str,
        seed: int,
        max_iter: int,
    ):
        """Build the SA per-generation hook that writes the incumbent.

        The hook throttles to ``output_config.checkpoint_every`` generations
        and writes atomically, so a walltime kill / OOM always leaves a
        resumable best-so-far decision vector on disk (release valve).
        """
        every = max(1, int(output_config.checkpoint_every))
        state = {"last": -10 ** 9}

        def _cb(gen, decision, score, elapsed, temperature):
            if gen - state["last"] < every:
                return
            state["last"] = int(gen)
            try:
                save_search_checkpoint(output_config, {
                    "algorithm": algo,
                    "seed": int(seed),
                    "max_iter": int(max_iter),
                    "gen": int(gen),
                    "elapsed_seconds": float(elapsed),
                    "best_score": float(score),
                    "best_decision": np.asarray(decision, dtype=float).tolist(),
                    "variables": [str(v) for v in evaluator.vars],
                    "temperature": (None if temperature is None
                                    else float(temperature)),
                    "description": output_config.search_description,
                })
                print(f"  [checkpoint] gen {int(gen)} | "
                      f"best_score={float(score):.4f} -> "
                      f"{output_config.checkpoint_name or 'checkpoint'}")
            except Exception as exc:  # noqa: BLE001 - never kill a search
                print(f"  [checkpoint] write failed ({exc}); continuing")

        return _cb

    def run(
        self,
        evaluator:  Optional[StructureEvaluatorLC] = None,
        algo:       str  = "sa",
        max_iter:   int  = 3000,
        n_jobs:     int  = 1,
        seed:       int  = 0,
        config_id:  int  = 0,
        output_config: Optional[SearchOutputConfig] = None,
        max_time:   Optional[float] = None,
        refit:      bool = True,
        **algo_kwargs,
    ) -> dict:
        """
        Run the metaheuristic search.

        algo : "sa"  Simulated Annealing (recommended for single mode)
               "de"  Differential Evolution NSGA2 (multi mode)
               "hs"  Harmony Search NSGA2 (multi mode)
        max_time : wall-time stop in seconds (per SA restart; None = no limit).
        refit : run the end-of-search summary refit; pass False for
                intermediate chunks of a chunked search to skip a full MLE
                fit the caller is going to redo anyway.
        output_config : SearchOutputConfig; set checkpoint_every > 0 to write
                the best-so-far decision vector + score during the search
                (resume with init_solutions=[checkpoint["best_decision"]]).
        """
        import time as _time
        _t0 = _time.time()

        evaluator = evaluator or self._evaluator
        if evaluator is None:
            raise RuntimeError("Call build_evaluator() first.")

        # build_search() does not always hand back a bare evaluator: the
        # linear / duration / tobit families return a *search problem*
        # wrapper (LinearSearchProblem, DurationSearchProblem) that owns the
        # evaluator.  Calling run() with one of those used to die on
        # `len(evaluator.vars)` with
        #   AttributeError: 'LinearSearchProblem' object has no attribute 'vars'
        # (jobs o25908337/o25908338).  Route through run_search(), which
        # already dispatches wrappers correctly and handles output_config,
        # so both entry points accept whatever build_search() produced.
        if (
            not hasattr(evaluator, "vars")
            and not isinstance(evaluator, StructureEvaluatorLC)
            and hasattr(evaluator, "run")
        ):
            return self.run_search(
                evaluator,
                algo=algo,
                max_iter=max_iter,
                seed=seed,
                config_id=config_id,
                output_config=output_config,
                max_time=max_time,
                refit=refit,
                **algo_kwargs,
            )

        D   = len(evaluator.vars)
        # Decision vector: [roles(D) | dists(D) | dispersion_bit | lc_code?]
        # The LC gene (index 2*D+1) is only present when max_latent_classes > 1.
        # Without it the SA never generates valid LC solutions (IndexError in build_spec).
        has_lc = getattr(evaluator, "max_latent_classes", 1) > 1
        dim    = 3 * D + 2 if has_lc else 2 * D + 1

        print(f"\n  Running {algo.upper()} | dim={dim} | max_iter={max_iter} | seed={seed}")

        if algo in ("sa", "hc"):
            defaults = dict(
                max_iter=max_iter,
                mutation_rate=0.3,
                step_size=1,
                min_changes=1,
                max_changes=5,  # increased for larger role space (10 roles vs old 6)
                n_starts=3,     # multiple restarts for better coverage
                alpha=0.995,
            )
            defaults.update(algo_kwargs)
            if max_time is not None:
                # Wall-time stop, forwarded to AdvancedSimulatedAnnealing
                # (applies per restart; a 3-start run can take 3x max_time).
                defaults["max_time"] = float(max_time)
            if (output_config is not None
                    and int(getattr(output_config, "checkpoint_every", 0) or 0) > 0):
                defaults["on_iteration"] = self._make_checkpoint_callback(
                    output_config, evaluator, algo, seed, max_iter,
                )
            # Warm-start resume: harvest the best decision vector already in
            # the evaluator cache (e.g. restored by a PersistentEvalCache
            # after a walltime kill) and seed the SA with it, so resubmitted
            # jobs continue from the incumbent instead of re-exploring at
            # random.  Opt out with warm_start_cache=False.
            warm_start = defaults.pop("warm_start_cache", True)
            if warm_start and "init_solutions" not in defaults:
                D_ = len(evaluator.vars)
                want = 3 * D_ + 2 if has_lc else 2 * D_ + 1
                best_k, best_v = None, None
                for k, v in getattr(evaluator, "cache", {}).items():
                    if isinstance(k, (tuple, list)) and len(k) == want:
                        try:
                            val = float(np.min(v))
                        except Exception:
                            continue
                        if np.isfinite(val) and val < 1e12 and (
                            best_v is None or val < best_v
                        ):
                            best_k, best_v = k, val
                if best_k is not None:
                    defaults["init_solutions"] = [np.asarray(best_k, dtype=float)]
                    print(f"  [resume] warming start from cached best "
                          f"(score={best_v:.4f})")
            # Run metadata for save_search_result() -- variables considered,
            # the fully-resolved hyperparameters (defaults + any overrides,
            # not just the raw overrides), and wall-clock timing. Addresses
            # the JSON output previously carrying none of this (just
            # solutions/scores/best_solution/best_score).
            metadata = {
                "variables": [str(v) for v in evaluator.vars],
                "n_variables": len(evaluator.vars),
                "algorithm": algo,
                "max_iter": max_iter,
                "seed": seed,
                "hyperparameters": {k: v for k, v in defaults.items()
                                    if k != "on_iteration"},
                "objective": "bic",   # ExperimentBuilder.run() always optimises BIC internally
                "max_time": None if max_time is None else float(max_time),
                "refit": bool(refit),
            }

            solver = MultiStartSA(
                evaluator=evaluator,
                dimension=dim,
                **defaults,
            )
            solutions, scores = solver.optimize()
            solutions = np.array(solutions)
            scores    = np.array(scores)

            best_idx      = int(np.argmin(scores))
            best_solution = solutions[best_idx]
            best_score    = float(scores[best_idx])
            model_spec = evaluator.build_spec(best_solution)
            if model_spec is not None and getattr(evaluator, "cmf_metadata", None):
                model_spec = {
                    **model_spec,
                    "family": "cmf",
                    "metadata": dict(evaluator.cmf_metadata),
                }

            # Decode best
            D2  = len(evaluator.vars)
            if has_lc and len(best_solution) > 2 * D2 + 1:
                lc = int(best_solution[2*D2+1]) % evaluator.max_latent_classes + 1
            else:
                lc = 1
            n_mem_7 = sum(
                1 for i, v in enumerate(evaluator.vars)
                if int(best_solution[i]) == 7
            )
            n_mem_8 = sum(
                1 for i, v in enumerate(evaluator.vars)
                if int(best_solution[i]) == 8
            )

            print("\n  Best structure:")
            decode_best_solution(best_solution, evaluator)
            print(f"  Best BIC              : {best_score:.4f}")
            print(f"  Latent classes        : {lc}")
            print(f"  Membership-only vars  : {n_mem_7}  (role 7)")
            print(f"  Membership+fixed vars : {n_mem_8}  (role 8)")

            if refit:
                refit_and_print(evaluator, best_solution)
                save_run_summary_to_txt(evaluator, best_solution,
                                        algo, seed, config_id)
            else:
                print("  [refit] skipped (refit=False)")

            metadata["elapsed_seconds"] = _time.time() - _t0
            result = {
                "algorithm":     algo,
                "seed":          seed,
                "solutions":     solutions,
                "scores":        scores,
                "best_solution": best_solution,
                "best_score":    best_score,
                "model_spec":    model_spec,
                # search_stats/stats_csv: one entry per restart (n_starts),
                # each a per-iteration trace (iter/temperature/best/
                # archive_size, or the multi-objective columns) -- see
                # AdvancedSimulatedAnnealing.save_search_stats_csv().
                "search_stats":  [r.get("search_stats") for r in solver.results],
                "stats_csv":     [r.get("stats_csv") for r in solver.results],
            }
            if output_config is not None:
                result["saved_to"] = str(save_search_result(result, output_config, family="count", algorithm=algo, metadata=metadata))
            return result

        elif algo == "ga":
            # Genetic algorithm over the same decision vector the SA walks.
            # Population + crossover explores variable *combinations* that a
            # single-walk neighbourhood search tends to miss, which is what
            # you want when the question is "which set of variables, each
            # with its own coefficient, fits best" rather than "which single
            # term matters".
            ga_def = dict(
                population_size=60,
                max_iter=max_iter,
                crossover_rate=0.9,
                mutation_rate=0.15,
                elite_size=4,
                tournament_size=3,
                n_starts=1,
            )
            ga_def.update(algo_kwargs)

            n_starts = int(ga_def.pop("n_starts", 1))
            max_time = ga_def.pop("max_time", None)
            warm_start = ga_def.pop("warm_start_cache", True)
            init_solutions = None
            if warm_start:
                # Same resume behaviour as the SA branch: reuse the best
                # structure already in the evaluator cache (e.g. restored
                # from a checkpoint after a walltime kill).
                want = dim
                best_v = None
                for k, v in getattr(evaluator, "cache", {}).items():
                    if isinstance(k, (tuple, list)) and len(k) == want:
                        try:
                            val = float(np.min(v))
                        except Exception:
                            continue
                        if np.isfinite(val) and val < 1e12 and (
                            best_v is None or val < best_v
                        ):
                            init_solutions, best_v = [np.asarray(k, dtype=float)], val
                if init_solutions is not None:
                    print(f"  [resume] seeding GA from cached best (score={best_v:.4f})")

            metadata = {
                "variables": [str(v) for v in evaluator.vars],
                "n_variables": len(evaluator.vars),
                "algorithm": algo,
                "max_iter": max_iter,
                "seed": seed,
                "hyperparameters": dict(ga_def),
                "objective": "bic",
                "max_time": None if max_time is None else float(max_time),
                "refit": bool(refit),
            }

            solver = MultiStartGA(
                evaluator=evaluator,
                dimension=dim,
                n_starts=n_starts,
                n_jobs=n_jobs,
                init_solutions=init_solutions,
                max_time=max_time,
                **ga_def,
            )
            solutions, scores = solver.optimize()
            solutions = np.array(solutions)
            scores    = np.array(scores)

            best_idx      = int(np.argmin(scores))
            best_solution = solutions[best_idx]
            best_score    = float(scores[best_idx])
            model_spec = evaluator.build_spec(best_solution)
            if model_spec is not None and getattr(evaluator, "cmf_metadata", None):
                model_spec = {
                    **model_spec,
                    "family": "cmf",
                    "metadata": dict(evaluator.cmf_metadata),
                }

            D2  = len(evaluator.vars)
            if has_lc and len(best_solution) > 2 * D2 + 1:
                lc = int(best_solution[2*D2+1]) % evaluator.max_latent_classes + 1
            else:
                lc = 1
            n_mem_7 = sum(1 for i in range(D2) if int(best_solution[i]) == 7)
            n_mem_8 = sum(1 for i in range(D2) if int(best_solution[i]) == 8)

            print("\n  Best structure:")
            decode_best_solution(best_solution, evaluator)
            print(f"  Best BIC              : {best_score:.4f}")
            print(f"  Latent classes        : {lc}")
            print(f"  Membership-only vars  : {n_mem_7}  (role 7)")
            print(f"  Membership+fixed vars : {n_mem_8}  (role 8)")

            if refit:
                refit_and_print(evaluator, best_solution)
                save_run_summary_to_txt(evaluator, best_solution,
                                        algo, seed, config_id)

            metadata["elapsed_seconds"] = _time.time() - _t0
            result = {
                "algorithm":     algo,
                "seed":          seed,
                "solutions":     solutions,
                "scores":        scores,
                "best_solution": best_solution,
                "best_score":    best_score,
                "model_spec":    model_spec,
                "search_stats":  [r.get("search_stats") for r in solver.results],
                "stats_csv":     [None for _ in solver.results],
            }
            if output_config is not None:
                result["saved_to"] = str(save_search_result(result, output_config, family="count", algorithm=algo, metadata=metadata))
            return result

        elif algo in ("de", "hs"):
            de_def = dict(population_size=30, F=0.5, CR=0.7)  # larger pop for expanded role space
            hs_def = dict(population_size=30, hmcr=0.9,
                          par_min=0.1, par_max=0.9, bw_min=1, bw_max=3)

            if algo == "de":
                de_def.update(algo_kwargs)
                op  = AdaptiveDE(F=de_def["F"], CR=de_def["CR"])
                pop = de_def["population_size"]
                resolved_hyperparams = dict(de_def)
            else:
                hs_def.update(algo_kwargs)
                op  = DynamicHarmony(**{k: v for k, v in hs_def.items()
                                        if k != "population_size"})
                pop = hs_def["population_size"]
                resolved_hyperparams = dict(hs_def)

            metadata = {
                "variables": [str(v) for v in evaluator.vars],
                "n_variables": len(evaluator.vars),
                "algorithm": algo,
                "max_iter": max_iter,
                "seed": seed,
                "hyperparameters": resolved_hyperparams,
                "objective": "bic",   # multi-objective NSGA2 also ranks its Pareto "best" by BIC (column 0)
            }

            result = run_nsga(evaluator=evaluator, operator=op,
                              seed=seed, pop_size=pop,
                              max_iter=max_iter, n_jobs=n_jobs)
            # run_nsga()'s own result dict already carries search_stats/
            # stats_csv (see main_hpc.py's run_nsga()).

            # run_nsga()/NSGA2Engine.optimize() return "solutions"/"scores"
            # but never "best_solution"/"best_score" -- the sa/hc branch
            # above sets those, but this branch didn't, so callers using
            # extract_search_best() got best_bic=None / best_decision=None
            # even after a fully successful search (e.g. a clean 1750-gen,
            # 5+ hour HS run whose own per-generation log showed a
            # converged best BIC of 2722.5 the whole time). Downstream code
            # that does build_spec(best["best_decision"]) then crashes with
            # "TypeError: 'NoneType' object is not subscriptable" right
            # after the expensive search finished -- losing the run's
            # result was purely a missing-key bug, not a search failure.
            solutions = np.asarray(result.get("solutions"))
            scores    = np.asarray(result.get("scores"))
            if solutions.size and scores.size:
                if solutions.ndim == 1:
                    # Single-objective: optimize() already reduced to one
                    # best (decision, score) pair.
                    best_solution = solutions
                    best_score    = float(scores)
                else:
                    # Multi-objective: solutions/scores are the Pareto
                    # front. Pick the point minimising the primary
                    # objective (column 0, e.g. BIC) as "the" best.
                    best_idx      = int(np.argmin(scores[:, 0]))
                    best_solution = solutions[best_idx]
                    best_score    = float(scores[best_idx, 0])

                result["best_solution"] = best_solution
                result["best_score"]    = best_score
                result["model_spec"]     = evaluator.build_spec(best_solution)
                if result["model_spec"] is not None and getattr(evaluator, "cmf_metadata", None):
                    result["model_spec"] = {
                        **result["model_spec"],
                        "family": "cmf",
                        "metadata": dict(evaluator.cmf_metadata),
                    }

                print("\n  Best structure:")
                decode_best_solution(best_solution, evaluator)
                print(f"  Best BIC              : {best_score:.4f}")

                if refit:
                    refit_and_print(evaluator, best_solution)
                    save_run_summary_to_txt(evaluator, best_solution,
                                            algo, seed, config_id)
                else:
                    print("  [refit] skipped (refit=False)")
            else:
                print("  [warn] Harmony/DE search returned no solutions; "
                      "best_solution/best_score left unset.")

            metadata["elapsed_seconds"] = _time.time() - _t0
            if output_config is not None:
                result["saved_to"] = str(save_search_result(result, output_config, family="count", algorithm=algo, metadata=metadata))
            return result

        else:
            raise ValueError(f"Unknown algo '{algo}'. Choose: sa, hc, de, hs")

    def run_search(self, search_problem=None, **kwargs):
        output_config = kwargs.pop("output_config", None)
        search_problem = search_problem or self._evaluator
        if search_problem is None:
            raise RuntimeError("Call build_evaluator() or build_search() first.")

        if isinstance(search_problem, StructureEvaluatorLC):
            return self.run(evaluator=search_problem, output_config=output_config, **kwargs)

        if hasattr(search_problem, "run"):
            result = search_problem.run(**kwargs)
            if output_config is not None:
                family = result.get("family") or getattr(search_problem, "family", "search")
                algorithm = str(kwargs.get("algo", result.get("algorithm", "run")))
                result["saved_to"] = str(save_search_result(result, output_config, family=family, algorithm=algorithm))
            return result

        raise TypeError("Unsupported search problem type.")

    # ── helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _infer_type(s: pd.Series) -> str:
        n = s.nunique()
        if n == 2:                                         return "binary"
        if n <= 10 and (s % 1 == 0).all():                return "ordinal"
        if (s >= 0).all() and (s % 1 == 0).all():         return "count"
        return "continuous"

    @staticmethod
    def _suggest_roles_dists(col, s, vtype, max_lc=1):
        base_roles = [0, 1, 2]
        mem_roles  = ([7, 8] if max_lc > 1 else [])

        if vtype == "binary":
            return (
                base_roles + mem_roles,
                ["normal"],
                "Binary — fixed usually sufficient. "
                + ("Membership roles available (predicts class membership)."
                   if max_lc > 1 else "")
            )
        if vtype == "ordinal":
            return (
                [0, 1, 2] + mem_roles,
                ["normal"],
                "Ordinal — fixed or random-independent."
                + (" Role 7/8: could help explain class structure."
                   if max_lc > 1 else "")
            )
        if vtype == "count":
            return (
                [0, 1, 2, 3] + mem_roles,
                ["normal", "lognormal"],
                "Count covariate — lognormal if effect is strictly positive."
            )
        return (
            [0, 1, 2, 3, 5] + mem_roles,
            ["normal", "lognormal", "triangular"],
            "Continuous — full menu. Role 8 (mem+fixed) is useful for "
            "variables that explain both class membership and outcome level."
        )


# =====================================================================
# SPF Export Objective
# =====================================================================

def export_spf_per_class(
    fit_cache: dict,
    df: "pd.DataFrame",
    output_dir: str = "spf_exports",
    class_col: str = "FC",
) -> dict:
    """
    Compute the per-class SPF from a fitted model cache and write
    one SPF file per class (road functional class or peer group).

    Parameters
    ----------
    fit_cache : dict
        The fit cache dict from ExperimentBuilder._last_fit_cache,
        containing 'params', 'spec', 'data', 'bic'.
    df : pd.DataFrame
        The full dataframe used for the experiment, containing the
        class column (e.g. 'FC' for functional class).
    output_dir : str
        Directory to write SPF export files.
    class_col : str
        Column in df that defines the road class / peer group.
        Default 'FC' (functional class). For synthetic data use 'LANES'.

    Returns
    -------
    dict
        Mapping from class value to dict with 'a' (intercept), 'b' (AADT elasticity),
        'bic', 'loglik', 'n_obs', and 'formula' string.
    """
    import os
    import json
    import numpy as np
    import pandas as pd

    os.makedirs(output_dir, exist_ok=True)

    params = fit_cache.get("params")
    spec = fit_cache.get("spec")
    data = fit_cache.get("data")
    if params is None or spec is None or data is None:
        return {}

    # Identify class column in data
    if class_col not in data.columns:
        # Fallback: try common columns
        for fallback in ["FC", "URB", "LANES", "road_class", "road_type"]:
            if fallback in data.columns:
                class_col = fallback
                break

    # Extract fitted parameters
    # The parameter layout depends on spec:
    #   - alpha0, alphas (baseline), beta0, betas (local), theta (het), log_theta (NB)
    #   - For mixed models: sigmas after
    # We need to map back to the hierarchical form:
    #   log A(z1) = alpha0 + sum alpha_k * z1_k
    #   B(z2) = beta0 + sum beta_j * z2_j
    # For the export we want the hierarchical CMF form:
    #   N = A(z1) * AADT^{B(z2)}
    # where A(z1) = exp(alpha0 + sum alpha_k * z1_k)
    #       B(z2) = beta0 + sum beta_j * z2_j

    # For now, use the full dataset mean to represent the "average" road
    # This is a simplification; in production you'd extract per-class fitted values
    # The class column in the data gives the peer group
    class_values = data[class_col].unique()

    results = {}
    for c in class_values:
        mask = data[class_col] == c
        if mask.sum() < 10:
            continue

        # For this class, the intercept is the baseline at mean AADT
        # This is a simplification; true per-class intercept depends on class-specific covariates
        # For export we just report the overall fitted model parameters
        pass

    # For now, return a placeholder structure
    # TODO: implement full per-class extraction from the fitted model
    return {}


# =====================================================================
# Standalone helper functions (importable from metacountregressor)
# =====================================================================

def extract_summary(fit_result: dict) -> dict:
    """Safely extract the summary dict from a fit_manual_model result.

    Parameters
    ----------
    fit_result : dict
        Output of ``ExperimentBuilder.fit_manual_model()`` or
        ``CMFExperimentBuilder.fit_manual_cmf_model()``.

    Returns
    -------
    dict
        Keys: ``bic``, ``aic``, ``loglik``, ``num_parm``, ``n_obs``.
    """
    s = fit_result.get("summary")
    if s is not None and isinstance(s, dict) and "bic" in s:
        return s
    # Fallback: build a minimal dict from whatever is available
    return {
        "loglik":   s.get("loglik", float("nan")) if isinstance(s, dict) else float("nan"),
        "num_parm": s.get("num_parm", float("nan")) if isinstance(s, dict) else float("nan"),
        "n_obs":    s.get("n_obs", float("nan")) if isinstance(s, dict) else float("nan"),
        "aic":      s.get("aic", float("nan")) if isinstance(s, dict) else float("nan"),
        "bic":      s.get("bic", float("nan")) if isinstance(s, dict) else float("nan"),
    }


def extract_search_best(search_result: dict) -> dict:
    """Normalise search result keys from ``ExperimentBuilder.run()``.

    The ``run()`` method returns ``best_score`` and ``best_solution``.
    This helper returns a dict with canonical names so downstream code
    is resilient to future API changes.

    Parameters
    ----------
    search_result : dict
        Output of ``ExperimentBuilder.run()``.

    Returns
    -------
    dict
        Keys: ``best_bic``, ``best_decision``, ``scores``.
    """
    return {
        "best_bic":      search_result.get("best_score",
                            search_result.get("best_fitness")),
        "best_decision": search_result.get("best_solution",
                            search_result.get("best_decision")),
        "scores":        search_result.get("scores",
                            search_result.get("history")),
    }


def compare_models(fit_results: dict) -> "pd.DataFrame":
    """Build a comparison DataFrame from a dict of fit results.

    Parameters
    ----------
    fit_results : dict[str, dict]
        ``{model_name: fit_result}`` where each ``fit_result`` is the
        output of ``fit_manual_model()`` or ``fit_manual_cmf_model()``.

    Returns
    -------
    pandas.DataFrame
        Columns: ``Model``, ``BIC``, ``AIC``, ``Log-Likelihood``,
        ``Parameters``.  Sorted by BIC ascending.
    """
    import pandas as _pd  # local import to keep module import light
    rows = []
    for name, fit in fit_results.items():
        s = extract_summary(fit)
        rows.append({
            "Model":          name,
            "BIC":            s.get("bic", float("nan")),
            "AIC":            s.get("aic", float("nan")),
            "Log-Likelihood": s.get("loglik", float("nan")),
            "Parameters":     s.get("num_parm", float("nan")),
        })
    df = _pd.DataFrame(rows).sort_values("BIC")
    df.index = range(1, len(df) + 1)
    df.index.name = "Rank"
    return df


def make_synthetic_count_data(
    n_obs: int = 500,
    n_periods: int = 3,
    latent_classes: int = 0,
    seed: int = 42,
    include_membership: bool = False,
) -> "pd.DataFrame":
    """Generate synthetic count data with a known true DGP.

    Creates a panel dataset with 5 outcome covariates (x1..x5),
    optional latent classes with membership covariates (z1, z2),
    and NB2-distributed counts.  Useful for step-by-step tutorials,
    method demonstrations, and recovery tests.

    Parameters
    ----------
    n_obs : int
        Number of individuals (if ``n_periods > 1``) or total observations.
    n_periods : int
        Time periods per individual.  Set to 1 for cross-sectional data.
    latent_classes : int
        Number of latent classes (0 = no latent classes, single-class model).
        When ``latent_classes >= 2``, data are drawn from a mixture with
        different parameter vectors per class.
    seed : int
        Random seed for reproducibility.
    include_membership : bool
        When ``True`` and ``latent_classes >= 2``, add membership covariates
        z1, z2 whose values drive class assignment probabilities.

    Returns
    -------
    pandas.DataFrame
        Columns: ``id``, ``t`` (if ``n_periods > 1``),
        ``x1``..``x5``, ``z1``, ``z2`` (if membership),
        ``y`` (count outcome), and ``true_class`` (if latent_classes >= 2).

    Examples
    --------
    >>> from metacountregressor import make_synthetic_count_data
    >>> df = make_synthetic_count_data(n_obs=500, n_periods=3)
    >>> print(df.head())

    >>> df_lc = make_synthetic_count_data(
    ...     latent_classes=2, include_membership=True,
    ... )
    """
    rng = np.random.default_rng(seed)
    rows = []
    true_classes = []
    panel = n_periods > 1
    N = n_obs
    C = latent_classes

    if C < 2:
        C = 1

    n_vars = 5

    if C >= 2:
        betas = [rng.normal(0.0, 0.5, size=n_vars + 1) for _ in range(C)]
        alphas = [rng.uniform(0.3, 2.0) for _ in range(C)]
        gam = None
        if include_membership:
            gam = np.zeros((C - 1, 3))
            gam[:, 1:] = np.array([[+1.5, -1.0], [-0.8, +1.2]])[:C - 1, :2]
    else:
        betas = [rng.normal(0.0, 0.5, size=n_vars + 1)]
        alphas = [rng.uniform(0.3, 2.0)]
        gam = None

    for i in range(N):
        x = rng.normal(0.0, 1.0, size=n_vars)
        z_data = np.zeros(2) if not include_membership else rng.normal(0.0, 1.0, size=2)
        z1_val, z2_val = float(z_data[0]), float(z_data[1])

        if C >= 2:
            if gam is not None:
                logit = np.zeros(C)
                for c in range(1, C):
                    log_odds = gam[c - 1, 0] + gam[c - 1, 1] * z1_val + gam[c - 1, 2] * z2_val
                    logit[c] = log_odds
                probs = np.exp(logit) / np.exp(logit).sum()
            else:
                probs = np.ones(C) / C
            class_idx = int(rng.choice(C, p=probs))
        else:
            class_idx = 0
        true_classes.append(class_idx if C >= 2 else 0)

        b = betas[class_idx]
        a = alphas[class_idx]

        for t in range(max(n_periods, 1)):
            eta = b[0]
            for k in range(n_vars):
                eta += b[k + 1] * x[k]
            mu = np.exp(np.clip(float(eta), -20.0, 20.0))
            p_nb = a / (a + mu)
            y = int(rng.negative_binomial(a, p_nb))
            row = {"id": i, "y": y}
            for k in range(n_vars):
                row[f"x{k + 1}"] = float(x[k])
            if include_membership:
                row["z1"] = z1_val
                row["z2"] = z2_val
            if panel:
                row["t"] = t
            rows.append(row)

    df = pd.DataFrame(rows)
    if C >= 2:
        df["true_class"] = [true_classes[int(r["id"])] for _, r in df.iterrows()] if panel else true_classes

    return df


def print_fit(fit_result: dict, file=None) -> None:
    """Pretty-print the formatted model summary from a fit result.

    Works with the dictionary returned by ``fit_manual_model()``, including
    older fit dicts that were computed before ``FitResult`` was introduced.

    Parameters
    ----------
    fit_result : dict
        Output of ``ExperimentBuilder.fit_manual_model()`` or
        ``CMFExperimentBuilder.fit_manual_cmf_model()``.
    file : file-like, optional
        Where to write the output.  Defaults to ``sys.stdout``.

    Examples
    --------
    >>> fit = builder.fit_manual_model(manual_spec=..., model='nb', R=500)
    >>> print_fit(fit)
    """
    import sys as _sys
    out = file or _sys.stdout
    text = fit_result.get("_summary_text")
    if text:
        out.write(text)
        return

    summary = fit_result.get("summary", {})
    if isinstance(summary, dict):
        out.write("────────────────── Model Fit Summary ──────────────────\n")
        for k in ("loglik", "num_parm", "n_obs", "aic", "bic"):
            v = summary.get(k)
            if v is not None:
                out.write(f"  {k:>12}: {v:,.4f}\n" if isinstance(v, (int, float)) else f"  {k:>12}: {v}\n")
        out.write("──────────────────────────────────────────────────────\n")


# =====================================================================
# SPF Export and Conversion Functions
# =====================================================================

def extract_hierarchical_coefficients(params, spec, param_index):
    """
    Extract hierarchical coefficients (A and B components) from fitted parameters.
    
    The model structure is:
    log mu = alpha_0 + sum_k alpha_k * z1_k + (beta_0 + sum_j beta_j * z2_j) * log(AADT)
    
    This can be written as:
    log mu = log A(z1) + B(z2) * log(AADT)
    where:
    - log A(z1) = alpha_0 + sum_k alpha_k * z1_k
    - B(z2) = beta_0 + sum_j beta_j * z2_j
    
    Parameters
    ----------
    params : array
        Fitted parameter vector
    spec : ModelSpec
        Model specification
    param_index : dict
        Parameter index from build_param_index
    
    Returns
    -------
    dict
        Dictionary containing:
        - alpha_0: intercept
        - alpha: array of upper-level coefficients (for z1)
        - beta_0: baseline elasticity
        - beta: array of lower-level coefficients (for z2)
        - log_A_intercept: alpha_0 (log A at z1=0)
        - A_at_mean_z1: exp(alpha_0 + sum alpha_k * mean(z1_k))
        - B_at_mean_z2: beta_0 + sum beta_j * mean(z2_j)
        - AADT_elasticity_at_mean_z2: beta_0 + sum beta_j * mean(z2_j)
    """
    # Build base parameter index for single-class model
    from main_hpc_lc_patch import build_base_index
    
    # For single-class model, use base parameter index
    pidx = build_base_index(spec)
    
    # Extract fixed effects
    fixed_start, fixed_end = param_index.get("fixed", (0, 0))
    fixed_params = params[fixed_start:fixed_end]
    
    # The fixed effects layout for CMF models:
    # fixed = [intercept, upper_coeffs..., beta_0, lower_coeffs...]
    # where upper = baseline covariates (z1), lower = elasticity covariates (z2)
    n_fixed = len(fixed_params)
    if n_fixed == 0:
        return {}
    
    # Infer n_upper and n_lower from spec structure
    # Kf = 1 (intercept) + n_upper + 1 (beta_0) + n_lower + Kzi
    Kzi = getattr(spec, 'Kzi', 0)
    n_upper_lower = spec.Kf - 1 - Kzi - 1  # -1 for intercept, -1 for beta_0
    n_upper = n_upper_lower // 2
    n_lower = n_upper_lower - n_upper
    
    alpha_0 = fixed_params[0]
    alpha = fixed_params[1:1+n_upper] if n_upper > 0 else np.array([])
    beta_0 = fixed_params[1+n_upper] if n_fixed > 1+n_upper else 1.0
    beta = fixed_params[2+n_upper:2+n_upper+n_lower] if n_lower > 0 else np.array([])
    
    return {
        "alpha_0": float(alpha_0),
        "alpha": alpha.astype(float),
        "beta_0": float(beta_0),
        "beta": beta.astype(float),
        "log_A_intercept": float(alpha_0),
        "n_upper": n_upper,
        "n_lower": n_lower,
    }


def hierarchical_to_spf(hierarchical_coeffs, spec, aadt_mean=None, length_mean=None):
    """
    Convert hierarchical coefficients to SPF form for reporting.
    
    The hierarchical model is:
    N = A(z1) * AADT^{B(z2)}
    where A(z1) = exp(alpha_0 + alpha^T * z1)
          B(z2) = beta_0 + beta^T * z2
    
    Parameters
    ----------
    hierarchical_coeffs : dict
        Output from extract_hierarchical_coefficients
    spec : ModelSpec
        Model specification
    aadt_mean : float, optional
        Mean AADT for evaluating at mean exposure
    length_mean : float, optional
        Mean segment length for exposure offset
    
    Returns
    -------
    dict
        Dictionary with SPF components for reporting
    """
    alpha_0 = hierarchical_coeffs.get("alpha_0", 0)
    alpha = hierarchical_coeffs.get("alpha", np.array([]))
    beta_0 = hierarchical_coeffs.get("beta_0", 1.0)
    beta = hierarchical_coeffs.get("beta", np.array([]))
    
    # Component A: baseline crash propensity
    log_A = alpha_0  # at z1 = 0
    A_at_zero = np.exp(alpha_0)
    
    # Component B: AADT elasticity
    B_at_zero = beta_0  # at z2 = 0
    
    # CMF components
    cmf_A = {f"z1_{i}": np.exp(float(a)) for i, a in enumerate(alpha)}
    cmf_B = {f"z2_{j}": float(b) for j, b in enumerate(beta)}
    
    # Exposure elasticity at mean
    if aadt_mean is not None:
        aadt_elasticity = beta_0
    else:
        aadt_elasticity = None
    
    return {
        "A": {
            "log_A_intercept": float(alpha_0),
            "A_at_zero": float(A_at_zero),
            "alpha_coefficients": {f"z1_{i}": float(a) for i, a in enumerate(alpha)},
        },
        "B": {
            "B_at_zero": float(B_at_zero),
            "beta_coefficients": {f"z2_{j}": float(b) for j, b in enumerate(beta)},
        },
        "exposure_elasticity": aadt_elasticity,
        "model_form": "N = A(z1) * AADT^{B(z2)}",
        "log_mu_form": "log(mu) = log(A) + B(z2) * log(AADT)",
    }


def export_spf_report(fit_cache, df, output_dir="spf_exports", class_col="FC"):
    """
    Export SPF report for each class (road functional class or peer group).
    
    Parameters
    ----------
    fit_cache : dict
        Fit cache from ExperimentBuilder._last_fit_cache
    df : pd.DataFrame
        Full dataframe with class column
    output_dir : str
        Directory to write export files
    class_col : str
        Column name for class/road type (e.g., 'FC', 'LANES', 'road_class')
    
    Returns
    -------
    dict
        Dictionary with per-class SPF reports
    """
    import os
    import json
    import numpy as np
    import pandas as pd
    
    os.makedirs(output_dir, exist_ok=True)
    
    params = fit_cache.get("params")
    spec = fit_cache.get("spec")
    data = fit_cache.get("data")
    
    if params is None or spec is None or data is None:
        return {}
    
    # Build param index
    from main_hpc_lc_patch import build_param_index
    param_index = build_param_index(spec)
    
    # Extract hierarchical coefficients
    hier_coeffs = extract_hierarchical_coefficients(params, spec, param_index)
    spf = hierarchical_to_spf(hier_coeffs, spec)
    
    # Find class column
    class_col_actual = class_col
    if class_col not in data.columns:
        for fallback in ["FC", "URB", "LANES", "road_class", "road_type", "road_type_id"]:
            if fallback in data.columns:
                class_col_actual = fallback
                break
    
    class_values = data[class_col_actual].unique()
    results = {}
    
    for c in class_values:
        mask = data[class_col_actual] == c
        if mask.sum() < 10:
            continue
        
        # For each class, the SPF is the same functional form
        # but evaluated at class-specific z1, z2 means
        class_data = data[mask]
        z1_cols = [c for c in data.columns if c.startswith("z1") or c in ["z1"]]
        z2_cols = [c for c in data.columns if c.startswith("z2") or c in ["z2"]]
        
        z1_mean = class_data[z1_cols].mean() if z1_cols else np.array([0.0])
        z2_mean = class_data[z2_cols].mean() if z2_cols else np.array([0.0])
        
        # Evaluate A and B at class means
        alpha = hierarchical_coeffs.get("alpha", np.array([]))
        beta = hierarchical_coeffs.get("beta", np.array([]))
        alpha_0 = hierarchical_coeffs.get("alpha_0", 0)
        beta_0 = hierarchical_coeffs.get("beta_0", 1.0)
        
        log_A = alpha_0 + float(np.sum(alpha * z1_mean))
        B_val = beta_0 + float(np.sum(hierarchical_coeffs.get("beta", np.array([])) * z2_mean))
        
        A_val = np.exp(log_A)
        B_val = B_val
        
        # CMFs for this class
        alpha = hierarchical_coeffs.get("alpha", np.array([]))
        beta = hierarchical_coeffs.get("beta", np.array([]))
        cmf_A = {f"z1_{i}": float(np.exp(a)) for i, a in enumerate(hierarchical_coeffs.get("alpha", np.array([])))}
        cmf_B = {f"z2_{j}": float(b) for j, b in enumerate(hierarchical_coeffs.get("beta", np.array([])))}
        
        results[c] = {
            "class": c,
            "n_obs": int(mask.sum()),
            "A": {
                "log_A": float(log_A),
                "A_at_class_mean": float(A_val),
            },
            "B": {
                "B_at_class_mean": float(B_val),
                "beta_0": float(beta_0),
            },
            "CMF_A": cmf_A,
            "CMF_B": cmf_B,
            "exposure_elasticity": float(B_val),
            "model_form": "N = A * AADT^B",
        }
    
    # Save to file
    output_file = os.path.join(output_dir, "spf_export.json")
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    # Also save a human-readable summary
    summary_file = os.path.join(output_dir, "spf_export_summary.txt")
    with open(summary_file, 'w') as f:
        f.write("SPF Export Summary\n")
        f.write("=" * 60 + "\n\n")
        for c, r in results.items():
            f.write(f"Class {c} (n={r['n_obs']}):\n")
            f.write(f"  A = {r['A']['A_at_class_mean']:.4f}\n")
            f.write(f"  B = {r['B']['B_at_class_mean']:.4f}\n")
            f.write(f"  CMF_A: {r['CMF_A']}\n")
            f.write(f"  CMF_B: {r['CMF_B']}\n")
            f.write(f"  Exposure Elasticity (at mean AADT): {r['exposure_elasticity']:.4f}\n")
            f.write("\n")
    
    return results


def plot_spf_functions(results, aadt_range=None, output_dir="spf_exports"):
    """
    Plot SPF functions for each class.
    
    Parameters
    ----------
    results : dict
        Output from export_spf_report
    aadt_range : tuple, optional
        (min_aadt, max_aadt) for plotting range
    output_dir : str
        Directory to save plots
    """
    import os
    import matplotlib.pyplot as plt
    import numpy as np
    
    os.makedirs(output_dir, exist_ok=True)
    
    if aadt_range is None:
        aadt_range = (1000, 100000)
    
    aadt_vals = np.logspace(np.log10(aadt_range[0]), np.log10(aadt_range[1]), 100)
    
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    
    # Plot 1: Crash frequency vs AADT for each class
    ax = axes[0]
    for c, r in results.items():
        A = r['A']['A_at_class_mean']
        B = r['B']['B_at_class_mean']
        preds = A * np.power(aadt_vals, B)
        axes[0].plot(aadt_vals, preds, label=f"Class {c}", linewidth=2)
    
    axes[0].set_xscale('log')
    axes[0].set_yscale('log')
    axes[0].set_xlabel('AADT (veh/day)')
    axes[0].set_ylabel('Predicted Crashes per Year')
    axes[0].set_title('SPF Curves by Class')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    
    # Plot 2: CMF comparison
    ax = axes[1]
    for c, r in results.items():
        B = r['B']['B_at_class_mean']
        cmf = np.power(aadt_vals / 10000, B)  # CMF relative to 10k AADT
        axes[1].plot(aadt_vals, cmf, label=f"Class {c}", linewidth=2)
    
    axes[1].axhline(y=1, color='k', linestyle='--', alpha=0.5)
    axes[1].set_xscale('log')
    axes[1].set_xlabel('AADT (veh/day)')
    axes[1].set_ylabel('CMF (relative to 10,000 AADT)')
    axes[1].set_title('CMF Curves (AADT Elasticity)')
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plot_file = os.path.join(output_dir, "spf_curves.png")
    plt.savefig(plot_file, dpi=150, bbox_inches='tight')
    plt.close()
    
    # Save CMF table
    cmf_table = []
    for c, r in results.items():
        B = r['B']['B_at_class_mean']
        for aadt_ref in [5000, 10000, 20000, 50000, 100000]:
            cmf = (aadt_ref / 10000) ** r['B']['B_at_class_mean']
            cmf_table.append({
                "class": c,
                "AADT": aadt_ref,
                "CMF": cmf,
                "elasticity": r['B']['B_at_class_mean']
            })
    
    cmf_df = pd.DataFrame(cmf_table)
    cmf_file = os.path.join(output_dir, "cmf_table.csv")
    cmf_df.to_csv(cmf_file, index=False)
    
    return fig
