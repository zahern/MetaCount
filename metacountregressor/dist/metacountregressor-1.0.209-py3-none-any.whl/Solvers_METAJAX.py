import numpy as np
import jax
import gc

plt = None


def _ensure_plt():
    global plt
    if plt is None:
        import matplotlib.pyplot as _plt
        plt = _plt
    return plt

import os
import psutil
import time




def save_plot(fig, filename, folder="results"):
    _ensure_plt()
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, filename)
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"[OK] Saved plot: {path}")


def format_time(seconds):
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    return f"{h:02d}:{m:02d}:{s:02d}"

def print_memory_usage(tag=""):
    process = psutil.Process(os.getpid())
    mem_mb = process.memory_info().rss / (1024 ** 2)
    print(f"[MEMORY] {tag} RSS: {mem_mb:.2f} MB")

def force_gc():
    gc.collect()


import numpy as np
from joblib import Parallel, delayed


import pickle


import numpy as np
ROLE_PROBS = np.array([
    0.35,  # 0 – Excluded
    0.12,  # 1 – Fixed
    0.15,  # 2 – Random Independent
    0.14,  # 3 – Random Correlated
    0.00,  # 4 – Grouped
    0.05,  # 5 – Heterogeneity in means
    0.05,  # 6 – Zero Inflation
    0.05,  # 7 – Membership only
    0.05,  # 8 – Membership + fixed outcome
    0.04,  # 9 – Heterogeneity in variances
])

ROLE_PROBS = ROLE_PROBS / ROLE_PROBS.sum()


# ── Mutual-exclusion helpers ──────────────────────────────────────────

def _count_mutex_violations(roles, vars_list, mutex_groups):
    """Return number of mutual-exclusion groups with >1 active variable."""
    violations = 0
    for group in mutex_groups:
        active = 0
        for i, v in enumerate(vars_list):
            if v in group and int(roles[i]) != 0:
                active += 1
        if active > 1:
            violations += 1
    return violations


def _repair_mutex(roles, vars_list, mutex_groups, rng=None):
    """Force at most one active variable per mutual-exclusion group.

    If multiple variables in a group have role != 0, keep only the
    first one and set the rest to 0.
    """
    if rng is None:
        rng = np.random
    for group in mutex_groups:
        kept = False
        for i, v in enumerate(vars_list):
            if v in group and int(roles[i]) != 0:
                if not kept:
                    kept = True
                else:
                    roles[i] = 0
    return roles


class AdvancedSimulatedAnnealing:

    def __init__(self,
                 evaluator,
                 dimension,
                 max_iter=5000,        # more iterations for larger search space
                 max_time=None,
                 T0=None,
                 alpha=0.995,
                 mutation_rate=0.3,
                 min_changes=1,
                 max_changes=5,        # larger for 10-role space
                 adaptive=True,
                 step_size=1,
                 archive_limit=100,
                 restart_threshold=500, patience=400, tol=1e-6,
                 init_solution=None,
                 on_iteration=None,
                 cache_clear_every=10):

        self.init_solution = None
        if init_solution is not None:
            cand = np.asarray(init_solution, dtype=float).reshape(-1)
            if cand.size == dimension and np.all(np.isfinite(cand)):
                self.init_solution = np.rint(cand).astype(int)
        self.tol = tol
        self.patience = patience
        self.mutation_rate = mutation_rate
        self.min_changes = min_changes
        self.max_changes = max_changes
        self.step_size = step_size
        self.evaluator = evaluator
        self.dim = dimension
        self.dim_core = len(evaluator.vars)  # D = number of variables
        self.max_iter = max_iter

        self.T0 = T0
        self.alpha = alpha
        self.adaptive = adaptive
        self.step_size = step_size
        self.max_time = max_time
        # Optional per-generation hook: on_iteration(gen, best_decision,
        # best_score, elapsed, temperature).  Used by ExperimentBuilder to
        # checkpoint the best-so-far structure during long searches so a
        # walltime kill / OOM leaves a resumable incumbent behind.
        self.on_iteration = on_iteration if callable(on_iteration) else None
        # Generations between force_gc()+jax.clear_caches() calls. Every new
        # structure JIT-compiles fresh XLA executables; without periodic
        # clearing, RSS grows for the whole search (OOM on 15-min panels).
        self.cache_clear_every = int(cache_clear_every) if cache_clear_every else 0

        self.archive_limit = archive_limit
        self.restart_threshold = restart_threshold
        self.runtime = time.time()
        self.archive = []
        self.archive_scores = []
        self.hypervolume_history = []
        self.convergence = []
        self.search_stats = []
        self.runtime = None
        self.total_iterations = 0

    
    def finalize_plots(self, algo="sa", seed=0, folder="results"):
        _ensure_plt()
        timestamp = time.strftime("%Y%m%d_%H%M%S")

        # ==========================
        # SINGLE OBJECTIVE
        # ==========================
        if len(self.convergence) > 0 and not self.is_multiobjective(self.archive_scores[0]):

            fig = plt.figure()
            plt.plot(self.convergence)
            plt.xlabel("Iteration")
            plt.ylabel("Best Fitness")
            plt.title("SA Convergence (Single Objective)")
            plt.grid(True)

            save_plot(fig, f"{algo}_convergence_seed{seed}_{timestamp}.png", folder)

        # ==========================
        # MULTI OBJECTIVE
        # ==========================
        if len(self.hypervolume_history) > 0:

            # Hypervolume trace
            fig = plt.figure()
            plt.plot(self.hypervolume_history)
            plt.xlabel("Iteration")
            plt.ylabel("Hypervolume")
            plt.title("SA Hypervolume Convergence")
            plt.grid(True)

            save_plot(fig, f"{algo}_hypervolume_seed{seed}_{timestamp}.png", folder)

            # Pareto front
            if len(self.archive_scores) > 0:
                scores = np.array(self.archive_scores)

                if scores.ndim > 1 and scores.shape[1] >= 2:
                    fig = plt.figure()
                    plt.scatter(scores[:, 0], scores[:, 1])
                    plt.xlabel("Objective 1")
                    plt.ylabel("Objective 2")
                    plt.title("Final Pareto Front (SA)")
                    plt.grid(True)

                    save_plot(fig, f"{algo}_pareto_seed{seed}_{timestamp}.png", folder)
        
    # =========================================================
    # Objective handling
    # =========================================================
    def is_multiobjective(self, score):
        return isinstance(score, np.ndarray) and score.ndim > 0

    def dominates(self, a, b):
        return np.all(a <= b) and np.any(a < b)

    # =========================================================
    # Temperature
    # =========================================================
    def temperature(self, gen):
        return self.T0 * (self.alpha ** gen)

    def is_feasible(self, solution):

            D = self.dim_core
            roles = solution[:D]

            # Rule 1:
            # If role 5 exists → must have at least one 2 or 3
            if 5 in roles:
                if not (2 in roles or 3 in roles):
                    return False

            # Rule 1b:
            # If role 9 exists → must have at least one 2 or 3 or 4
            if 9 in roles:
                if not (2 in roles or 3 in roles or 4 in roles):
                    return False

            # Rule 2: mutual exclusion – at most one active per group
            mutex = getattr(self.evaluator, "mutual_exclusion", None)
            if mutex:
                if _count_mutex_violations(roles, self.evaluator.vars, mutex) > 0:
                    return False

            return True


    def repair(self, solution):

            D = self.dim_core
            roles = solution[:D]

            # Rule:
            # If role 5 exists → must also have at least one 2 or 3
            if 5 in roles and not (2 in roles or 3 in roles):

                zero_idx = np.where(roles == 0)[0]

                if len(zero_idx) > 0:
                    # Activate one zero as 2 or 3
                    roles[np.random.choice(zero_idx)] = np.random.choice([2, 3])
                else:
                    # Force-convert one variable
                    idx = np.random.randint(D)
                    roles[idx] = np.random.choice([2, 3])

            # Rule:
            # If role 9 exists → must also have at least one 2, 3, or 4
            if 9 in roles and not (2 in roles or 3 in roles or 4 in roles):

                zero_idx = np.where(roles == 0)[0]

                if len(zero_idx) > 0:
                    # Activate one zero as 2, 3, or 4
                    roles[np.random.choice(zero_idx)] = np.random.choice([2, 3, 4])
                else:
                    # Force-convert one variable
                    idx = np.random.randint(D)
                    roles[idx] = np.random.choice([2, 3, 4])

            # Mutual-exclusion repair: keep only the first active in each group
            mutex = getattr(self.evaluator, "mutual_exclusion", None)
            if mutex:
                roles = _repair_mutex(roles, self.evaluator.vars, mutex, rng=np.random)

            solution[:D] = roles
            
            return solution
    
    
    
    def sample_allowed_role(self, var_index, force_active=False):
        var_name = self.evaluator.vars[var_index]
        allowed = self.evaluator.allowed_roles[var_name]

        # ── Ban check: if variable is banned and not force-included, only role 0 ──
        banned = getattr(self.evaluator, "_banned_variables", set())
        force_inc = getattr(self.evaluator, "_force_included_vars", set())
        if var_name in banned and var_name not in force_inc:
            return 0  # permanently excluded unless analyst forced-included it

        # If we require non-zero role
        if force_active:
            allowed = [r for r in allowed if r != 0]

        if len(allowed) == 0:
            return 0  # fallback safety

        if len(allowed) == 1:
            return allowed[0]

        allowed = np.array(allowed)
        probs = ROLE_PROBS[allowed].copy()

        # --- UCB bandit: suppress variables with high sign-violation rates ---
        # When the evaluator has accumulated sign-violation statistics from
        # _check_sign_violations(), use a UCB-1 style score to downweight
        # activation (role != 0) of variables that consistently produce
        # wrong-sign coefficients.
        if (not force_active
                and 0 in allowed
                and hasattr(self.evaluator, '_sign_violation_counts')
                and hasattr(self.evaluator, '_sign_visit_counts')):
            n_visits = self.evaluator._sign_visit_counts.get(var_name, 0)
            n_viol = self.evaluator._sign_violation_counts.get(var_name, 0)
            if n_visits >= 3:
                # Violation rate in [0, 1]; apply a soft exclusion boost
                viol_rate = n_viol / n_visits
                if viol_rate >= 0.5:
                    # Boost the probability mass on role=0 proportional to rate
                    excl_boost = viol_rate  # 0.5 → ×1.5×, 1.0 → ×2.0×
                    excl_idx = np.where(allowed == 0)[0]
                    probs[excl_idx] *= (1.0 + excl_boost)

        probs = probs / probs.sum()
        return np.random.choice(allowed, p=probs)
    
    
    # =========================================================
    # Neighbor
    # =========================================================
    def generate_neighbor(self, solution, T=None, max_attempts=20, min_active=2):

        for _ in range(max_attempts):

            neighbor = solution.copy()

            # ---------------------------------
            # Determine mutation rate
            # ---------------------------------
            if T is not None and self.T0 is not None:
                temp_scale = T / self.T0
                mutation_rate = self.mutation_rate * temp_scale
            else:
                mutation_rate = self.mutation_rate

            mutation_rate = min(1.0, max(0.0, mutation_rate))

            # ---------------------------------
            # Decide how many variables to change
            # ---------------------------------
            n_changes = np.random.randint(
                self.min_changes,
                self.max_changes + 1
            )

            indices = np.random.choice(
                self.dim,
                size=n_changes,
                replace=False
            )

            changed = False

            # ---------------------------------
            # Apply mutations
            # ---------------------------------
            for idx in indices:

                if np.random.rand() < mutation_rate:

                    old_value = neighbor[idx]

                    # Force real step
                    step = 0
                    while step == 0:
                        step = np.random.randint(
                            -self.step_size,
                            self.step_size + 1
                        )

                    D = self.dim_core

                    if idx < D:
                        # role mutation → weighted
                        neighbor[idx] = self.sample_allowed_role(idx)
                    elif idx < 2*D:
                        # distribution code mutation
                        neighbor[idx] = np.random.randint(0, 6)
                    elif idx == 2*D:
                        # dispersion bit: toggle 0<->1 (Poisson <-> NB2)
                        neighbor[idx] = 1 - neighbor[idx]
                    elif idx == 2*D + 1:
                        # lc_code gene (only present when max_latent_classes > 1)
                        max_lc = getattr(self.evaluator, 'max_latent_classes', 1)
                        if max_lc > 1:
                            neighbor[idx] = np.random.randint(0, max_lc)
                    else:
                        # class_mask genes (per-class variable assignments)
                        # 0=all classes, 1=class1 only, ..., C=class C only
                        max_lc2 = getattr(self.evaluator, 'max_latent_classes', 1)
                        if max_lc2 > 1:
                            neighbor[idx] = np.random.randint(0, max_lc2 + 1)

                    changed = True

            # ---------------------------------
            # [OK] Enforce minimum active constraint
            # ---------------------------------
            D = self.dim_core
            active_count = np.sum(neighbor[:D] != 0)

            if active_count < min_active:

                zero_indices = np.where(neighbor[:D] == 0)[0]

                if len(zero_indices) > 0:
                    activate = np.random.choice(
                        zero_indices,
                        size=min_active - active_count,
                        replace=False
                    )
                    for j in activate:
                        neighbor[j] = self.sample_allowed_role(j, force_active=True)
                    

            # ---------------------------------
            # Return if valid and changed
            # ---------------------------------
            
            neighbor = self.repair(neighbor)
            if (
                    changed
                    and not self.is_same(neighbor, solution)
                ):
                return neighbor

        # ---------------------------------
        # 🔴 Fallback: force valid change
        # ---------------------------------
        neighbor = solution.copy()

        # ensure at least min_active nonzeros
        #active_count = np.sum(neighbor != 0)
        active_count = np.sum(neighbor[:self.dim_core] != 0)
        if active_count < min_active:
            zero_indices = np.where(neighbor == 0)[0]
            activate = np.random.choice(
                zero_indices,
                size=min_active - active_count,
                replace=False
            )
            neighbor[activate] = np.random.randint(1, 6, size=len(activate))

        else:
            # force one mutation
            idx = np.random.randint(0, self.dim_core)

            var_name = self.evaluator.vars[idx]
            allowed = self.evaluator.allowed_roles[var_name]

            old = neighbor[idx]

            possible = [v for v in allowed if v != old]

            if len(possible) == 0:
                return neighbor  # nothing else allowed

            neighbor[idx] = np.random.choice(possible)
        
        if self.is_same(solution, neighbor):
            return self.generate_neighbor(solution, T, min_active=min_active+1)
        return neighbor
    
    def is_same(self, nbr, sol):
        nbr_spec = self.evaluator.build_spec(nbr)
        sol_spec = self.evaluator.build_spec(sol)
        if nbr_spec is None or sol_spec is None:
            return False

        a = self.evaluator.structural_signature(nbr_spec)
        b = self.evaluator.structural_signature(sol_spec)
        if a is None or b is None:
            return False

        if a == b:
            return True
        else:
            return False
        
    #========================================
    # Crowding pruning
    # =========================================================
    def prune_archive(self):

        if len(self.archive_scores) <= self.archive_limit:
            return

        scores = np.array(self.archive_scores)

        distances = np.zeros(len(scores))

        for m in range(scores.shape[1]):
            order = np.argsort(scores[:, m])
            distances[order[0]] = distances[order[-1]] = np.inf

            min_val = scores[order[0], m]
            max_val = scores[order[-1], m]

            if max_val - min_val == 0:
                continue

            for i in range(1, len(scores)-1):
                distances[order[i]] += (
                    scores[order[i+1], m] -
                    scores[order[i-1], m]
                ) / (max_val - min_val)

        keep = np.argsort(-distances)[:self.archive_limit]

        self.archive = [self.archive[i] for i in keep]
        self.archive_scores = [self.archive_scores[i] for i in keep]

    # =========================================================
    # Hypervolume (2D minimization)
    # =========================================================
    def compute_hypervolume(self):

        if len(self.archive_scores) < 2:
            return 0.0

        scores = np.array(self.archive_scores)

        if scores.ndim == 1:
            return 0.0  # single objective

        ref = np.max(scores, axis=0) * 1.1

        sorted_pts = scores[np.argsort(scores[:, 0])]

        hv = 0.0
        prev_f1 = ref[0]

        for f1, f2 in reversed(sorted_pts):
            width = prev_f1 - f1
            height = ref[1] - f2
            if width > 0 and height > 0:
                hv += width * height
            prev_f1 = f1

        return hv

    # =========================================================
    # Archive update
    # =========================================================
    def update_archive(self, solution, score):

        if not self.is_multiobjective(score):
            # Single objective
            if len(self.archive) == 0 or score < self.archive_scores[0]:
                self.archive = [solution.copy()]
                self.archive_scores = [score]
            return

        keep = []

        for s, sc in zip(self.archive, self.archive_scores):
            if self.dominates(score, sc):
                continue
            keep.append((s, sc))

        self.archive = [k[0] for k in keep]
        self.archive_scores = [k[1] for k in keep]

        dominated = False
        for sc in self.archive_scores:
            if self.dominates(sc, score):
                dominated = True
                break

        if not dominated:
            self.archive.append(solution.copy())
            self.archive_scores.append(score.copy())

        self.prune_archive()

    
    def estimate_initial_temperature_single(self,
                                        solution,
                                        samples=100,
                                        target_accept=0.8):

        deltas = []

        f_current = self.evaluator.fitness(solution)
        if not np.isfinite(f_current):
            return 1.0

        for _ in range(samples):

            neighbor = self.generate_neighbor(solution)
            f_neighbor = self.evaluator.fitness(neighbor)
            if not np.isfinite(f_neighbor):
                continue

            delta = f_neighbor - f_current

            if delta > 0:
                deltas.append(delta)

        if len(deltas) == 0:
            return 1.0

        avg_delta = np.mean(deltas)

        return -avg_delta / np.log(target_accept)
    
    def estimate_initial_temperature_multi(self,
                                       solution,
                                       samples=100,
                                       target_accept=0.8):

        deltas = []

        f_current = self.evaluator.fitness(solution)

        for _ in range(samples):

            neighbor = self.generate_neighbor(solution)
            f_neighbor = self.evaluator.fitness(neighbor)

            if self.dominates(f_current, f_neighbor):
                # neighbor is worse
                delta = np.linalg.norm(f_neighbor - f_current)
                deltas.append(delta)

        if len(deltas) == 0:
            return 1.0
        
        avg_delta = np.mean(deltas)
        avg_delta = np.mean(deltas[np.isfinite(deltas)])

        return -avg_delta / np.log(target_accept)
    
    def auto_temperatureold(self,
                     solution,
                     samples=100,
                     target_accept=0.8):

        score = self.evaluator.fitness(solution)

        if isinstance(score, np.ndarray):
            return self.estimate_initial_temperature_multi(
                solution,
                samples,
                target_accept
            )
        else:
            return self.estimate_initial_temperature_single(
                solution,
                samples,
                target_accept
            )
    
    
    def is_valid_fitness(self, score, max_allowed=1e12):

        if not np.all(np.isfinite(score)):
            return False
        
        if np.any(score < 0):
            return False   # <--- add this

        if np.any(score >= max_allowed):
            return False

        return True
    
    def auto_temperature(self, solution, samples=25, target_accept=0.8):
        
        f_current = self.evaluator.fitness(solution)
        deltas = []

        for _ in range(samples):

            neighbor = self.generate_neighbor(solution)
            neighbor = self.repair(neighbor)
            f_neighbor = self.evaluator.fitness(neighbor)
            if not self.is_valid_fitness(f_neighbor, max_allowed=1e20):
                continue

            delta = self.energy_difference(f_current, f_neighbor)

            if delta > 0 and np.isfinite(delta):
                deltas.append(delta)

        if len(deltas) == 0:
            return 1.0

        avg_delta = np.mean(deltas)
        T_est = -avg_delta / np.log(target_accept)

        # Clamp: never let auto-temperature exceed a sane ceiling.
        # Extremely high T0 makes the SA accept all moves for hundreds
        # of generations before any selection pressure kicks in.
        MAX_T0 = 50000.0
        T0 = min(T_est, MAX_T0)
        if T_est > MAX_T0:
            print(f"[SA init] Auto T0 clamped from {T_est:.1f} to {T0:.1f}")
        return max(T0, 1.0)
        
    def energy_difference(self, current_score, neighbor_score):

        # SINGLE OBJECTIVE (minimization)
        if not self.is_multiobjective(current_score):

            delta = neighbor_score - current_score
            return max(0.0, delta)

        # MULTI OBJECTIVE (minimization)
        else:

            if self.dominates(current_score, neighbor_score):
                # neighbor worse
                return np.linalg.norm(neighbor_score - current_score)

            elif self.dominates(neighbor_score, current_score):
                # neighbor better
                return 0.0

            else:
                # non-dominated → treat as small penalty
                return np.linalg.norm(neighbor_score - current_score)
    
    
    
    # =========================================================
    # Safe Initialization
    # =========================================================
    def initialize_valid_solution(self, max_attempts=200, min_active=2):
        """
        Find an initial solution with at least min_active variables.

        Iterates from min_active up to dim_core (inclusive).
        min_active defaults to 2 — a minimum viable model needs at least
        2 active predictors.  The old default of 5 caused an empty
        range(5, 5) = [] when dim_core == 5, raising immediately.
        """
        D = self.dim_core
        has_lc = getattr(self.evaluator, "max_latent_classes", 1) > 1
        print(f"[SA init] searching for valid solution "
              f"(min_active={min_active}, dim_core={D}, dim={self.dim}, has_lc={has_lc})")

        # range is inclusive of dim_core so we always try the full model
        for complexity in range(min_active, self.dim_core + 1):

            for _ in range(max_attempts):

                solution = np.zeros(self.dim, dtype=int)

                # Activate exactly `complexity` role genes
                idx = np.random.choice(
                    self.dim_core,
                    size=min(complexity, self.dim_core),
                    replace=False
                )

                for j in idx:
                    solution[j] = self.sample_allowed_role(j, force_active=True)

                # Randomise distribution genes (D … 2D-1)
                for j in range(D, 2 * D):
                    solution[j] = np.random.randint(0, 5)  # 5 distributions: normal, lognormal, triangular, uniform, neglognormal

                # Dispersion bit (2D): randomise 0 or 1
                if self.dim > 2 * D:
                    solution[2 * D] = np.random.randint(0, 2)

                # LC code (2D+1): randomise within max_latent_classes
                if has_lc and self.dim > 2 * D + 1:
                    max_lc = getattr(self.evaluator, "max_latent_classes", 2)
                    solution[2 * D + 1] = np.random.randint(0, max_lc)

                # Class masks (2D+2 … 3D+1): randomise 0..max_latent_classes per variable
                if has_lc and self.dim > 2 * D + 2:
                    _max_lc = getattr(self.evaluator, "max_latent_classes", 2)
                    for j in range(2 * D + 2, min(3 * D + 2, self.dim)):
                        solution[j] = np.random.randint(0, _max_lc + 1)

                solution = self.repair(solution)
                score    = self.evaluator.fitness(solution)

                if self.is_valid_fitness(score):
                    score_str = " ".join(f"{v:.1f}" for v in np.asarray(score).ravel())
                    lc_val = int(solution[2 * D + 1]) + 1 if has_lc and self.dim > 2 * D + 1 else 1
                    print(f"[SA init] valid model found  "
                          f"active={complexity}  classes={lc_val}  score={score_str}")
                    return solution, score

        raise ValueError(
            f"Could not find a valid initial solution after trying "
            f"complexities {min_active}..{self.dim_core} x {max_attempts} attempts. "
            f"Check that the fitness function returns finite values for at least "
            f"one variable combination."
        )
    
    
    
    def is_valid_fitness(self, score, max_allowed=1e12):

        if not np.all(np.isfinite(score)):
            return False

        if np.any(score == -1000000000000.0):
            return False
        
        if np.any(score >= max_allowed):
            return False

        return True
    
    
  

    def sa_accept(self, delta, T):
        """
        Stable simulated annealing acceptance rule.
        Prevents overflow in exp(-delta/T).
        """

        # Always accept downhill moves
        if delta <= 0:
            return True

        # If temperature is zero or extremely small → reject uphill moves
        if T <= 1e-12:
            return False

        # Compute exponent safely
        exponent = -delta / T

        # Clip to avoid overflow (float64 safe range)
        exponent = np.clip(exponent, -700, 700)

        # Acceptance probability
        p = np.exp(exponent)

        # Draw random uniform
        return np.random.rand() < p
    
    
    def save_search_stats_txt(
        self,
        algo="sa",
        seed=0,
        config_id=0,
        folder="results"
    ):

        os.makedirs(folder, exist_ok=True)

        timestamp = time.strftime("%Y%m%d_%H%M%S")

        filename = f"{algo}_search_stats_seed{seed}_config{config_id}_{timestamp}.txt"
        filepath = os.path.join(folder, filename)

        with open(filepath, "w") as f:

            f.write("=====================================================\n")
            f.write("SIMULATED ANNEALING SEARCH STATISTICS\n")
            f.write("=====================================================\n")
            f.write(f"Algorithm : {algo}\n")
            f.write(f"Seed      : {seed}\n")
            f.write(f"Config ID : {config_id}\n")
            f.write(f"Runtime   : {self.runtime:.2f} seconds\n")
            f.write(f"Iterations: {self.total_iterations}\n")
            f.write("=====================================================\n\n")

            if len(self.search_stats) == 0:
                f.write("No search statistics recorded.\n")
                return

            first = self.search_stats[0]

            # MULTI OBJECTIVE
            if "hypervolume" in first:

                f.write("Iter | Temp | Hypervolume | ParetoSize | BestObj1 | BestObj2\n")
                f.write("-------------------------------------------------------------\n")

                for row in self.search_stats:
                    f.write(
                        f"{row['iter']:4d} | "
                        f"{row['temperature']:8.4f} | "
                        f"{row['hypervolume']:12.6f} | "
                        f"{row['pareto_size']:10d} | "
                        f"{row['best_obj1']:10.4f} | "
                        f"{row['best_obj2']:10.4f}\n"
                    )

            # SINGLE OBJECTIVE
            else:

                f.write("Iter | Temp | Best | ArchiveSize\n")
                f.write("------------------------------------------\n")

                for row in self.search_stats:
                    f.write(
                        f"{row['iter']:4d} | "
                        f"{row['temperature']:8.4f} | "
                        f"{row['best']:12.6f} | "
                        f"{row['archive_size']:10d}\n"
                    )

        print(f"[OK] SA search stats saved to {filepath}")

    def save_search_stats_csv(
        self,
        algo="sa",
        seed=0,
        config_id=0,
        folder="results"
    ):
        """Same per-iteration data as save_search_stats_txt(), as a CSV --
        one row per generation, columns depend on single- vs multi-objective
        (see search_stats' 'best'/'archive_size' vs 'hypervolume'/
        'pareto_size'/'best_obj1'/'best_obj2' keys, set in optimize())."""
        import pandas as pd

        os.makedirs(folder, exist_ok=True)
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"{algo}_search_stats_seed{seed}_config{config_id}_{timestamp}.csv"
        filepath = os.path.join(folder, filename)

        pd.DataFrame(self.search_stats).to_csv(filepath, index=False)
        print(f"[OK] SA search stats CSV saved to {filepath}")
        return filepath

    # =========================================================
    # Optimize
    # =========================================================
    def optimize(self):
        start_time = time.time()   # [OK]
        last_best = None
        if self.init_solution is not None:
            # Warm start (e.g. best structure from a previous cached run):
            # evaluate it; fall back to random init if it is infeasible.
            current = self.init_solution.copy()
            current_score = self.evaluator.fitness(current)
            if not np.isfinite(current_score).all() or float(
                np.max(np.asarray(current_score, dtype=float))
            ) >= 1e12:
                print("[SA init] warm-start solution invalid - using random init")
                current, current_score = self.initialize_valid_solution()
            else:
                print(f"[SA init] warm-started from cached solution "
                      f"(score={float(np.min(current_score)):.4f})")
        else:
            current, current_score = self.initialize_valid_solution()

        if self.T0 is None:
            self.T0 = self.auto_temperature(current)
            print(f"Auto T0: {self.T0:.4f}")
        
        self.archive = []
        self.archive_scores = []
        archive_sizes = []
        self.update_archive(current, current_score)

        # Track the best-so-far so we can announce genuine improvements
        # (the per-generation "nbr fitness" line is just the proposed neighbour,
        # not the incumbent best -- previously the best was never printed).
        best_ever = None
        if not self.is_multiobjective(current_score):
            best_ever = float(self.archive_scores[0])
            print(f"[NEW BEST] gen 0 | score={best_ever:.4f}")

        no_improve = 0

        for gen in range(self.max_iter):
            
            elapsed = time.time() - start_time
            avg_time_per_iter = elapsed / (gen + 1)
            remaining = avg_time_per_iter * (self.max_iter - gen - 1)

            if gen % 10 == 0:
                print(
                    f"[Gen {gen}/{self.max_iter}] "
                    f"Elapsed: {elapsed:.1f}s | "
                    f"ETA: {remaining:.1f}s"
                )
            if self.cache_clear_every and gen % self.cache_clear_every == 0:
                force_gc()
                jax.clear_caches()
            T = self.temperature(gen)

            if self.max_time is not None and elapsed >= self.max_time:
                print(f"[STOP] Stopping early: reached max_time={self.max_time:.1f}s")
                break

            neighbor = self.generate_neighbor(current, T)
            neighbor = self.repair(neighbor)
            neighbor_score = self.evaluator.fitness(neighbor)
            print(f'gen{gen}, nbr fitness:{neighbor_score}')

            accept = False

            if not self.is_multiobjective(current_score):
                ## TERMINATON STAGNATON #################
                best = self.archive_scores[0]
        
                if last_best is None:
                    last_best = best

                if abs(last_best - best) < self.tol:
                    no_improve += 1
                else:
                    no_improve = 0

                last_best = best

                if no_improve > self.patience:
                    print("[STOP] Early stop: no improvement")
                    break
                #####################################
                delta = self.energy_difference(current_score, neighbor_score)

                if delta == 0:
                    accept = True
                else:
                    if T < 1e-12:
                        accept = False
                    else:
                        accept = np.random.rand() < np.exp(-delta / T)

            else:

                if self.dominates(neighbor_score, current_score):
                    accept = True
                elif self.dominates(current_score, neighbor_score):
                    delta = np.sum(np.maximum(
                        0, neighbor_score - current_score))
                    accept = self.sa_accept(delta, T)
                else:
                    dist = np.linalg.norm(
                        neighbor_score - current_score)
                    accept = self.sa_accept(dist, T)

            if accept:
                current = neighbor
                current_score = neighbor_score
                self.update_archive(current, current_score)
                archive_sizes.append(len(self.archive))
                no_improve = 0

                # Announce a genuine improvement in the incumbent best model.
                if not self.is_multiobjective(current_score):
                    cur_best = float(self.archive_scores[0])
                    if best_ever is None or cur_best < best_ever - self.tol:
                        best_ever = cur_best
                        n_active = int(np.count_nonzero(
                            np.asarray(self.archive[0])[:self.dim_core]))
                        print(f"[NEW BEST] gen {gen} | score={cur_best:.4f} "
                              f"| active_vars={n_active} | elapsed={elapsed:.0f}s",
                              flush=True)
            else:
                no_improve += 1

            # [OK] Adaptive cooling
            if self.adaptive and no_improve > 50:
                self.alpha *= 0.99

            # [OK] Restart
            if no_improve > self.restart_threshold:
                D = self.dim_core

                roles = np.zeros(D, dtype=int)
                for j in range(D):
                    roles[j] = self.sample_allowed_role(j)
                dists = np.random.randint(0, 5, size=D)  # 5 distributions: normal, lognormal, triangular, uniform, neglognormal
                disp = np.random.randint(0, 2, size=1)
                # lc_code gene (0 when single-class, [0,max_lc) otherwise)
                max_lc = getattr(self.evaluator, 'max_latent_classes', 1)
                lc_code = np.random.randint(0, max(max_lc, 1), size=1) if max_lc > 1 else np.zeros(1, dtype=int)
                # class_mask genes (per-class variable assignments, 0..max_lc)
                class_mask = np.random.randint(0, max_lc + 1, size=D) if max_lc > 1 else np.zeros(D, dtype=int)

                current = np.concatenate([roles, dists, disp, lc_code, class_mask])
                current_score = self.evaluator.fitness(current)
                no_improve = 0

            # [OK] Hypervolume tracking
            if self.is_multiobjective(current_score):
                hv = self.compute_hypervolume()
                self.hypervolume_history.append(hv)
                self.convergence.append(hv)
                front_scores = np.array(self.archive_scores)

                best_obj1 = float(np.min(front_scores[:, 0]))
                best_obj2 = float(np.min(front_scores[:, 1]))

                self.search_stats.append({
                    "iter": gen,
                    "temperature": float(T),
                    "hypervolume": float(hv),
                    "pareto_size": len(self.archive),
                    "best_obj1": best_obj1,
                    "best_obj2": best_obj2
                })
                # Multiobjective stagnation check
                # Only activate after 40% of max_iter has elapsed.
                # Use relative hypervolume change (not absolute) to avoid
                # premature stopping on problems where HV scale is large.
                if (
                    gen > self.max_iter * 0.4 and
                    len(self.archive) >= 2 and
                    len(self.hypervolume_history) > 60
                ):

                    recent_hv = self.hypervolume_history[-50:]
                    recent_size = archive_sizes[-50:]

                    hv_range = max(recent_hv) - min(recent_hv)
                    hv_rel_change = hv_range / (abs(recent_hv[0]) + 1e-12)

                    if (
                        hv_rel_change < 1e-4 and
                        max(recent_size) == min(recent_size)
                    ):
                        print("[STOP] Early stop: multiobjective stagnation")
                        break
                '''
                if max(recent) - min(recent) < self.tol:
                    print("[STOP] Early stop: hypervolume stagnated")
                    break
                if len(archive_sizes) > 50:

                    recent_sizes = archive_sizes[-30:]

                    if max(recent_sizes) == min(recent_sizes):
                        print("[STOP] Early stop: archive not growing")
                        break
                '''
            else:
                # single objective
                best = self.archive_scores[0]
                self.convergence.append(best)
                #self.convergence.append(best)
                self.search_stats.append({
                    "iter": gen,
                    "temperature": float(T),
                    "best": float(best),
                    "archive_size": len(self.archive)
                })

            # Best-so-far hook (checkpointing / external monitors). Reports
            # the global incumbent (archive best), not the proposed neighbour.
            if self.on_iteration is not None and len(self.archive):
                try:
                    if self.is_multiobjective(self.archive_scores[0]):
                        _front = np.asarray(self.archive_scores, dtype=float)
                        _bi = int(np.argmin(_front[:, 0]))
                        _dec = self.archive[_bi]
                        _best = float(_front[_bi, 0])
                    else:
                        _dec = self.archive[0]
                        _best = float(self.archive_scores[0])
                    self.on_iteration(gen, np.asarray(_dec, dtype=float),
                                      _best, elapsed, T)
                except Exception as _exc:  # noqa: BLE001 - never kill a search
                    print(f"  [checkpoint] on_iteration failed ({_exc});"
                          " continuing")

        self.runtime = time.time() - start_time
        self.total_iterations = gen + 1
        return np.array(self.archive), np.array(self.archive_scores)
    
    



class MultiStartSA:

    def __init__(self,
                 evaluator,
                 dimension,
                 n_starts=5,          # more restarts for better coverage
                 n_jobs=1,
                 init_solutions=None,
                 on_iteration=None,
                 **sa_kwargs):

        self.evaluator = evaluator
        self.dimension = dimension
        self.n_starts = n_starts
        self.n_jobs = n_jobs
        # Optional per-start warm-start decision vectors (list of arrays).
        # Start i uses init_solutions[i % len(init_solutions)] when provided.
        self.init_solutions = (
            list(init_solutions) if init_solutions is not None else None
        )
        # Global best across starts, forwarded to on_iteration only on
        # improvement so callbacks (e.g. checkpoint writers) see a monotone
        # incumbent even when a later start begins from a worse point.
        self.on_iteration = on_iteration if callable(on_iteration) else None
        self._best_score = np.inf
        self._best_decision = None
        self.sa_kwargs = sa_kwargs

    def run_single(self, seed, start_index=0):

        np.random.seed(seed)

        sa = AdvancedSimulatedAnnealing(
            evaluator=self.evaluator,
            dimension=self.dimension,
            **self.sa_kwargs
        )
        if self.init_solutions:
            # Decision genes are integer codes (roles/dists/dispersion/masks);
            # a warm start restored from JSON/cache arrives as float and would
            # otherwise leak into list indexing downstream.
            sa.init_solution = np.rint(np.asarray(
                self.init_solutions[start_index % len(self.init_solutions)],
                dtype=float,
            )).astype(int)

        if self.on_iteration is not None:
            def _forward(gen, decision, score, elapsed, temperature):
                if score < self._best_score:
                    self._best_score = float(score)
                    self._best_decision = np.asarray(decision, dtype=float).copy()
                    self.on_iteration(gen, self._best_decision,
                                      self._best_score, elapsed, temperature)

            sa.on_iteration = _forward

        archive, scores = sa.optimize()
        sa.save_search_stats_txt(
                algo='sa',
                seed=seed,
                config_id=0
        )
        stats_csv = sa.save_search_stats_csv(
                algo='sa',
                seed=seed,
                config_id=0
        )

        sa.finalize_plots(
            algo="sa",
            seed=seed
        )

        return {
        "archive": archive,
        "scores": scores,
        "convergence": sa.convergence,
        "search_stats": sa.search_stats,
        "stats_csv": stats_csv,
        "runtime": sa.runtime,
        }

    def optimize(self):

        results = Parallel(n_jobs=self.n_jobs)(
            delayed(self.run_single)(i, start_index=i)
            for i in range(self.n_starts)
        )

        self.results = results

        # Merge archives
        all_solutions = []
        all_scores = []

        for r in results:
            for s, sc in zip(r["archive"], r["scores"]):
                all_solutions.append(s)
                all_scores.append(sc)

        return np.array(all_solutions), np.array(all_scores)
    
    def plot_convergence(self):
        _ensure_plt()
        all_curves = [r["convergence"] for r in self.results]

        min_len = min(len(c) for c in all_curves)
        trimmed = np.array([c[:min_len] for c in all_curves])

        mean_curve = np.mean(trimmed, axis=0)
        std_curve = np.std(trimmed, axis=0)

        plt.plot(mean_curve, label="Mean")
        plt.fill_between(range(min_len),
                        mean_curve - std_curve,
                        mean_curve + std_curve,
                        alpha=0.3)

        plt.xlabel("Iteration")
        plt.ylabel("Hypervolume / Best Fitness")
        plt.title("Convergence Across Starts")
        plt.legend()
        plt.show()
        
    def final_pareto(self, all_scores):

        def dominates(a, b):
            return np.all(a <= b) and np.any(a < b)

        scores = np.array(all_scores)

        if scores.ndim == 1:
            # single objective
            idx = np.argmin(scores)
            return idx, scores[idx]

        keep = []

        for i in range(len(scores)):
            dominated = False
            for j in range(len(scores)):
                if j != i and dominates(scores[j], scores[i]):
                    dominated = True
                    break
            if not dominated:
                keep.append(i)

        return keep, scores[keep]


class NSGA2Engine:

    def __init__(self,
                 evaluator,
                 operator,
                 dimension,
                 pop_size=30,
                 max_iter=50,
                 n_jobs=1,
                 save_history=False):

        self.evaluator = evaluator
        self.operator = operator
        self.dim = dimension
        self.dim_core = len(evaluator.vars)  # D = number of variables
        self.pop_size = pop_size
        self.max_iter = max_iter
        self.generations = max(1, int(np.ceil(max_iter / pop_size)))
        self.n_jobs = n_jobs
        self.mutation_prob = 0.2
        self.save_history = save_history

        # ---- tracking ----
        self.fitness_history = []
        self.hypervolume_history = []
        self.population_history = []
        self.pareto_history = []
        # Bound per-generation history memory.  A long many-objective run kept
        # a full population copy (and a full Pareto front) per generation with
        # no cap, which grows without bound and OOMs the node.  Only the most
        # recent entries are ever read (plots use [-1] / iterate; the pickle
        # is for resume), so truncate to the most recent N.  population_history
        # is the heavy one (whole population per gen) and is not returned in the
        # result dict, so it gets a much smaller cap.  Override with
        # MC_MAX_GEN_HISTORY (<=0 disables the cap).
        try:
            _hist_cap = int(os.environ.get("MC_MAX_GEN_HISTORY", "2000"))
        except (TypeError, ValueError):
            _hist_cap = 2000
        self._hist_cap = _hist_cap if _hist_cap > 0 else None
        self._pop_hist_cap = min(200, _hist_cap) if _hist_cap > 0 else None
        # ---- generation statistics ----
        self.search_stats = []

    @staticmethod
    def _trim_history(lst, cap):
        """Drop the oldest entries of a per-generation history list."""
        if cap is not None and len(lst) > cap:
            del lst[: len(lst) - cap]

    
    def finalize_plots(self, algo="nsga2", seed=0, folder="results"):
        _ensure_plt()
        timestamp = time.strftime("%Y%m%d_%H%M%S")

        # ==========================
        # SINGLE OBJECTIVE
        # ==========================
        if len(self.fitness_history) > 0:

            fig = plt.figure()
            plt.plot(self.fitness_history)
            plt.xlabel("Generation")
            plt.ylabel("Best Fitness")
            plt.title("NSGA-II Convergence (Single Objective)")
            plt.grid(True)

            save_plot(fig, f"{algo}_convergence_seed{seed}_{timestamp}.png", folder)

        # ==========================
        # MULTI OBJECTIVE
        # ==========================
        if len(self.hypervolume_history) > 0:

            # Hypervolume trace
            fig = plt.figure()
            plt.plot(self.hypervolume_history)
            plt.xlabel("Generation")
            plt.ylabel("Hypervolume")
            plt.title("NSGA-II Hypervolume Convergence")
            plt.grid(True)

            save_plot(fig, f"{algo}_hypervolume_seed{seed}_{timestamp}.png", folder)

            # Pareto front
            if len(self.pareto_history) > 0:

                front = self.pareto_history[-1]

                fig = plt.figure()
                plt.scatter(front[:, 0], front[:, 1])
                plt.xlabel("Objective 1")
                plt.ylabel("Objective 2")
                plt.title("Final Pareto Front (NSGA-II)")
                plt.grid(True)

                save_plot(fig, f"{algo}_pareto_seed{seed}_{timestamp}.png", folder)
    
    # =========================================================
    # Evaluation
    # =========================================================
    def evaluate_population(self, pop):

        if self.n_jobs == 1:
            return np.array([
                self.evaluator.fitness(ind)
                for ind in pop
            ])

        return np.array(
            Parallel(n_jobs=self.n_jobs)(
                delayed(self.evaluator.fitness)(ind)
                for ind in pop
            )
        )

    # =========================================================
    def is_multiobjective(self, scores):
        return scores.ndim > 1 and scores.shape[1] > 1

    def dominates(self, a, b):
        return np.all(a <= b) and np.any(a < b)

    # =========================================================
    def fast_non_dominated_sort(self, scores):

        fronts = [[]]
        domination_count = np.zeros(len(scores))
        dominated_sets = [[] for _ in range(len(scores))]

        for i in range(len(scores)):
            for j in range(len(scores)):
                if i == j:
                    continue
                if self.dominates(scores[i], scores[j]):
                    dominated_sets[i].append(j)
                elif self.dominates(scores[j], scores[i]):
                    domination_count[i] += 1

            if domination_count[i] == 0:
                fronts[0].append(i)

        current = 0
        while fronts[current]:
            next_front = []
            for i in fronts[current]:
                for j in dominated_sets[i]:
                    domination_count[j] -= 1
                    if domination_count[j] == 0:
                        next_front.append(j)
            current += 1
            fronts.append(next_front)

        return fronts[:-1]

    # =========================================================
    def crowding_distance(self, scores, front):

        distance = np.zeros(len(front))
        front_scores = scores[front]
        num_obj = front_scores.shape[1]

        for m in range(num_obj):

            sorted_idx = np.argsort(front_scores[:, m])
            distance[sorted_idx[0]] = distance[sorted_idx[-1]] = np.inf

            min_val = front_scores[sorted_idx[0], m]
            max_val = front_scores[sorted_idx[-1], m]

            if max_val - min_val == 0:
                continue

            for i in range(1, len(front)-1):
                distance[sorted_idx[i]] += (
                    front_scores[sorted_idx[i+1], m] -
                    front_scores[sorted_idx[i-1], m]
                ) / (max_val - min_val)

        return distance

    # =========================================================
    def compute_hypervolume(self, front_scores, reference):

        # Sort by first objective ascending (since minimizing)
        sorted_pts = front_scores[np.argsort(front_scores[:, 0])]

        hv = 0.0
        prev_f1 = reference[0]

        for f1, f2 in reversed(sorted_pts):
            width = prev_f1 - f1
            height = reference[1] - f2

            if width > 0 and height > 0:
                hv += width * height

            prev_f1 = f1

        return hv
    
    def sample_allowed_role(self, var_index, force_active=False):
        var_name = self.evaluator.vars[var_index]
        allowed = self.evaluator.allowed_roles[var_name]

        # ── Ban check: if variable is banned and not force-included, only role 0 ──
        banned = getattr(self.evaluator, "_banned_variables", set())
        force_inc = getattr(self.evaluator, "_force_included_vars", set())
        if var_name in banned and var_name not in force_inc:
            return 0

        # If we require non-zero role
        if force_active:
            allowed = [r for r in allowed if r != 0]

        if len(allowed) == 0:
            return 0  # fallback safety

        if len(allowed) == 1:
            return allowed[0]

        allowed = np.array(allowed)
        probs = ROLE_PROBS[allowed].copy()

        # UCB bandit adaptive sign-violation suppression (see AdvancedSimulatedAnnealing)
        if (not force_active
                and 0 in allowed
                and hasattr(self.evaluator, '_sign_violation_counts')
                and hasattr(self.evaluator, '_sign_visit_counts')):
            n_visits = self.evaluator._sign_visit_counts.get(var_name, 0)
            n_viol = self.evaluator._sign_violation_counts.get(var_name, 0)
            if n_visits >= 3:
                viol_rate = n_viol / n_visits
                if viol_rate >= 0.5:
                    excl_idx = np.where(allowed == 0)[0]
                    probs[excl_idx] *= (1.0 + viol_rate)

        probs = probs / probs.sum()
        return np.random.choice(allowed, p=probs)
    def _initialise_start_pop(self):
        D = self.dim_core   # [OK] define it here
        pop = []
        while len(pop) < self.pop_size:

            roles = np.zeros(D, dtype=int)

            for j in range(D):
                roles[j] = self.sample_allowed_role(j)

            dists = np.random.randint(0, 6, size=D)
            disp = np.random.randint(0, 2, size=1)
            # lc_code gene (0 when single-class, [0,max_lc) otherwise)
            max_lc = getattr(self.evaluator, 'max_latent_classes', 1)
            lc_code = np.random.randint(0, max(max_lc, 1), size=1) if max_lc > 1 else np.zeros(1, dtype=int)
            # class_mask genes (per-class variable assignments, 0..max_lc)
            class_mask = np.random.randint(0, max_lc + 1, size=D) if max_lc > 1 else np.zeros(D, dtype=int)

            candidate = np.hstack((roles, dists, disp, lc_code, class_mask))
            candidate = self.repair(candidate)

            pop.append(candidate)
        pop = np.array(pop)
        return pop

    # =========================================================
    def optimize(self):
        start_time = time.time()  # [OK] start timer

        D = self.dim_core
        pop  = self._initialise_start_pop()
        allowed_roles = [
            self.evaluator.allowed_roles.get(var, [0])
            for var in self.evaluator.vars
        ]

      
        scores = self.evaluate_population(pop)
        scores = self.sanitize_scores(scores)

        single = not self.is_multiobjective(scores)
        
        # -------------------------------------------------
        # [OK] Auto-estimate SA initial temperature
        # -------------------------------------------------
        

        for gen in range(self.generations):
            elapsed = time.time() - start_time
            avg_time_per_gen = elapsed / (gen + 1)
            remaining = avg_time_per_gen * (self.generations - gen - 1)

            print(
                f"[Gen {gen}/{self.max_iter}] "
                f"Elapsed: {format_time(elapsed)} | "
                f"ETA: {format_time(remaining)}"
            )
            #print_jax_compilation_cache()
            offspring = []

            for i in range(self.pop_size):
                child = self.operator.generate(
                    pop, i, gen, self.max_iter,
                    allowed_roles=allowed_roles)
                child = self.repair(child)   # 
                offspring.append(child)

            offspring = np.array(offspring)

            offspring_scores = self.evaluate_population(offspring)
            offspring_scores = self.sanitize_scores(offspring_scores)

            if single:

                combined = np.vstack((pop, offspring))
                combined_scores = np.hstack((scores, offspring_scores))

                idx = np.argsort(combined_scores)[:self.pop_size]
                pop = combined[idx]
                scores = combined_scores[idx]

                best = np.min(scores)
                self.fitness_history.append(best)
                self._trim_history(self.fitness_history, self._hist_cap)

            else:

                pop, scores = self.environmental_selection(
                    pop, scores, offspring, offspring_scores
                )

                front = self.fast_non_dominated_sort(scores)[0]
                front_scores = scores[front]
                # [OK] Remove NaNs
                front_scores = front_scores[~np.isnan(front_scores).any(axis=1)]

                if len(front_scores) == 0:
                    hv = 0.0
                else:
                    ref = np.nanmax(scores, axis=0) + 1
                    hv = self.compute_hypervolume(front_scores, ref)
                
                
               # ref = np.max(scores, axis=0) + 1
                #hv = self.compute_hypervolume(front_scores, ref)

                self.hypervolume_history.append(hv)
                self._trim_history(self.hypervolume_history, self._hist_cap)
                self.pareto_history.append(front_scores.copy())
                self._trim_history(self.pareto_history, self._hist_cap)

            if self.save_history:
                self.population_history.append(pop.copy())
                self._trim_history(self.population_history, self._pop_hist_cap)

            
            
            if single:

                best = np.min(scores)
                mean = np.mean(scores)
                std = np.std(scores)
                self.search_stats.append({
                        "gen": gen,
                        "best": float(best),
                        "mean": float(mean),
                        "std": float(std)
                })

                print(
                    f"Gen {gen:03d} | "
                    f"Best: {best:.4f} | "
                    f"Mean: {mean:.4f} | "
                    f"Std: {std:.4f}"
                )
                print_memory_usage(f"end gen before gc {gen}")
                force_gc()
                jax.clear_caches()
                print_memory_usage(f"end gen {gen}")
                print('cool')
            else:

                pareto_size = len(front_scores)

                best_bic = np.min(front_scores[:, 0])
                best_rmse = np.min(front_scores[:, 1])
                self.search_stats.append({
                    "gen": gen,
                    "hypervolume": float(hv),
                    "pareto_size": int(pareto_size),
                    "best_obj1": float(best_bic),
                    "best_obj2": float(best_rmse)
                })
                print(
                    f"Gen {gen:03d} | "
                    f"HV: {hv:.4f} | "
                    f"Pareto: {pareto_size} | "
                    f"Best BIC: {best_bic:.2f} | "
                    f"Best RMSE: {best_rmse:.4f}"
                )
                print_memory_usage(f"end gen before gc {gen}")
                force_gc()
                # Mirror the single-objective branch: every new structure
                # JIT-compiles fresh XLA executables (static_argnames=("spec",)),
                # so without clearing here RSS grows for the whole multi-objective
                # search (observed OOM on long many-objective runs).
                jax.clear_caches()
                print_memory_usage(f"end gen {gen}")
                print('cool')

        if single:
            best = np.argmin(scores)
            return pop[best], scores[best]
        else:
            front = self.fast_non_dominated_sort(scores)[0]
            return pop[front], scores[front]
        
    def save_search_stats_txt(
        self,
        algo="nsga2",
        seed=0,
        config_id=0,
        folder="results"
    ):

        os.makedirs(folder, exist_ok=True)

        timestamp = time.strftime("%Y%m%d_%H%M%S")

        filename = f"{algo}_search_stats_seed{seed}_config{config_id}_{timestamp}.txt"
        filepath = os.path.join(folder, filename)

        with open(filepath, "w") as f:

            f.write("=====================================================\n")
            f.write("NSGA-II SEARCH STATISTICS\n")
            f.write("=====================================================\n")
            f.write(f"Algorithm : {algo}\n")
            f.write(f"Seed      : {seed}\n")
            f.write(f"Config ID : {config_id}\n")
            f.write(f"Timestamp : {timestamp}\n")
            f.write("=====================================================\n\n")

            if len(self.search_stats) == 0:
                f.write("No search statistics recorded.\n")
                return

            # Detect mode
            first = self.search_stats[0]

            if "hypervolume" in first:
                f.write("Gen | Hypervolume | ParetoSize | BestObj1 | BestObj2\n")
                f.write("-----------------------------------------------------\n")

                for row in self.search_stats:
                    f.write(
                        f"{row['gen']:3d} | "
                        f"{row['hypervolume']:12.6f} | "
                        f"{row['pareto_size']:10d} | "
                        f"{row['best_obj1']:10.4f} | "
                        f"{row['best_obj2']:10.4f}\n"
                    )
            else:
                f.write("Gen | Best | Mean | Std\n")
                f.write("---------------------------------\n")

                for row in self.search_stats:
                    f.write(
                        f"{row['gen']:3d} | "
                        f"{row['best']:10.6f} | "
                        f"{row['mean']:10.6f} | "
                        f"{row['std']:10.6f}\n"
                    )

        print(f"[OK] Search stats saved to {filepath}")

    def save_search_stats_csv(
        self,
        algo="nsga2",
        seed=0,
        config_id=0,
        folder="results"
    ):
        """CSV counterpart to save_search_stats_txt() -- one row per
        generation (columns: gen/best/mean/std, or gen/hypervolume/
        pareto_size/best_obj1/best_obj2 for multi-objective runs)."""
        import pandas as pd

        os.makedirs(folder, exist_ok=True)
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"{algo}_search_stats_seed{seed}_config{config_id}_{timestamp}.csv"
        filepath = os.path.join(folder, filename)

        pd.DataFrame(self.search_stats).to_csv(filepath, index=False)
        print(f"[OK] Search stats CSV saved to {filepath}")
        return filepath

    def constraint_violation(self, solution):

        D = self.dim_core
        roles = solution[:D]

        violation = 0.0

        # Rule:
        # If role 5 exists but no 2 or 3
        if 5 in roles and not (2 in roles or 3 in roles):
            violation += 1.0   # magnitude of violation

        # Mutual exclusion violation penalty
        mutex = getattr(self.evaluator, "mutual_exclusion", None)
        if mutex:
            violation += _count_mutex_violations(roles, self.evaluator.vars, mutex)

        return violation
    
    
    def repair(self, solution):

        D = self.dim_core
        roles = solution[:D]

        if 5 in roles and not (2 in roles or 3 in roles):

            zero_idx = np.where(roles == 0)[0]

            if len(zero_idx) > 0:
                roles[np.random.choice(zero_idx)] = np.random.choice([2,3])
            else:
                # force convert one variable
                idx = np.random.randint(D)
                roles[idx] = np.random.choice([2,3])

        # Mutual-exclusion repair
        mutex = getattr(self.evaluator, "mutual_exclusion", None)
        if mutex:
            roles = _repair_mutex(roles, self.evaluator.vars, mutex, rng=np.random)

        solution[:D] = roles
        return solution

    def environmental_selection(self,
                            pop, scores,
                            offspring, offspring_scores):

        # Combine parent + offspring
        combined_pop = np.vstack((pop, offspring))
        combined_scores = np.vstack((scores, offspring_scores))

        # Fast non-dominated sort
        fronts = self.fast_non_dominated_sort(combined_scores)

        new_pop = []
        new_scores = []

        for front in fronts:

            if len(new_pop) + len(front) <= self.pop_size:
                # Take full front
                for idx in front:
                    new_pop.append(combined_pop[idx])
                    new_scores.append(combined_scores[idx])
            else:
                # Need partial front → crowding distance
                front_scores = combined_scores[front]
                distances = self.crowding_distance(combined_scores, front)

                sorted_idx = np.argsort(-distances)

                remaining = self.pop_size - len(new_pop)

                for i in sorted_idx[:remaining]:
                    idx = front[i]
                    new_pop.append(combined_pop[idx])
                    new_scores.append(combined_scores[idx])

                break

        return np.array(new_pop), np.array(new_scores)
    
    
    # =========================================================
    # ---------------- PLOTTING ----------------
    # =========================================================

    def plot_convergence(self):
        _ensure_plt()
        if len(self.fitness_history) > 0:
            plt.plot(self.fitness_history)
            plt.xlabel("Generation")
            plt.ylabel("Best Fitness")
            plt.title("Convergence (Single Objective)")
            plt.show()

        elif len(self.hypervolume_history) > 0:
            plt.plot(self.hypervolume_history)
            plt.xlabel("Generation")
            plt.ylabel("Hypervolume")
            plt.title("Hypervolume Convergence")
            plt.show()

    def plot_pareto_front(self):
        _ensure_plt()
        if len(self.pareto_history) == 0:
            print("Not multi-objective.")
            return

        last_front = self.pareto_history[-1]

        plt.scatter(last_front[:, 0], last_front[:, 1])
        plt.xlabel("Objective 1")
        plt.ylabel("Objective 2")
        plt.title("Final Pareto Front")
        plt.show()

    def plot_pareto_evolution(self):
        _ensure_plt()
        if len(self.pareto_history) == 0:
            print("Not multi-objective.")
            return

        for front in self.pareto_history:
            plt.scatter(front[:, 0], front[:, 1], alpha=0.2)

        plt.xlabel("Objective 1")
        plt.ylabel("Objective 2")
        plt.title("Pareto Front Evolution")
        plt.show()

    # =========================================================
    # ---------------- SAVE / LOAD ----------------
    # =========================================================
    
    def sanitize_scores(self, scores, max_allowed=1e12):

        scores = np.array(scores)

        # NOTE: negative objectives are legitimate (BIC-type criteria are
        # negative by design), so the negativity rejection is applied ONLY
        # to the single-objective vector where it originally made sense.
        if scores.ndim == 1:
            invalid = (
                ~np.isfinite(scores) |
                (scores >= max_allowed) |
                (scores < 0)
            )
            scores[invalid] = max_allowed
        else:
            invalid = (
                ~np.isfinite(scores) |
                (scores >= max_allowed)
            )
            scores[invalid.any(axis=1)] = max_allowed

        return scores
    
    
    

    def save_history(self, filename="nsga_history.pkl"):

        data = {
            "fitness_history": self.fitness_history,
            "hypervolume_history": self.hypervolume_history,
            "population_history": self.population_history,
            "pareto_history": self.pareto_history
        }

        with open(filename, "wb") as f:
            pickle.dump(data, f)

    def load_history(self, filename="nsga_history.pkl"):

        with open(filename, "rb") as f:
            data = pickle.load(f)

        self.fitness_history = data["fitness_history"]
        self.hypervolume_history = data["hypervolume_history"]
        self.population_history = data["population_history"]
        self.pareto_history = data["pareto_history"]



class DynamicHarmony:

    def __init__(self,
                 hmcr=0.9,
                 par_min=0.1,
                 par_max=0.9,
                 bw_min=1,
                 bw_max=3):

        self.hmcr = hmcr
        self.par_min = par_min
        self.par_max = par_max
        self.bw_min = bw_min
        self.bw_max = bw_max
        self.F = par_max-par_min

    def generate(self, pop, i, gen, max_iter, allowed_roles=None):

        PAR = self.par_min + (
            (self.par_max - self.par_min)
            * gen / max_iter
        )

        BW = int(
            self.bw_max -
            (self.bw_max - self.bw_min)
            * gen / max_iter
        )

        child = pop[i].copy()

        n_vars = len(allowed_roles) if allowed_roles is not None else len(child) // 2
        for j in range(len(child)):

            if np.random.rand() < self.hmcr:
                idx = np.random.randint(len(pop))
                child[j] = pop[idx][j]

            if np.random.rand() < PAR:
                step = np.random.randint(-BW, BW+1)
                # Role genes (0-9): j < n_vars
                if j < n_vars:
                    # This is a role gene - sample from allowed roles for this variable
                    roles = allowed_roles[j] if isinstance(allowed_roles, list) and j < len(allowed_roles) else list(range(10))
                    child[j] = np.random.choice(roles)
                elif j < 2 * n_vars:
                    # Distribution gene (0-4)
                    child[j] = np.random.randint(0, 5)
                else:
                    # Tail genes (dispersion, LC, masks) - step with bounds
                    child[j] = int(np.clip(child[j] + step, 0, 9))

        return child


class AdaptiveDE:

    def __init__(self, F=0.5, CR=0.7,
                 tau1=0.1, tau2=0.1):

        self.F = F
        self.CR = CR
        self.tau1 = tau1
        self.tau2 = tau2

    def generate(self, pop, i, gen, max_iter, allowed_roles=None):

        if np.random.rand() < self.tau1:
            self.F = 0.1 + 0.9*np.random.rand()

        if np.random.rand() < self.tau2:
            self.CR = np.random.rand()

        idxs = list(range(len(pop)))
        idxs.remove(i)
        a_idx, b_idx, c_idx = np.random.choice(idxs, 3, replace=False)
        a, b, c = pop[a_idx], pop[b_idx], pop[c_idx]

        mutant = a.copy()
        n_vars = len(allowed_roles) if allowed_roles is not None else len(mutant) // 2
        for j in range(len(mutant)):
            if b[j] != c[j]:
                if np.random.rand() < self.F:
                    mutant[j] = b[j]
                else:
                    mutant[j] = c[j]
            else:
                if np.random.rand() < self.F:
                    mutant[j] = a[j]
                else:
                    # Random role from allowed_roles or 0-9
                    if j < n_vars:
                        roles = allowed_roles[j] if isinstance(allowed_roles, list) and j < len(allowed_roles) else list(range(10))
                        mutant[j] = np.random.choice(roles)
                    elif j < 2 * n_vars:
                        mutant[j] = np.random.randint(0, 5)
                    else:
                        mutant[j] = np.random.randint(0, 10)

        trial = pop[i].copy()

        dim = len(trial)

        # force at least one mutation
        j_rand = np.random.randint(dim)
        
        for j in range(len(trial)):
            if np.random.rand() < self.CR or j == j_rand:
                trial[j] = mutant[j]

        if np.array_equal(trial, pop[i]):
            idx = np.random.randint(dim)
            if idx < n_vars:
                roles = allowed_roles[idx] if isinstance(allowed_roles, list) and idx < len(allowed_roles) else list(range(10))
                possible = [v for v in roles if v != trial[idx]]
            elif idx < 2 * n_vars:
                possible = [v for v in range(5) if v != trial[idx]]
            else:
                possible = [v for v in range(10) if v != trial[idx]]
            trial[idx] = np.random.choice(possible) if possible else 0
        
        return trial




    

class StepwiseStructureSolver:

    def __init__(
        self,
        fitness_function,
        all_variables,
        allowed_roles,
        allowed_distributions,
        max_iter=20,
        mode="aic"
    ):
        self.fitness = fitness_function
        self.vars = all_variables
        self.allowed_roles = allowed_roles
        self.allowed_distributions = allowed_distributions
        self.max_iter = max_iter
        self.mode = mode

        self.D = len(all_variables)

    # ---------------------------------------
    # Initial solution (all OFF)
    # ---------------------------------------
    def initialize(self):
        roles = np.zeros(self.D, dtype=int)
        dists = np.zeros(self.D, dtype=int)
        return np.concatenate([roles, dists])

    # ---------------------------------------
    # Generate neighbors (add/remove/modify)
    # ---------------------------------------
    def generate_neighbors(self, solution):

        neighbors = []
        roles = solution[:self.D]
        dists = solution[self.D:]

        for i, var in enumerate(self.vars):

            # Try changing role - use all allowed roles including 7,8,9
            for new_role in self.allowed_roles.get(var, [0]):

                if new_role != roles[i]:
                    new_roles = roles.copy()
                    new_roles[i] = new_role

                    neighbors.append(
                        np.concatenate([new_roles, dists])
                    )

            # If random role, try changing distribution
            if roles[i] in [2,3,4]:
                allowed = self.allowed_distributions.get(var, ["normal"])
                for dist_idx in range(len(allowed)):

                    if dist_idx != dists[i]:
                        new_dists = dists.copy()
                        new_dists[i] = dist_idx

                        neighbors.append(
                            np.concatenate([roles, new_dists])
                        )

        return neighbors

    # ---------------------------------------
    # Optimize
    # ---------------------------------------
    def optimize(self):

        current = self.initialize()
        current_score = self.fitness(current)

        for _ in range(self.max_iter):
            print(current_score)

            neighbors = self.generate_neighbors(current)

            improved = False
            best_neighbor = current
            best_score = current_score

            for candidate in neighbors:

                score = self.fitness(candidate)

                if score > best_score:
                    best_score = score
                    best_neighbor = candidate
                    improved = True

            if improved:
                current = best_neighbor
                current_score = best_score
            else:
                break  # no improvement

        return current, current_score