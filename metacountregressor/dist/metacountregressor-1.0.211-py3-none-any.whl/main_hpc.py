import jax
import jax.numpy as jnp
import jax.scipy as jsp
import numpy as np
import pandas as pd
import os
import gc
import itertools
from functools import partial
from typing import NamedTuple as TypingNamedTuple
try:
    from jaxopt import LBFGS
except ImportError as _jaxopt_exc:  # pragma: no cover - dependency guard
    raise ImportError(
        "metacountregressor requires the 'jaxopt' package.  "
        "Install the backend with:  pip install jax jaxlib jaxopt"
    ) from _jaxopt_exc
from jaxopt import LBFGS, GradientDescent, NonlinearCG, BFGS, OptStep
import pandas as pd
import scipy.stats as stats
try:
    from ._jax_config import configure_jax
except ImportError:  # flat import (script run from inside the package dir)
    from _jax_config import configure_jax
configure_jax()
try:
    from .nb_parameterization import (
        nb2_dispersion,
        nb2_logpmf,
        nb2_logpmf_from_mean,
    )
except ImportError:
    from nb_parameterization import (
        nb2_dispersion,
        nb2_logpmf,
        nb2_logpmf_from_mean,
    )
try:
    from .Solvers_METAJAX import *  # type: ignore[attr-defined]
except ImportError:
    from Solvers_METAJAX import *
from scipy.stats import qmc
from scipy.stats import norm
import argparse
import time
import psutil
import json
from datetime import datetime
import sys
from contextlib import redirect_stdout
from scipy.optimize import minimize
import traceback

try:
    from importlib.resources import files as _resource_files
except ImportError:
    from importlib_resources import files as _resource_files

# JAX compilation cache management: clear periodically to bound memory growth
# from static_argnames=("spec",) in mixed_model_loglik.
_speccache_counter = 0
_SPECCACHE_CLEAR_EVERY = 50

def _maybe_clear_jax_caches():
    """Call jax.clear_caches() after every N distinct ModelSpec compiles."""
    global _speccache_counter
    _speccache_counter += 1
    if _speccache_counter >= _SPECCACHE_CLEAR_EVERY:
        jax.clear_caches()
        gc.collect()
        _speccache_counter = 0

DIST_MAP = {
    "normal": 0,
    "lognormal": 1,
    "triangular": 2,
    'uniform':3,
    'neglognormal': 4,
}

def lognormal_loglik(y, eta, sigma):

    sigma = jax.nn.softplus(sigma)

    log_y = jnp.log(jnp.clip(y, 1e-12, 1e12))

    ll = (
        -0.5 * jnp.log(2 * jnp.pi * sigma**2)
        - (log_y - eta)**2 / (2 * sigma**2)
        - log_y
    )

    return ll


def gaussian_loglik(y, eta, sigma):

    sigma = jax.nn.softplus(sigma)

    ll = (
        -0.5 * jnp.log(2 * jnp.pi * sigma**2)
        - (y - eta) ** 2 / (2 * sigma**2)
    )

    return ll


def tobit_loglik(y, eta, sigma_raw):
    """
    Left-censored (at 0) Tobit log-likelihood.

    Implements Eqs. (9)-(10) from Chand & Dixit (2018).

    Y_i = Y*_i  if Y*_i > 0,  else  0
    Y*_i = eta_i + eps_i,   eps_i ~ N(0, sigma^2)

    Censored  (y == 0): log P(Y* <= 0) = log Phi(-eta/sigma)
    Uncensored (y > 0): log phi((y - eta)/sigma) - log(sigma)

    Parameters
    ----------
    y         : (N, P, 1)  observed outcome
    eta       : (N, P, R)  linear predictor (mean of latent Y*)
    sigma_raw : scalar     raw scale — transformed via softplus to sigma > 0

    Returns
    -------
    ll : (N, P, R)  per-observation log-likelihoods
    """
    sigma = jax.nn.softplus(sigma_raw)

    ll_cens   = jsp.special.log_ndtr(-eta / sigma)           # log Phi(-z)

    ll_uncens = (
        -0.5 * jnp.log(2.0 * jnp.pi * sigma ** 2)
        - (y - eta) ** 2 / (2.0 * sigma ** 2)
    )

    return jnp.where(y <= 0.0, ll_cens, ll_uncens)


def check_structure_recovery(
    pareto_solutions,
    evaluator,
    true_spec_dict,
):

    true_clean = strip_distribution(true_spec_dict)

    for i, decision in enumerate(pareto_solutions):

        spec_dict = evaluator.build_spec(decision)
        if spec_dict is None:
            continue

        spec_clean = strip_distribution(spec_dict)

        if spec_clean == true_clean:
            return True, i

    return False, None


def save_structure_recovery_file(
    recovered,
    algo,
    seed,
    config_id,
    folder="results"
):

    os.makedirs(folder, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    filename = f"{algo}_recovery_seed{seed}_config{config_id}_{timestamp}.txt"
    filepath = os.path.join(folder, filename)

    with open(filepath, "w") as f:

        if recovered:
            f.write("✅ TRUE STRUCTURE RECOVERED\n")
        #else:
        #    f.write("❌ TRUE STRUCTURE NOT RECOVERED\n")

    print(f"✅ Structure recovery saved to {filepath}")
    
    
def refit_and_save_true_model(
    evaluator,
    decision,
    algo,
    seed,
    config_id,
    folder="results"
):

    os.makedirs(folder, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    filename = f"{algo}_TRUE_MODEL_seed{seed}_config{config_id}_{timestamp}.txt"
    filepath = os.path.join(folder, filename)

    with open(filepath, "w", encoding="utf-8") as f:
        with redirect_stdout(f):

            print("================================================")
            print("TRUE STRUCTURE RE-ESTIMATION")
            print("================================================")
            print("Algorithm:", algo)
            print("Seed:", seed)
            print("Config ID:", config_id)
            print("Timestamp:", timestamp)
            print("================================================\n")

            # Build spec
            spec_dict = evaluator.build_spec(decision)

            data_train, spec = evaluator.build_data(
                evaluator.df_train,
                spec_dict,
                evaluator.master_halton_train
            )

            model = CountModel(spec, data_train)
            result = model.fit()

            objective = partial(mixed_model_loglik,
                                data=data_train,
                                spec=spec)

            param_index = build_param_index(spec)

            print_summary(
                result=result,
                objective=objective,
                data=data_train,
                spec=spec,
                param_index=param_index
            )

    print(f"✅ True model summary saved to {filepath}")

def save_pareto_front(
    solutions,
    scores,
    evaluator,
    algo,
    seed,
    config_id,
    folder="results"
):

    os.makedirs(folder, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    filename = (
        f"{algo}_pareto_seed{seed}_config{config_id}_{timestamp}.csv"
    )

    filepath = os.path.join(folder, filename)

    rows = []

    for i in range(len(solutions)):

        decision = solutions[i]
        score = scores[i]

        spec_dict = evaluator.build_spec(decision)

        rows.append({
            "solution_id": i,
            "bic": float(score[0]) if score.ndim > 0 else float(score),
            "rmse": float(score[1]) if score.ndim > 0 else None,
            "structure": json.dumps(spec_dict)
        })

    df = pd.DataFrame(rows)
    df.to_csv(filepath, index=False)

    print(f"\n✅ Saved Pareto front to {filepath}")



def extract_pareto_front(solutions, scores):
    """
    Generic Pareto front extractor.
    Minimization assumed.
    """

    solutions = np.array(solutions)
    scores = np.array(scores)

    # Single objective
    if scores.ndim == 1:
        best_idx = np.argmin(scores)
        return solutions[[best_idx]], scores[[best_idx]]

    n = len(scores)
    keep = []

    for i in range(n):
        dominated = False
        for j in range(n):
            if i == j:
                continue

            if np.all(scores[j] <= scores[i]) and np.any(scores[j] < scores[i]):
                dominated = True
                break

        if not dominated:
            keep.append(i)

    return solutions[keep], scores[keep]

def save_pareto_front(
    solutions,
    scores,
    evaluator,
    algo,
    seed,
    config_id,
    folder="results"
):

    os.makedirs(folder, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    filename = (
        f"{algo}_pareto_seed{seed}_config{config_id}_{timestamp}.csv"
    )

    filepath = os.path.join(folder, filename)

    rows = []

    for i in range(len(solutions)):

        decision = solutions[i]
        score = scores[i]

        spec_dict = evaluator.build_spec(decision)

        rows.append({
            "solution_id": i,
            "bic": float(score[0]) if score.ndim > 0 else float(score),
            "rmse": float(score[1]) if score.ndim > 0 else None,
            "structure": json.dumps(spec_dict)
        })

    df = pd.DataFrame(rows)
    df.to_csv(filepath, index=False)

    print(f"\n✅ Saved Pareto front to {filepath}")


def generate_halton_normal(N, K, R, seed=42):

    sampler = qmc.Halton(d=K, scramble=False, seed=seed)
    sampler.fast_forward(50)
    u = sampler.random(N*R)          # (N*R, K)
    u = np.clip(u, 1e-12, 1 - 1e-12)
    z = norm.ppf(u)                # (N*R, K)
    z = z.reshape(N, R, K).swapaxes(1, 2)
    return z


def generate_sobol_normal(N, K, R, seed=42):
    import math
    sampler = qmc.Sobol(d=K, scramble=True, seed=seed)
    total = N * R
    k = math.ceil(math.log2(max(total, 2)))
    try:
        u = sampler.random_base2(k)[:total]
    except (AttributeError, TypeError):
        u = sampler.random(total)
    u = np.clip(u, 1e-12, 1 - 1e-12)
    z = norm.ppf(u)
    z = z.reshape(N, R, K).swapaxes(1, 2)
    return jnp.array(z)


def decode_distribution(dist_code, allowed_list):

    if len(allowed_list) == 1:
        return allowed_list[0]

    # Decision vectors may arrive as floats (e.g. warm starts / cache keys
    # round-tripped through JSON); index with an int so list lookups never
    # raise "list indices must be integers..., not numpy.float64".
    idx = int(dist_code) % len(allowed_list)
    return allowed_list[idx]







def random_decision(D, rng):

    # 0 to 4 inclusive (5 distributions: normal, lognormal, triangular, uniform, neglognormal)
    return rng.integers(0, 5, size=D)

def pareto_front(solutions):

    pareto = []

    for s in solutions:
        dominated = False

        for t in solutions:
            if (
                t.train_ll >= s.train_ll and
                t.test_rmse <= s.test_rmse and
                (t.train_ll > s.train_ll or
                 t.test_rmse < s.test_rmse)
            ):
                dominated = True
                break

        if not dominated:
            pareto.append(s)

    return pareto

class ModelStructureOptimizer:

    def __init__(self, df, mode="single", algorithm="de"):
        self.df = df
        self.mode = mode
        self.algorithm = algorithm
        self.solutions = []

    def evaluate(self, decision_vector):

        if self.mode == "single":
            score = single_objective(decision_vector, self.df)
            return score

        elif self.mode == "multi":
            train_ll, test_rmse = multi_objective(decision_vector, self.df)
            return train_ll, test_rmse

    def optimize(self, n_iter=20):

        for i in range(n_iter):

            decision = self.random_decision()

            result = self.evaluate(decision)

            self.solutions.append((decision, result))

        if self.mode == "multi":
            return pareto_front(self.solutions)
        else:
            return max(self.solutions, key=lambda x: x[1])


class ModelSolution:

    def __init__(self, result, spec, param_index):

        self.params = result.params
        self.spec = spec
        self.param_index = param_index

        # These will be filled later
        self.train_metrics = {}
        self.test_metrics = {}
        self.validation_metrics = {}

        self.train_ll = None
        self.test_ll = None
        self.validation_ll = None

        self.aic = None
        self.bic = None

    # -------------------------------------
    # Evaluate on a dataset
    # -------------------------------------

    def evaluate(self, data, name="train", param_index: dict = None):

        objective = partial(mixed_model_loglik, data=data, spec=self.spec)
        mle_ll = float(-objective(self.params))

        # Apply PARTE shrinkage and track the corrected LL separately.
        # The corrected LL is used for AIC / BIC so that information
        # criteria reflect the parameters actually used for inference.
        corrected_ll = mle_ll
        if param_index is not None:
            try:
                params_parte, _, _ = compute_regularized_estimates(
                    self.params, objective, param_index,
                    variant="k3d3", check_multicollinearity=False,
                )
                corrected_ll = float(-objective(params_parte))
                self.params_parte = params_parte
            except Exception:
                pass

        metrics = evaluate_metrics(self.params, data, self.spec, name.upper())

        if name == "train":
            self.train_ll           = mle_ll
            self.train_ll_corrected = corrected_ll
            self.train_metrics      = metrics

            k = len(self.params)
            n = data["y"].shape[0]
            self.aic = float(2*k - 2*corrected_ll)
            self.bic = float(k * jnp.log(n) - 2*corrected_ll)
            self.aic_mle = float(2*k - 2*mle_ll)
            self.bic_mle = float(k * jnp.log(n) - 2*mle_ll)

        elif name == "test":
            self.test_ll           = mle_ll
            self.test_ll_corrected = corrected_ll
            self.test_metrics      = metrics

        elif name == "validation":
            self.validation_ll           = mle_ll
            self.validation_ll_corrected = corrected_ll
            self.validation_metrics      = metrics

    # -------------------------------------
    # Print summary
    # -------------------------------------

    def print_performance(self):

        print("\n================ MODEL PERFORMANCE ================")

        def _ll_line(mle, corrected):
            line = f"  LL (MLE):              {mle:.4f}"
            if corrected != mle:
                line += f"\n  LL (PARTE-corrected):  {corrected:.4f}  [d={corrected-mle:+.4f} vs MLE]"
            return line

        print("\n--- TRAIN ---")
        print(_ll_line(self.train_ll, getattr(self, "train_ll_corrected", self.train_ll)))
        print(self.train_metrics)

        if getattr(self, "test_ll", None) is not None:
            print("\n--- TEST ---")
            print(_ll_line(self.test_ll, getattr(self, "test_ll_corrected", self.test_ll)))
            print(self.test_metrics)

        if getattr(self, "validation_ll", None) is not None:
            print("\n--- VALIDATION ---")
            print(_ll_line(self.validation_ll,
                           getattr(self, "validation_ll_corrected", self.validation_ll)))
            print(self.validation_metrics)

        print(f"\nAIC (PARTE LL): {self.aic}")
        print(f"BIC (PARTE LL): {self.bic}")
        if hasattr(self, "aic_mle"):
            print(f"AIC (MLE LL):   {self.aic_mle}")
            print(f"BIC (MLE LL):   {self.bic_mle}")

        print("===================================================")


# =========================================================
# MODEL SPEC (HASHABLE FOR JAX)
# =========================================================
from dataclasses import dataclass, replace
@dataclass(frozen=True)
class ModelSpec:
    Kf: int
    Kr_ind: int
    Kr_cor: int
    Kg: int
    Kh: int
    Kv: int = 0
    Kzi: int = 0
    model: str = "poisson"
    zero_inflated: bool = False  # ✅ NEW
    fixed_names: tuple = ()
    zi_names: tuple = ()
    random_ind_names: tuple = ()
    random_cor_names: tuple = ()
    grouped_names: tuple = ()
    hetro_names: tuple = ()
    hetro_var_names: tuple = ()
    # ── GSE GRADIENT-SCORE LOADINGS ────────────────────────────────────
    # Kgse = number of gradient-score columns; one loading gamma_gse[k] per
    # random coefficient (structural equation in random_parameter_structure).
    Kgse: int = 0
    gse_names: tuple = ()
    random_ind_dists: tuple = ()
    random_cor_dists: tuple = ()
    grouped_dists: tuple = ()
    # ── VARIANCE REGULARISATION ────────────────────────────────────────
    # Two-sided log-barrier that keeps random-SD / dispersion scale
    # parameters strictly away from zero AND from runaway (+inf), so
    # random-parameters and NB2 models cannot degenerate into fixed-effect
    # / Poisson specifications or drift up a flat likelihood valley (raw
    # dispersion → +inf while fixed effects compensate to absurd values).
    # The barrier is exactly zero while every scale sits inside
    # [variance_floor, variance_cap], so sane fits are bit-identical.
    # Set variance_reg = 0.0 to disable.  variance_floor is the minimum
    # allowed scale; variance_cap the maximum allowed scale for any
    # random-SD or dispersion parameter.
    variance_reg:   float = 10.0
    variance_floor: float = 1e-3
    variance_cap:   float = 50.0
    latent_classes: int =1
    @property
    def K_random_total(self):
        return self.Kr_cor + self.Kr_ind


# =========================================================
# UTILITIES
# =========================================================

def build_cholesky(params, K):
    L = jnp.zeros((K, K))
    idx = 0
    for i in range(K):
        for j in range(i + 1):
            L = L.at[i, j].set(params[idx])
            idx += 1
    return L





def random_correlated(mean, chol_params, draws, K, dist_codes):

    L = jnp.zeros((K, K))
    tril = jnp.tril_indices(K)
    L = L.at[tril].set(chol_params)

    diag = jnp.diag_indices(K)
    L = L.at[diag].set(_positive_scale(L[diag]))

    z_corr = jnp.einsum("ij,njr->nir", L, draws)

    scale_dummy = jnp.zeros(K)  # not used, embedded in chol

    beta = transform_draws(
        z_corr,
        mean,
        scale_dummy,
        dist_codes
    )

    return beta


def _positive_scale(log_scale):
    """Map an unconstrained log-SD to a finite positive standard deviation."""
    return jnp.exp(jnp.clip(log_scale, -12.0, 6.0))


''' works with non hetrogeneity 
def random_correlated(mean, chol_params, draws, K):
    L = build_cholesky(chol_params, K)
    return mean[None, :, None] + jnp.einsum("ij,njr->nir", L, draws)
'''
def random_independent(mean, sd, draws, dist_codes):

    return transform_draws(
        draws,
        mean,
        sd,
        dist_codes
    )
'''
def random_independent(mean, sd, draws):
    return mean[None, :, None] + sd[None, :, None] * draws
'''

def poisson_loglik(y, mu):
    mu = jnp.clip(mu, 1e-12, 1e12)
    return y * jnp.log(mu) - mu - jsp.special.gammaln(y + 1)


def nb_loglik(y, mu, alpha):
    return nb2_logpmf_from_mean(y, mu, alpha)

def build_eta(params, data, spec: ModelSpec):

    blocks = unpack_params(params, spec)

    # Start with zero eta (N,P,1) inferred later
    eta = 0.0

    # =====================================================
    # FIXED EFFECTS
    # =====================================================
    if spec.Kf > 0:
        if data["Xf"].shape[-1] != spec.Kf:
            raise ValueError(
                f"ModelSpec.Kf={spec.Kf} does not match data['Xf'] width "
                f"({data['Xf'].shape[-1]}). The spec and data were built for "
                f"different fixed-effect variable sets — e.g. a per-class "
                f"Kf reduction (class_fixed_idx) was applied to the spec but "
                f"data['Xf'] was not sliced to the same columns, or vice versa."
            )
        eta = jnp.einsum("npk,k->np", data["Xf"], blocks["beta_f"])[..., None]

    # =====================================================
    # HETEROGENEITY SHIFT (MEANS)
    # =====================================================
    shift = None
    if spec.Kh > 0 and spec.K_random_total > 0:

        Z = data["Xh"]  # (N,P,Kh)

        shift_full = jnp.einsum(
            "npk,km->npm",
            Z,
            blocks["gamma"]
        )

        # average across panel dimension
        shift = jnp.mean(shift_full, axis=1)  # (N,K_random_total)

    # =====================================================
    # HETEROGENEITY SHIFT (VARIANCES)
    # =====================================================
    shift_var = None
    if spec.Kv > 0 and spec.K_random_total > 0:

        Z_var = data["Xh_var"]  # (N,P,Kv)

        shift_var_full = jnp.einsum(
            "npk,km->npm",
            Z_var,
            blocks["gamma_var"]
        )

        # average across panel dimension
        shift_var = jnp.mean(shift_var_full, axis=1)  # (N,K_random_total)

    # =====================================================
    # GSE GRADIENT-SCORE SHIFT (structural equation)
    # =====================================================
    # gamma_k * g_nk per random coefficient; G columns align with the
    # random-coefficient order (cor, then ind).  See
    # random_parameter_structure for the canonical equation.
    gse_shift = None
    if getattr(spec, "Kgse", 0) > 0 and spec.K_random_total > 0:
        _G = data.get("G") if isinstance(data, dict) else None
        _gg = blocks.get("gamma_gse")
        if _G is not None and _gg is not None and _G.shape[-1] > 0:
            if _G.shape[-1] != spec.K_random_total:
                raise ValueError(
                    f"GSE scores have {_G.shape[-1]} columns but the spec has "
                    f"{spec.K_random_total} random coefficients — G must align "
                    f"with the random-coefficient order (cor, then ind)."
                )
            gse_shift = jnp.mean(_G * _gg[None, None, :], axis=1)

    # =====================================================
    # CORRELATED RANDOM EFFECTS
    # =====================================================
    if spec.Kr_cor > 0:

        _shift_cor = 0.0
        if shift is not None:
            _shift_cor = _shift_cor + shift[:, :spec.Kr_cor]
        if gse_shift is not None:
            _shift_cor = _shift_cor + gse_shift[:, :spec.Kr_cor]
        mean_cor = blocks["mean_cor"]
        mean_cor = mean_cor[None, :] + _shift_cor

        # For correlated effects, variance heterogeneity affects the Cholesky factor
        # We apply the mean shift across observations to the log-diagonal
        chol = blocks["chol"]
        if shift_var is not None:
            # Average variance heterogeneity shift across observations for the Cholesky diagonal
            shift_var_cor = jnp.mean(shift_var[:, :spec.Kr_cor], axis=0)
            K = spec.Kr_cor
            diag_idx = jnp.array([i * (i + 3) // 2 for i in range(K)])
            chol = chol.at[diag_idx].add(shift_var_cor)

        beta_cor = random_correlated(
            mean_cor,
            chol,
            data["draws_cor"],
            spec.Kr_cor,
            jnp.array([DIST_MAP[d] for d in spec.random_cor_dists])
        )

        eta += jnp.einsum("npk,nkr->npr", data["Xr_cor"], beta_cor)

    # =====================================================
    # INDEPENDENT RANDOM EFFECTS
    # =====================================================
    if spec.Kr_ind > 0:

        _shift_ind = 0.0
        if shift is not None:
            _shift_ind = _shift_ind + shift[:, spec.Kr_cor:]
        if gse_shift is not None:
            _shift_ind = _shift_ind + gse_shift[:, spec.Kr_cor:]
        mean_ind = blocks["mean_ind"]
        mean_ind = mean_ind[None, :] + _shift_ind

        sd_ind = blocks["sd_ind"]
        if shift_var is not None:
            # Apply variance heterogeneity shift to log-SDs
            sd_ind = sd_ind + shift_var[:, spec.Kr_cor:]

        beta_ind = random_independent(
            mean_ind,
            sd_ind,
            data["draws_ind"],
            jnp.array([DIST_MAP[d] for d in spec.random_ind_dists])
        )

        eta += jnp.einsum("npk,nkr->npr", data["Xr_ind"], beta_ind)

    # =====================================================
    # GROUPED RANDOM EFFECTS
    # =====================================================
    if spec.Kg > 0:

        mean_g = blocks["mean_g"]
        sd_g = blocks["sd_g"]
        g_start = spec.Kr_cor + spec.Kr_ind
        g_end = g_start + spec.Kg

        # Heterogeneity in the MEANS of grouped coefficients:
        # E[gamma_g] = Gamma a_g. This is what lets a future fixture's
        # functional form depend on its game-day attributes (crowd,
        # kickoff, competition codes) instead of being a draw around a
        # common mean whose expectation is identical for every fixture.
        if spec.Kh > 0 and spec.Kg > 0:
            _Xh_group = data.get("Xh_group")
            _gamma_g = blocks.get("gamma_g")
            if (_Xh_group is not None and _gamma_g is not None
                    and getattr(_Xh_group, "shape", (0, 0))[1] > 0):
                _shift_g = jnp.einsum("gk,km->gm", _Xh_group, _gamma_g)
                mean_g = mean_g[None, :] + _shift_g

        if shift_var is not None:
            # Apply variance heterogeneity shift to grouped log-SDs
            # Use pre-computed group-level variance heterogeneity shift
            g_start = spec.Kr_cor + spec.Kr_ind
            g_end = g_start + spec.Kg
            
            # Use pre-computed group-level shift from Xh_var_group
            Xh_var_group = data.get("Xh_var_group")
            if Xh_var_group is not None and Xh_var_group.shape[0] > 0 and Xh_var_group.shape[1] > 0:
                # Xh_var_group has shape (n_groups, Kv)
                # We need to map this to the grouped random effects
                # The grouped effects are at position g_start:g_end in random total
                # For simplicity, apply the same group-level shift to all grouped effects
                if g_end <= Xh_var_group.shape[1] + g_start:
                    sd_g = sd_g + Xh_var_group[:, :spec.Kg]

        beta_g_all = transform_draws(
            data["draws_g"],
            mean_g,
            sd_g,
            jnp.array([DIST_MAP[d] for d in spec.grouped_dists])
        )

        beta_g = beta_g_all[data["group_ids"]]

        eta += jnp.einsum("npk,nkr->npr", data["Xg"], beta_g)

    # =====================================================
    # OFFSET
    # =====================================================
    offset = data["offset"]

    if offset.ndim == 2:
        offset = offset[..., None]

    eta += offset

    return eta

def ensure_3d(x):
    if x.ndim == 2:
        return x[..., None]
    return x


def transform_draws(draws, mean, scale, dist_codes):
    """
    draws: (N,K,R) standard normal or uniform
    mean:  (K,) or (N,K)
    scale: (K,) or (N,K)  # per-observation scale for heterogeneity in variances
    dist_codes: integer array (K,)
        0 = normal
        1 = lognormal
        2 = triangular
        3 = uniform
        4 = neglognormal (strictly negative site effects)
    """

    scale = _positive_scale(scale)

    if mean.ndim == 1:
        mean = mean[None, :, None]
    else:
        mean = mean[:, :, None]

    # Handle scale: can be (K,) or (N,K)
    if scale.ndim == 1:
        scale = scale[None, :, None]
    else:
        scale = scale[:, :, None]

    z = draws

    # Normal
    beta_normal = mean + scale * z

    # Lognormal
    beta_lognormal = jnp.exp(mean + scale * z)

    # Neglognormal (strictly negative site effects for treatments that only reduce)
    beta_neglognormal = -jnp.exp(mean + scale * z)

    # Triangular (using inverse CDF of symmetric triangular)
    # Assume draws are uniform in (-1,1)
    u = jsp.stats.norm.cdf(z)
    beta_tri = mean + scale * (2*u - 1)
    
        # Uniform (mean + scale * u) where u in (-1,1)
    u = jsp.stats.norm.cdf(z) * 2 - 1
    beta_uniform = mean + scale * u

    # Stack and select
    betas = jnp.stack([beta_normal, beta_lognormal, beta_tri, beta_uniform, beta_neglognormal], axis=-1)

    # dist_codes shape (K,)
    selector = jax.nn.one_hot(dist_codes, 5)  # (K,5)

    selector = selector[None, :, None, :]  # (1,K,1,5)

    beta = jnp.sum(betas * selector, axis=-1)

    return beta  # (N,K,R)


# LOG LIKELIHOOD
# =========================================================





@partial(jax.jit, static_argnames=("spec", "indivi"))
def mixed_model_loglik(params, data, spec: ModelSpec, indivi = False):
    
    # ==========================================================
    # ✅ LATENT CLASS WRAPPER (NEW)
    # ==========================================================
    if spec.latent_classes > 1:

        C = spec.latent_classes
        base_spec = replace(spec, latent_classes=1)

        # Build base index once
        base_index = build_param_index(base_spec)
        K_base = base_index["total_params"]

        # Split parameters
        theta_all = params[:C * K_base].reshape(C, K_base)
        logits = params[C * K_base:]

        logits_full = jnp.concatenate([jnp.array([0.0]), logits])
        pi = jax.nn.softmax(logits_full)

        ll_classes = []

        for c in range(C):

            ll_c = mixed_model_loglik(
                theta_all[c],
                data,
                base_spec,
                indivi = True
            )                                               # (N,) log-likelihoods (negative)

            ll_classes.append(ll_c + jnp.log(pi[c]))

        ll_stack = jnp.stack(ll_classes, axis = 1)
        ll_ind = jsp.special.logsumexp(ll_stack, axis=1)

        if indivi:
            return ll_ind

        return -jnp.sum(ll_ind)

        #return -jsp.special.logsumexp(ll_stack)

    blocks = unpack_params(params, spec)

    eta = build_eta(params, data, spec)

    # Clip for numerical stability.
    # Count/log-normal models work in log-scale so ±25 prevents exp overflow.
    # Linear-predictor models (gaussian, tobit) work in data scale — use a
    # wider clip that still prevents NaN but doesn't strangle their gradients.
    if spec.model in {"gaussian", "tobit"}:
        eta = jnp.clip(eta, -500.0, 500.0)
    else:
        eta = jnp.clip(eta, -25.0, 25.0)

    if eta.ndim == 2:
        eta = eta[..., None]

    y = ensure_3d(data["y"])
    mask = ensure_3d(data["mask"])

    R = eta.shape[-1]

    # =========================
    # Likelihood
    # =========================
    # =========================
    # BASE COUNT LIKELIHOOD
    # =========================
    if spec.model == "poisson":
        mu = jnp.exp(eta)
        ll_count = poisson_loglik(y, mu)

    elif spec.model == "nb":
        alpha = blocks["alpha"]
        ll_count = nb2_loglik(y, eta, alpha)
    elif spec.model == "nb1":
        # Linear-variance negative binomial: Var = mu * (1 + alpha).  Unlike the
        # NB2 branch this likelihood takes the mean rather than the linear
        # predictor, so eta is exponentiated here.
        ll_count = nb1_loglik(y, jnp.exp(eta), blocks["alpha"])
    elif spec.model == "lognormal":
        sigma    = blocks["sigma"]
        ll_count = lognormal_loglik(y, eta, sigma)
    elif spec.model == "gaussian":
        sigma    = blocks["sigma"]
        ll_count = gaussian_loglik(y, eta, sigma)
    elif spec.model == "tobit":
        # Left-censored at 0; eta is the linear predictor for the latent Y*
        sigma    = blocks["sigma"]
        ll_count = tobit_loglik(y, eta, sigma)
    else:
        raise ValueError("Unknown model")

    # =========================
    # APPLY ZERO INFLATION
    # =========================
    if spec.zero_inflated:

        if spec.Kzi > 0:
            eta_zi = jnp.einsum(
                    "npk,k->np",
                    data["Xzi"],
                    blocks["beta_zi"]
            )[..., None]   # make (N,P,1)
        else:
            # intercept-only inflation
            eta_zi = jnp.zeros_like(eta[..., :1])

        pi = jax.nn.sigmoid(eta_zi)
        
        mu = jnp.exp(eta)

        # Probability of zero from count model
        if spec.model == "poisson":
            f0 = jnp.exp(-mu)
        elif spec.model == "nb1":
            log_f0 = nb1_loglik(
                jnp.zeros_like(y), mu, blocks["alpha"]
            )
            f0 = jnp.exp(log_f0)
        else:
            # NB zero probability
            log_f0 = nb2_logpmf(
                jnp.zeros_like(y), eta, blocks["alpha"]
            )
            f0 = jnp.exp(log_f0)

        zero_mask = (y == 0)

        ll_zero = jnp.log(pi + (1 - pi) * f0 + 1e-12)
        ll_pos = jnp.log(1 - pi + 1e-12) + ll_count

        ll = jnp.where(zero_mask, ll_zero, ll_pos)

    else:
        ll = ll_count

    ll = ll * mask
    ll_panel = jnp.sum(ll, axis=1)

    # ✅ Log-sum-exp simulation averaging
    if R > 1:
        ll_ind = jsp.special.logsumexp(ll_panel, axis=-1) - jnp.log(R)
    else:
        ll_ind = ll_panel.squeeze(-1)

    # ── Two-sided variance-scale barrier ──────────────────────────
    # Applies ModelSpec.variance_reg / variance_floor / variance_cap here:
    # previously declared but never used on the single-class path, leaving
    # raw dispersion/SD params unbounded so sparse-data fits could drift
    # alpha → +inf while fixed effects compensated to absurd values.
    # The barrier is exactly 0 inside [floor, cap], so sane fits are
    # bit-identical; only degenerate drift is pushed back.
    vr = float(getattr(spec, "variance_reg", 0.0) or 0.0)
    if vr > 0.0:
        floor = float(getattr(spec, "variance_floor", 1e-3) or 1e-3)
        cap = float(getattr(spec, "variance_cap", 50.0) or 50.0)
        vpen = vr * _variance_barrier(blocks, spec, floor, cap)
        if indivi:
            n_obs = int(data["y"].shape[0])
            return ll_ind - vpen / max(n_obs, 1)
        return -jnp.sum(ll_ind) + vpen

    if indivi:
        return ll_ind
    return -jnp.sum(ll_ind)



@partial(jax.jit, static_argnames=("spec",))
def mixed_model_loglik_individual(params, data, spec: ModelSpec):
    return mixed_model_loglik(params, data, spec, indivi = True)


# --- JAX compilation cache management for static_argnames=("spec",) ---
# Each unique ModelSpec triggers a fresh trace + XLA executable.
# We track seen specs by id() and clear caches every N new specs.
_spec_seen = set()
_spec_cache_threshold = 50

def _call_loglik(params, data, spec: ModelSpec, indivi: bool = False):
    """Wrapper that bounds JAX compilation cache growth from spec static arg."""
    sid = id(spec)
    if sid not in _spec_seen:
        _spec_seen.add(sid)
        if len(_spec_seen) >= _spec_cache_threshold:
            jax.clear_caches()
            gc.collect()
            _spec_seen.clear()
    return mixed_model_loglik(params, data, spec, indivi=indivi)

def _call_loglik_individual(params, data, spec: ModelSpec):
    """Wrapper for mixed_model_loglik_individual with cache management."""
    return _call_loglik(params, data, spec, indivi=True)

def nb1_loglik(y, mu, alpha):

    alpha = jnp.exp(alpha)

    r = mu / alpha
    p = 1.0 / (1.0 + alpha)

    ll = (
        jsp.special.gammaln(y + r)
        - jsp.special.gammaln(r)
        - jsp.special.gammaln(y + 1)
        + r * jnp.log(p)
        + y * jnp.log(1 - p)
    )

    return ll

def nb2_loglik(y, eta, alpha):

    return nb2_logpmf(y, eta, alpha)


def _variance_barrier(blocks, spec, floor=1e-3, cap=50.0):
    """Two-sided log-barrier on variance scales (random-SDs + NB dispersion).

    Each scale ``s`` used by the likelihood contributes
    ``relu(log(floor) - log(s)) + relu(log(s) - log(cap))`` — exactly zero
    while ``s`` stays inside ``[floor, cap]`` and growing without bound as
    ``s`` escapes in either direction.  This wires the ``ModelSpec``
    ``variance_reg`` / ``variance_floor`` / ``variance_cap`` fields into the
    single-class objective (previously they were declared but never applied
    there), so the optimiser can no longer drift ``alpha → +inf`` up a flat
    sparse-data valley while fixed effects compensate.

    Scales used by the likelihood (mirrors the LC-patch barrier):
    * independent SD : exp(log_sd_ind)
    * correlated SD  : exp(diag of Cholesky)
    * grouped SD     : exp(log_sd_g)
    * NB2 dispersion : exp(log_alpha)
    """
    def _get(key):
        try:
            get = getattr(blocks, "get", None)
            return get(key) if callable(get) else None
        except Exception:
            return None

    floor_log = jnp.log(float(floor))
    cap_log = jnp.log(float(cap))
    eps = 1e-12
    p = 0.0

    def _hit(s):
        s = s + eps
        return (jnp.sum(jnp.maximum(floor_log - jnp.log(s), 0.0))
                + jnp.sum(jnp.maximum(jnp.log(s) - cap_log, 0.0)))

    sd_ind = _get("sd_ind")
    if sd_ind is not None:
        p = p + _hit(_positive_scale(sd_ind))

    chol = _get("chol")
    kr_cor = int(getattr(spec, "Kr_cor", 0) or 0)
    if chol is not None and kr_cor > 0:
        diag_idx = jnp.array([i * (i + 3) // 2 for i in range(kr_cor)])
        p = p + _hit(_positive_scale(chol[diag_idx]))

    sd_g = _get("sd_g")
    if sd_g is not None:
        p = p + _hit(_positive_scale(sd_g))

    alpha = _get("alpha")
    if alpha is not None:
        p = p + _hit(nb2_dispersion(alpha))

    return p



def _validate_role_exclusivity(manual_spec):
    """Roles of a given variable are mutually exclusive.

    A variable may be fixed (constant across individuals) *or* random
    (one mean + SD) *or* correlated-random *or* grouped *or* a
    heterogeneity term, never several at once.  Allowing e.g.
    ``fixed_terms`` to contain a variable that is also in ``rdm_terms``
    gives the likelihood two free ways to shift its mean (a fixed
    coefficient plus a random-parameter mean), which is not identified
    and shows up as blown-out standard errors.

    Raises
    ------
    ValueError
        If any variable appears under more than one role.
    """
    from collections import defaultdict

    def _base(term):
        return str(term).split(":")[0].strip()

    roles = defaultdict(set)
    for term in manual_spec.get("fixed_terms", []) or []:
        roles[_base(term)].add("fixed")
    for term in manual_spec.get("rdm_terms", []) or []:
        roles[_base(term)].add("rdm")
    for term in manual_spec.get("rdm_cor_terms", []) or []:
        roles[_base(term)].add("rdm_cor")
    for term in manual_spec.get("grouped_terms", []) or []:
        roles[_base(term)].add("grouped")
    for term in manual_spec.get("hetro_in_means", []) or []:
        roles[_base(term)].add("hetro_in_means")
    for term in manual_spec.get("hetro_in_variances", []) or []:
        roles[_base(term)].add("hetro_in_variances")
    for col in manual_spec.get("gse_cols", []) or []:
        roles[_base(col)].add("gse")

    clashing = {v: sorted(r) for v, r in roles.items() if len(r) > 1}
    if clashing:
        raise ValueError(
            "Non-identified random-parameter specification: the following "
            "variable(s) appear under multiple roles (a variable must be "
            "either fixed or random, not both): "
            + ", ".join(f"{v!r} -> {rs}" for v, rs in clashing.items())
        )


def parse_manual_spec(manual_spec):

    _validate_role_exclusivity(manual_spec)

    fixed_cols = manual_spec.get("fixed_terms", [])

    rdm_terms = manual_spec.get("rdm_terms", [])
    random_ind = [term.split(":")[0] for term in rdm_terms]

    rdm_cor_terms = manual_spec.get("rdm_cor_terms", [])
    random_cor = [term.split(":")[0] for term in rdm_cor_terms]
    

    grouped_terms = manual_spec.get("grouped_terms", [])
    grouped_cols = [term.split(":")[0] for term in grouped_terms]
    hetro_terms = manual_spec.get("hetro_in_means", [])
    hetro_cols = [term.split(":")[0].strip() for term in hetro_terms]
    hetro_var_terms = manual_spec.get("hetro_in_variances", [])
    hetro_var_cols = [term.split(":")[0].strip() for term in hetro_var_terms]
    gse_cols = list(manual_spec.get("gse_cols", []))
    gse_scores = manual_spec.get("gse_scores", None)
    random_ind_dists = [term.split(":")[1] for term in rdm_terms]
    random_cor_dists = [term.split(":")[1] for term in rdm_cor_terms]
    grouped_dists = [term.split(":")[1] for term in grouped_terms]
    zi_cols = manual_spec.get("zi_terms", [])

    return fixed_cols, random_ind, random_cor, grouped_cols, hetro_cols, hetro_var_cols, gse_cols, gse_scores, random_ind_dists, random_cor_dists, grouped_dists, zi_cols


def build_model_from_manual_spec(
    df,
    manual_spec,
    id_col,
    y_col,
    offset_col=None,
    draws_ind=None,
    draws_cor=None,
    draws_g=None,
    standardize=True,
    R=200
):

    (fixed_cols, random_ind, random_cor, grouped_cols, hetro_cols, hetro_var_cols, gse_cols, gse_scores, random_ind_dists, random_cor_dists,
    grouped_dists, zi_cols) = parse_manual_spec(manual_spec)

    data, spec = build_jax_data(
        df=df,
        id_col=id_col,
        y_col=y_col,
        group_id_col=manual_spec.get("group_id_col", None),
        fixed_cols=fixed_cols,
        random_ind_cols=random_ind,
        random_cor_cols=random_cor,
        grouped_cols=grouped_cols,
        hetro_cols=hetro_cols,
        hetro_var_cols=hetro_var_cols,
        gse_cols=gse_cols,
        gse_scores=gse_scores,
        zi_cols=zi_cols,
        offset_col=offset_col,
        draws_ind=draws_ind,
        draws_cor=draws_cor,
        draws_g=draws_g,
        random_ind_dists=random_ind_dists,
        random_cor_dists=random_cor_dists,
        grouped_dists=grouped_dists,
        standardize=standardize,
        R=R
    )

    # ``dispersion`` is the historical on/off flag (0 = Poisson, non-zero = NB2).
    # An explicit ``model`` key overrides it, which is how the linear-variance
    # negative binomial (``"nb1"``) is requested; specs without the key keep the
    # old behaviour exactly.
    model_type = manual_spec.get("model") or (
        "nb" if manual_spec.get("dispersion", 0) else "poisson"
    )
    spec = replace(spec, model=model_type)

    return data, spec


def balance_panel_dataframe(df, id_col, y_col, feature_cols):

    # O(N) single-pass build: the old per-id boolean scan
    # (df[df[id_col] == pid] inside a 100k-iteration loop) is O(N^2) and
    # dominates walltime/memory when id_col is unique (e.g. row_id).
    # factorize + one linear fill gives identical X/y/mask.
    df_sorted = df.sort_values(id_col, kind="mergesort").reset_index(drop=True)

    codes, uniques = pd.factorize(df_sorted[id_col], sort=False)
    N = len(uniques)
    if N == 0:
        raise ValueError(
            f"balance_panel_dataframe received an empty panel: 0 observations "
            f"and {N} unique '{id_col}' values. This usually means an upstream "
            f"filter or cluster subset removed all rows. Check the caller's data "
            f"selection (e.g. skip clusters with too few segments before fitting)."
        )
    codes = np.asarray(codes, dtype=np.int64)
    counts = np.bincount(codes, minlength=N)
    if counts.size == 0:
        raise ValueError(
            f"balance_panel_dataframe received an empty panel: 0 observations "
            f"and {N} unique '{id_col}' values. This usually means an upstream "
            f"filter or cluster subset removed all rows. Check the caller's data "
            f"selection (e.g. skip clusters with too few segments before fitting)."
        )
    P = int(counts.max())

    K = len(feature_cols)

    X = np.zeros((N, P, K))
    y = np.zeros((N, P, 1))
    mask = np.zeros((N, P))

    if K > 0:
        feat_vals = np.asarray(df_sorted[feature_cols].to_numpy(dtype=float))
    else:
        feat_vals = np.zeros((len(df_sorted), 0))
    y_vals = np.asarray(pd.to_numeric(df_sorted[y_col], errors="coerce").fillna(0.0),
                        dtype=float)
    pos = np.zeros(N, dtype=np.int64)
    for i in range(len(df_sorted)):
        c = int(codes[i])
        t = int(pos[c])
        if K > 0:
            X[c, t, :] = feat_vals[i]
        y[c, t, 0] = y_vals[i]
        mask[c, t] = 1.0
        pos[c] = t + 1

    return X, y, mask

def extract_offset(df, id_col, offset_col):
    # O(N) single-pass (see balance_panel_dataframe): avoids the O(N^2)
    # per-id boolean scan when id_col is unique.
    df_sorted = df.sort_values(id_col, kind="mergesort").reset_index(drop=True)
    codes, uniques = pd.factorize(df_sorted[id_col], sort=False)
    N = len(uniques)
    if N == 0:
        raise ValueError(
            f"extract_offset received an empty panel: 0 observations and {N} "
            f"unique '{id_col}' values (likely an empty cluster subset)."
        )
    codes = np.asarray(codes, dtype=np.int64)
    counts = np.bincount(codes, minlength=N)
    if counts.size == 0:
        raise ValueError(
            f"extract_offset received an empty panel: 0 observations and {N} "
            f"unique '{id_col}' values (likely an empty cluster subset)."
        )
    P = int(counts.max())

    offset = np.zeros((N, P, 1))
    off_vals = np.asarray(pd.to_numeric(df_sorted[offset_col], errors="coerce").fillna(0.0),
                          dtype=float)
    pos = np.zeros(N, dtype=np.int64)
    for i in range(len(df_sorted)):
        c = int(codes[i])
        t = int(pos[c])
        offset[c, t, 0] = off_vals[i]
        pos[c] = t + 1

    return offset

# =========================================================
# BUILD JAX DATA
# =========================================================
def build_jax_data(
    df,
    id_col,
    y_col,
    group_id_col=None,
    fixed_cols=None,
    random_ind_cols=None,
    random_cor_cols=None,
    grouped_cols=None,
    hetro_cols=None,
    hetro_var_cols=None,
    gse_cols=None,
    gse_scores=None,
    offset_col=None,
    draws_ind=None,
    draws_cor=None,
    draws_g=None,
    random_ind_dists=None,
    random_cor_dists=None,
    grouped_dists=None,
    zi_cols = None,
    standardize=True,
    R=200
):

    # -----------------------------
    # Safe defaults
    # -----------------------------
    fixed_cols = fixed_cols or []
    random_ind_cols = random_ind_cols or []
    random_cor_cols = random_cor_cols or []
    grouped_cols = grouped_cols or []
    hetro_cols = hetro_cols or []
    hetro_var_cols = hetro_var_cols or []
    gse_cols = gse_cols or []
    zi_cols = zi_cols or  []

    random_ind_dists = random_ind_dists or []
    random_cor_dists = random_cor_dists or []
    grouped_dists = grouped_dists or []

    # -----------------------------
    # Build balanced panel
    # -----------------------------
    # Always include intercept
    intercept_name = "__INTERCEPT__"

    df = df.copy()
    df[intercept_name] = 1.0

    # ── Standardise continuous predictors before building arrays ─────────
    # The scaler is stored in the returned data dict so that print_summary
    # can back-transform to original-scale coefficients for reporting.
    _predictor_cols = list(set(
        fixed_cols + random_ind_cols + random_cor_cols
        + grouped_cols + hetro_cols + hetro_var_cols + gse_cols + zi_cols
    ))
    # ``standardize=False`` keeps the caller's columns on the scale they were
    # supplied on.  The CMF pipeline already passes standardised ``*_Z``
    # columns and deliberately builds log(AADT)/interaction columns, so
    # re-standardising them here silently changes the model: a random
    # coefficient on *centred* log(AADT) is not a random elasticity, because
    # centring adds an implied random intercept of SD = tau * mean(log AADT).
    _scaler = compute_scaler(df, _predictor_cols) if standardize else {}
    if _scaler:
        df = apply_scaler(df, _scaler)

    all_features = list(set(
        ["__INTERCEPT__"] + fixed_cols + random_ind_cols + random_cor_cols + grouped_cols + hetro_cols + hetro_var_cols + gse_cols + zi_cols
    ))

    X_all, y, mask = balance_panel_dataframe(
        df, id_col, y_col, all_features
    )

    # -----------------------------
    # Group IDs
    # -----------------------------
    if group_id_col is not None and len(grouped_cols) > 0:

        df_sorted = df.sort_values(id_col)
        group_codes = df_sorted[group_id_col].astype("category").cat.codes.values
        unique_groups = np.unique(group_codes)
        G = len(unique_groups)

    else:
        group_codes = None
        G = 0

    # -----------------------------
    # Extract feature blocks
    # -----------------------------
    col_map = {col: i for i, col in enumerate(all_features)}

    def extract(cols):
        if len(cols) == 0:
            return np.zeros((X_all.shape[0], X_all.shape[1], 0))
        idx = [col_map[c] for c in cols if c in col_map]
        return X_all[:, :, idx]

    fixed_cols_with_intercept = ["__INTERCEPT__"] + fixed_cols
    Xf = extract(fixed_cols_with_intercept)
    X_fixed = extract(fixed_cols)
    X_intercept = extract(["__INTERCEPT__"])
    Xf = np.concatenate([X_intercept, X_fixed], axis=2)
    Xr_ind = extract(random_ind_cols)
    Xr_cor = extract(random_cor_cols)
    Xg = extract(grouped_cols)
    Xh = extract(hetro_cols)
    Xh_var = extract(hetro_var_cols)
    Xgse = extract(gse_cols)
    Xzi = extract(zi_cols)

    # Group-level means of the heterogeneity-in-means covariates. A grouped
    # random coefficient is constant WITHIN a group, so its mean must be
    # shifted by that group's attributes, not by each row's. Without this,
    # the coefficient for an unseen group (e.g. a future fixture) is a fresh
    # draw around a common mean, and averaging over draws erases the very
    # between-group signal the hierarchical term is meant to carry. With it,
    # E[gamma_g] = Gamma a_g and a future fixture's coefficients are
    # predicted from its own game-day attributes.
    if group_codes is not None and G > 0 and len(hetro_cols) > 0:
        # Build from df_sorted with the SAME category codes used for
        # group_ids, so the rows cannot drift out of alignment if
        # balance_panel_dataframe drops an id.
        _tmp = df_sorted[list(hetro_cols)].copy()
        _tmp["__group_code__"] = group_codes
        _Xh_group = (_tmp.groupby("__group_code__", observed=True)
                     [list(hetro_cols)].mean()
                     .reindex(range(G)).fillna(0.0).to_numpy(dtype=float))
    else:
        _Xh_group = np.zeros((max(G, 0), Xh.shape[2]), dtype=float)

    # Auto-generate simulation draws when random blocks are present but no
    # draws were supplied (mirrors main_hpc_lc_patch; without draws the
    # random blocks are silently dead weight).
    _n_draw = int(X_all.shape[0])
    if draws_ind is None and Xr_ind.shape[2] > 0:
        draws_ind = generate_halton_normal(_n_draw, Xr_ind.shape[2], R, seed=42)
    if draws_cor is None and Xr_cor.shape[2] > 0:
        draws_cor = generate_halton_normal(_n_draw, Xr_cor.shape[2], R, seed=43)
    if draws_g is None and Xg.shape[2] > 0:
        # Group draws are indexed by GROUP (build_eta does
        # beta_g = beta_g_all[data["group_ids"]]), so this tensor must have
        # one row per group, not one row per panel. Using _n_draw (panels)
        # allocated a (N_panels, Kg, R) tensor of which only the first G
        # rows are addressable -- silent dead weight rather than a crash,
        # because G <= N always holds. The refit path reaches here
        # (fit_manual_model passes draws_g=None) while the search path
        # supplies draws_g explicitly and was always correct.
        _g_draws = int(G) if (group_codes is not None and G > 0) else int(_n_draw)
        draws_g = generate_halton_normal(_g_draws, Xg.shape[2], R, seed=44)

    N, P = y.shape[0], y.shape[1]

    # -----------------------------
    # GSE gradient scores (N, P, Kgse)
    # -----------------------------
    # Either extracted from df columns (gse_cols) or passed explicitly as
    # gse_scores with shape (N, Kgse) / (N, P, Kgse).  Callers standardise
    # via random_parameter_structure.standardise_scores first.
    if gse_scores is not None:
        _g = np.asarray(gse_scores, dtype=float)
        if _g.ndim == 2:
            _g = np.broadcast_to(_g[:, None, :], (N, P, _g.shape[1])).copy()
        G = _g
    else:
        G = np.asarray(Xgse, dtype=float)
    if G.shape[2] == 0:
        G = np.zeros((N, P, 0))

    # -----------------------------
    # Offset
    # -----------------------------
    if offset_col:
        offset = extract_offset(df, id_col, offset_col)
    else:
        offset = np.zeros((N, P, 1))
    N = X_all.shape[0]
    # -----------------------------
    # Build data dict
    # -----------------------------
    data = {
        "Xf": jnp.array(Xf),
        "Xr_ind": jnp.array(Xr_ind),
        "Xr_cor": jnp.array(Xr_cor),
        "Xg": jnp.array(Xg),
        "Xh": jnp.array(Xh),
        "Xh_var": jnp.array(Xh_var),
        "Xh_group": jnp.array(_Xh_group),
        "G": jnp.array(G),
        "Xzi": jnp.array(Xzi),
        "y": jnp.array(y),
        "mask": jnp.array(mask),
        "offset": jnp.array(offset),
        "draws_ind": jnp.zeros((N, 0, R)) if draws_ind is None else jnp.array(draws_ind),
        "draws_cor": jnp.zeros((N, 0, R)) if draws_cor is None else jnp.array(draws_cor),
        "draws_g": jnp.zeros((N, 0, R)) if draws_g is None else jnp.array(draws_g),

        "group_ids": jnp.array(group_codes) if group_codes is not None else jnp.zeros(N, dtype=int),
        # Plain Python dict — not a JAX array.  Used by print_summary to
        # back-transform standardised coefficients to original scale.
        "scaler": _scaler,
    }

    
    
    
    # -----------------------------
    # Build ModelSpec (FULLY WIRED)
    # -----------------------------
    spec = ModelSpec(
        Kf=Xf.shape[2],
        Kr_ind=Xr_ind.shape[2],
        Kr_cor=Xr_cor.shape[2],
        Kg=Xg.shape[2],
        Kh=Xh.shape[2],
        Kv=Xh_var.shape[2],
        zi_names=tuple(zi_cols),
        Kzi=Xzi.shape[2],
        zero_inflated = (len(zi_cols) > 0),
        model="poisson",  # overwritten later if NB
        fixed_names=tuple(fixed_cols_with_intercept),
        random_ind_names=tuple(random_ind_cols),
        random_cor_names=tuple(random_cor_cols),
        grouped_names=tuple(grouped_cols),
        hetro_names=tuple(hetro_cols),
        hetro_var_names=tuple(hetro_var_cols),
        Kgse=G.shape[2],
        gse_names=tuple(gse_cols),
        random_ind_dists=tuple(random_ind_dists),
        random_cor_dists=tuple(random_cor_dists),
        grouped_dists=tuple(grouped_dists),
    )

    return data, spec


def build_base_index(spec, model=None):
    
    _model = model if model is not None else getattr(spec, 'model', 'poisson')

    idx = 0
    index = {}


    
    index["fixed"] = (idx, idx + spec.Kf)
    idx += spec.Kf
    
    # Zero Inflate
    if spec.Kzi > 0:
        index["zi_beta"] = (idx, idx + spec.Kzi)
        idx += spec.Kzi

    # =====================
    # CORRELATED RANDOM
    # =====================
    if spec.Kr_cor > 0:
        index["cor_mean"] = (idx, idx + spec.Kr_cor)
        idx += spec.Kr_cor

        Kchol = spec.Kr_cor * (spec.Kr_cor + 1) // 2
        index["chol"] = (idx, idx + Kchol)
        idx += Kchol

    # =====================
    # INDEPENDENT RANDOM
    # =====================
    if spec.Kr_ind > 0:
        index["ind_mean"] = (idx, idx + spec.Kr_ind)
        idx += spec.Kr_ind

        index["ind_sd"] = (idx, idx + spec.Kr_ind)
        idx += spec.Kr_ind

    if spec.Kg > 0:
        index["group_mean"] = (idx, idx + spec.Kg)
        idx += spec.Kg

        index["group_sd"] = (idx, idx + spec.Kg)
        idx += spec.Kg

    # Heterogeneity in MEANS of random parameters
    if spec.Kh > 0 and spec.K_random_total > 0:
        Khet = spec.Kh * spec.K_random_total
        index["hetro"] = (idx, idx + Khet)
        idx += Khet

    # Heterogeneity in VARIANCES of random parameters
    if spec.Kv > 0 and spec.K_random_total > 0:
        Khet_var = spec.Kv * spec.K_random_total
        index["hetro_var"] = (idx, idx + Khet_var)
        idx += Khet_var

    # Heterogeneity in MEANS of GROUPED random coefficients:
    # E[gamma_g] = Gamma_g a_g, shape (Kh, Kg). Kept separate from the
    # id-level gamma block because K_random_total deliberately excludes the
    # grouped dimension, so the two shift matrices have different widths.
    if spec.Kh > 0 and spec.Kg > 0:
        Khet_g = spec.Kh * spec.Kg
        index["hetro_group"] = (idx, idx + Khet_g)
        idx += Khet_g

    # GSE gradient-score loadings: one gamma per random coefficient.
    # G columns align with the random-coefficient order (cor, then ind).
    if getattr(spec, "Kgse", 0) > 0 and spec.K_random_total > 0:
        index["gse_gamma"] = (idx, idx + spec.K_random_total)
        idx += spec.K_random_total

    if _model in {"nb", "nb1"}:
        index["dispersion"] = idx
        idx += 1

    if _model in {"lognormal", "gaussian", "tobit", "weibull", "loglogistic", "weibull_ph"}:
        index["sigma"] = idx
        idx += 1

    index["total_params"] = idx
    index["_model"] = _model

    return index


    # ← your current build_param_index body

#=======================================
# PARAM INDEX
# =========================================================
def build_param_index(spec: ModelSpec):

    if spec.latent_classes == 1:
        return build_base_index(spec)
    base_spec = replace(spec, latent_classes=1)
    base_index = build_base_index(base_spec)

    K_base = base_index["total_params"]
    C = spec.latent_classes

    idx = 0
    index = {}

    index["class_params"] = (0, C * K_base)
    idx = C * K_base

    index["class_logits"] = (idx, idx + C - 1)
    idx += C - 1

    index["K_base"] = K_base
    index["total_params"] = idx

    return index



def compute_predictions(params, data, spec):
        eta = build_eta(params, data, spec)
        if eta.ndim == 2:
            eta = eta[..., None]
        mu = jnp.exp(eta)
        return mu

    
def compute_standard_errors(params, objective, return_diagnostics=False):
    """Compute Hessian SEs without hiding invalid curvature.

    The Hessian is normalised by its diagonal before eigendecomposition so
    fixed effects, random means, and log-SDs are compared on a common scale.
    Only positive, resolved eigen-directions contribute to the covariance.
    Parameters loading materially on negative or near-zero directions receive
    ``NaN`` SEs and are listed in the optional diagnostics result.

    The default return value remains the historical SE array.  Set
    ``return_diagnostics=True`` to receive ``(se, diagnostics)``.
    """
    params_np = np.asarray(params, dtype=float).reshape(-1)
    diagnostics = {
        "method": "scaled_positive_eigenspace",
        "hessian_finite_fraction": 0.0,
        "n_negative_eigenvalues": 0,
        "n_near_zero_eigenvalues": 0,
        "condition_number": np.inf,
        "unreliable_indices": [],
        "status": "failed",
    }

    def _return(se):
        se_jax = jnp.asarray(se, dtype=float)
        return (se_jax, diagnostics) if return_diagnostics else se_jax

    try:
        hess_fn = jax.jit(jax.hessian(objective))
        hess_raw = np.asarray(hess_fn(jnp.asarray(params_np)), dtype=float)
    except Exception as exc:
        diagnostics["status"] = f"hessian_failed: {exc}"
        return _return(np.full(len(params_np), np.nan))

    expected_shape = (len(params_np), len(params_np))
    if hess_raw.shape != expected_shape:
        diagnostics["status"] = "invalid_hessian_shape"
        return _return(np.full(len(params_np), np.nan))

    finite_mask = np.isfinite(hess_raw)
    diagnostics["hessian_finite_fraction"] = float(finite_mask.mean())
    if not finite_mask.all():
        diagnostics["status"] = "nonfinite_hessian"
        return _return(np.full(len(params_np), np.nan))

    hess = 0.5 * (hess_raw + hess_raw.T)
    diagonal = np.diag(hess)
    curvature_scale = np.sqrt(np.maximum(np.abs(diagonal), 1e-12))
    normalised = hess / np.outer(curvature_scale, curvature_scale)

    try:
        eigvals, eigvecs = np.linalg.eigh(normalised)
    except np.linalg.LinAlgError as exc:
        diagnostics["status"] = f"eigendecomposition_failed: {exc}"
        return _return(np.full(len(params_np), np.nan))

    max_abs_eigenvalue = float(np.max(np.abs(eigvals)))
    if not np.isfinite(max_abs_eigenvalue) or max_abs_eigenvalue <= 0:
        diagnostics["status"] = "zero_hessian"
        return _return(np.full(len(params_np), np.nan))

    eigen_tolerance = max(1e-10, max_abs_eigenvalue * 1e-8)
    positive = eigvals > eigen_tolerance
    negative = eigvals < -eigen_tolerance
    near_zero = ~positive & ~negative
    diagnostics["n_negative_eigenvalues"] = int(negative.sum())
    diagnostics["n_near_zero_eigenvalues"] = int(near_zero.sum())

    if positive.any():
        positive_vectors = eigvecs[:, positive]
        covariance_normalised = (
            positive_vectors * (1.0 / eigvals[positive])
        ) @ positive_vectors.T
        covariance = covariance_normalised / np.outer(
            curvature_scale, curvature_scale
        )
        diagonal_covariance = np.diag(covariance)
        se = np.sqrt(np.maximum(diagonal_covariance, 0.0))
    else:
        diagonal_covariance = np.full(len(params_np), np.nan)
        se = np.full(len(params_np), np.nan)

    bad_vectors = eigvecs[:, ~positive]
    bad_leverage = (
        np.sum(bad_vectors ** 2, axis=1)
        if bad_vectors.size
        else np.zeros(len(params_np))
    )
    unreliable = (
        ~np.isfinite(se)
        | (diagonal_covariance <= 0)
        | (bad_leverage > 0.25)
    )
    se[unreliable] = np.nan
    diagnostics["unreliable_indices"] = np.flatnonzero(unreliable).tolist()

    positive_eigenvalues = eigvals[positive]
    if positive_eigenvalues.size:
        diagnostics["condition_number"] = float(
            positive_eigenvalues.max() / positive_eigenvalues.min()
        )
    diagnostics["status"] = (
        "ok" if not diagnostics["unreliable_indices"] else "curvature_issues"
    )
    if (
        diagnostics["status"] != "ok"
        or diagnostics["hessian_finite_fraction"] < 1.0
        or diagnostics["n_negative_eigenvalues"] > 0
        or diagnostics["n_near_zero_eigenvalues"] > 0
        or not np.isfinite(diagnostics["condition_number"])
    ):
        import warnings

        warnings.warn(
            "compute_standard_errors: the Hessian is not full-rank "
            f"(status={diagnostics['status']!r}, "
            f"negative_eigenvalues={diagnostics['n_negative_eigenvalues']}, "
            f"near_zero_eigenvalues={diagnostics['n_near_zero_eigenvalues']}, "
            f"condition_number={diagnostics['condition_number']:.3g}). "
            f"{len(diagnostics['unreliable_indices'])} parameter(s) received "
            "NaN SEs. A rank-deficient Hessian means the random-parameter "
            "structure is not identified — treat this as a model/spec "
            "problem, not evidence that the effect is zero.",
            RuntimeWarning,
            stacklevel=2,
        )
    return _return(se)


def sd_display_with_delta_se(raw, se_raw, transform="exp"):
    """Display-scale estimate + delta-method SE for a positive SD parameter.

    Random-parameter SDs and Cholesky diagonals are optimised on an
    unconstrained log scale; the likelihood maps them to a positive SD via
    ``exp`` (``_positive_scale``), or (for the Gaussian/Tobit-type scale
    parameter) ``softplus``.  Their z/p-values must be computed on the
    *displayed* scale, using a delta-method standard error — applying the
    raw-scale SE to the transformed estimate tests the wrong quantity.

    Parameters
    ----------
    raw : array-like
        Unconstrained optimisation-scale SD parameters.
    se_raw : array-like
        Standard errors of ``raw`` (raw scale).
    transform : {"exp", "softplus"}
        Which positive transform the likelihood applies.  ``"exp"`` covers
        independent SDs, Cholesky diagonals and grouped SDs in
        ``main_hpc[_lc_patch]``; ``"softplus"`` covers the ``sigma`` block.

    Returns
    -------
    (display, se_display) : tuple of np.ndarray
        ``display = g(raw)`` and ``se_display = |g'(raw)| * se_raw``
        (``g'(x) = exp(clip(x))`` for exp, ``sigmoid(x)`` for softplus).
    """
    raw = np.asarray(raw, dtype=float)
    se_raw = np.asarray(se_raw, dtype=float)
    if transform == "softplus":
        clipped = np.clip(raw, -30.0, 30.0)
        display = np.logaddexp(0.0, clipped)
        derivative = 1.0 / (1.0 + np.exp(-clipped))
    else:
        clipped = np.clip(raw, -12.0, 6.0)
        display = np.exp(clipped)
        derivative = display
    return display, derivative * se_raw


def compute_regularized_estimates(
    params,
    objective,
    param_index: dict,
    variant: str = "k3d3",
    check_multicollinearity: bool = True,
):
    """
    Apply PARTE post-MLE shrinkage to the fixed-effect coefficients,
    yielding lower-MSE estimates under multicollinearity.

    Works for ALL model types (Poisson, NB, ZINB, Gaussian, Tobit,
    latent-class, random-effects) — only the fixed-effect block (β_f)
    is modified; all other parameters are left at their MLE values.

    Algorithm (Alghamdi et al. 2026, eq 23):
        β̂_PARTE = (F + k(1+d)I)⁻¹ (F + kdI) β̂_MLE
    where F = X'WX is the Fisher information matrix at the MLE, and
    (k, d) are selected via data-adaptive rules (eqs 37-41).

    Parameters
    ----------
    params    : full MLE parameter vector (JAX or numpy array)
    objective : callable  params → negative log-likelihood  (no grad needed)
    param_index : dict from build_param_index() or build_base_index()
    variant   : "k3d3" (default, best by paper), "k1d1", or "k2d2"
    check_multicollinearity : if True, print a diagnostic warning when the
                              condition number of F exceeds 30

    Returns
    -------
    params_parte : full param vector with β_f replaced by PARTE estimate
    se_parte     : standard errors — PARTE for β_f, ridge-MLE for the rest
    parte_result : regularization.ParteResult for the fixed-effect block,
                   or None when fewer than 2 fixed effects exist
    """
    from regularization import (
        compute_regularized_estimates_jax,
        compute_regularized_estimates as _compute_np,
        multicollinearity_diagnostics,
        condition_number_jax,
        ParteResult,
        apply_parte_to_fixed_effects,
    )

    params_jax = jnp.asarray(params, dtype=float)
    # Hessian of the negative log-likelihood at the MLE — the Fisher
    # information matrix.  jax.hessian gives us this as a jnp array,
    # so we can feed it directly into the JAX-native PARTE path without
    # any numpy round-trip.  Wrapped in jit so the forward-over-forward
    # helpers compile as one executable instead of many tiny ones.
    hess_jax = jax.jit(jax.hessian(objective))(params_jax)

    # Identify fixed-effect block indices (static at JIT compile time)
    fixed_key = "fixed" if "fixed" in param_index else "beta_f"
    if fixed_key not in param_index or (param_index[fixed_key][1] - param_index[fixed_key][0]) < 2:
        # Intercept-only or no fixed effects — fall back to plain ridge SEs
        se = compute_standard_errors(params, objective)
        return params_jax, se, None

    i0, i1 = int(param_index[fixed_key][0]), int(param_index[fixed_key][1])

    if check_multicollinearity:
        # Condition number is also JAX-native (one extra eigvalsh call)
        kappa = float(condition_number_jax(hess_jax, i0, i1))
        if kappa > 1000.0:
            print(
                f"[PARTE] WARNING: severe multicollinearity "
                f"(condition number = {kappa:.1f}). "
                "PARTE shrinkage strongly recommended."
            )
        elif kappa > 30.0:
            print(
                f"[PARTE] NOTE: moderate multicollinearity "
                f"(condition number = {kappa:.1f}). "
                "PARTE shrinkage applied."
            )

    # ── JAX-native path (JIT-compiled, GPU-ready) ──────────────────────────
    params_parte_jax, se_full_jax, beta_parte_jax, k_jax, d_jax = \
        compute_regularized_estimates_jax(
            params_jax, hess_jax, i0, i1, variant
        )

    # Build a lightweight ParteResult for the caller without a numpy round-trip
    # on the main arrays (only the scalars and diagnostics need np.array()).
    beta_f_np = np.asarray(params_jax[i0:i1])
    F_np = np.asarray(hess_jax[i0:i1, i0:i1])
    q_raw, theta = np.linalg.eigh(
        np.where(np.isfinite(F_np), F_np, 0.0)
    )
    parte_result = ParteResult(
        beta_mle=beta_f_np,
        beta_parte=np.asarray(beta_parte_jax),
        k=float(k_jax),
        d=float(d_jax),
        se_mle=np.asarray(se_full_jax[i0:i1]),   # ridge-MLE SE for the block
        se_parte=np.asarray(se_full_jax[i0:i1]),  # these are PARTE SEs
        condition_number=float(np.maximum(q_raw, 1e-12)[-1] /
                               float(max(np.maximum(q_raw, 1e-12)[0], 1e-12))),
        eigenvalues=q_raw,
        alpha=theta.T @ beta_f_np,
        variant=variant,
    )

    return params_parte_jax, se_full_jax, parte_result

def build_cholesky_from_params(chol_params, K):
    L = np.zeros((K, K))
    idx = 0
    for i in range(K):
        for j in range(i + 1):
            L[i, j] = chol_params[idx]
            idx += 1
    return L
'''
def print_summary(result, objective, data, spec, param_index):

    params = result.params
    se = compute_standard_errors(params, objective)

    z_vals = params / se
    p_vals = 2 * (1 - stats.norm.cdf(jnp.abs(z_vals)))

    # Log-likelihood
    final_ll = -objective(params)
    k = len(params)
    n = data["y"].shape[0]

    aic = 2*k - 2*final_ll
    bic = k * jnp.log(n) - 2*final_ll

    # Build parameter names
    names = []

    # Fixed
    for name in spec.fixed_names:
        names.append(name)

    # Correlated
    for name in spec.random_cor_names:
        names.append(f"cor_mean({name})")

    if spec.Kr_cor > 0:
        corr_cols = spec.correlated_cols
        K = spec.Kr_cor

        for i in range(K):
            for j in range(i + 1):
                names.append(f"chol({corr_cols[i]},{corr_cols[j]})")

    # Independent
    for name in spec.random_ind_names:
        names.append(f"mean({name})")
    for name in spec.random_ind_names:
        names.append(f"sd({name})")

    # Grouped
    if spec.Kg > 0:
        for name in spec.grouped_names:
            names.append(f"group_mean({name})")
        for name in spec.grouped_names:
            names.append(f"group_sd({name})")

    # Heterogeneity
    if spec.Kh > 0:
        for rnd in spec.random_cor_names + spec.random_ind_names:
            for z in spec.hetro_names:
                names.append(f"hetro({rnd}|{z})")

    # NB dispersion / Tobit-Gaussian scale
    if spec.model in {"nb", "nb1"}:
        names.append("dispersion")
    elif spec.model in {"lognormal", "gaussian", "tobit", "weibull", "loglogistic", "weibull_ph"}:
        names.append("sigma")

    summary_df = pd.DataFrame({
        "Parameter": names,
        "Estimate": np.array(params),
        "Std.Err": np.array(se),
        "z-value": np.array(z_vals),
        "p-value": np.array(p_vals)
    })

    print("\n================ MODEL SUMMARY ================")
    print(summary_df.to_string(index=False))
    print("------------------------------------------------")
    print(f"Log-Likelihood: {float(final_ll):.4f}")
    print(f"AIC: {float(aic):.4f}")
    print(f"BIC: {float(bic):.4f}")
    print("================================================\n")
    
'''

from sklearn.model_selection import train_test_split


def prepare_panel_summary(df, id_col, y_col):

    panel_df = (
        df.groupby(id_col)[y_col]
        .agg(["mean", "sum"])
        .reset_index()
    )

    return panel_df

def prepare_panel_summary(df, id_col, y_col):

    panel_df = (
        df.groupby(id_col)[y_col]
        .agg(["mean", "sum"])
        .reset_index()
    )

    return panel_df

from sklearn.model_selection import train_test_split

def stratified_panel_split(panel_df, train_size=0.6, test_size=0.2, val_size=0.2, seed=42):

    assert abs(train_size + test_size + val_size - 1) < 1e-8

    # First split train vs temp
    train_panels, temp_panels = train_test_split(
        panel_df,
        test_size=(1 - train_size),
        stratify=panel_df["strata"],
        random_state=seed
    )

    # Split temp into test and val
    relative_test = test_size / (test_size + val_size)

    test_panels, val_panels = train_test_split(
        temp_panels,
        test_size=(1 - relative_test),
        stratify=temp_panels["strata"],
        random_state=seed
    )

    return train_panels, test_panels, val_panels


def create_strata(panel_df, col="mean", n_bins=5):

    panel_df["strata"] = pd.qcut(
        panel_df[col],
        q=n_bins,
        duplicates="drop"
    )

    return panel_df


def evaluate_predictions(params, data, spec, name):

    mu = compute_predictions(params, data, spec)
    mu_mean = np.array(mu.mean(axis=-1))  # average over draws

    y_true = np.array(data["y"]).squeeze()

    rmse = np.sqrt(np.mean((mu_mean - y_true) ** 2))
    mae = np.mean(np.abs(mu_mean - y_true))

    print(f"\n{name} RMSE: {rmse:.4f}")
    print(f"{name} MAE: {mae:.4f}")

def build_datasets(df, id_col, y_col):

    panel_df = prepare_panel_summary(df, id_col, y_col)
    panel_df = create_strata(panel_df)

    train_panels, test_panels, val_panels = stratified_panel_split(panel_df)

    train_ids = train_panels[id_col]
    test_ids = test_panels[id_col]
    val_ids = val_panels[id_col]

    df_train = df[df[id_col].isin(train_ids)]
    df_test = df[df[id_col].isin(test_ids)]
    df_val = df[df[id_col].isin(val_ids)]

    return df_train, df_test, df_val


def create_strata(panel_df, col="mean", n_bins=5):

    panel_df["strata"] = pd.qcut(
        panel_df[col],
        q=n_bins,
        duplicates="drop"
    )

    return panel_df

def split_data(df, train_size=0.6, test_size=0.2, val_size=0.2, seed=42):

    assert abs(train_size + test_size + val_size - 1.0) < 1e-8

    # First split: train vs temp
    df_train, df_temp = train_test_split(
        df,
        test_size=(1 - train_size),
        random_state=seed
    )

    # Second split: test vs validation
    relative_test_size = test_size / (test_size + val_size)

    df_test, df_val = train_test_split(
        df_temp,
        test_size=(1 - relative_test_size),
        random_state=seed
    )

    return df_train, df_test, df_val


'''
def get_operator(algo, config_id, evaluator, dimension):

    config = ALL_CONFIGS[algo][config_id]

    if algo == "de":

        operator = AdaptiveDE(
            evaluator=evaluator,
            dimension=dimension,
            **config
        )

    elif algo == "hs":

        operator = DynamicHarmony(
            evaluator=evaluator,
            dimension=dimension,
            **config
        )

    elif algo == "sa":

        operator = MultiStartSA(
            evaluator=evaluator,
            dimension=dimension,
            n_starts=config["n_starts"],
            mutation_rate=config["mutation_rate"],
            step_size=config["step_size"],
            alpha=config["alpha"],
        )

    return operator, config
'''


def generate_configs(param_grid):

    keys = param_grid.keys()
    values = param_grid.values()

    configs = []

    for combination in itertools.product(*values):
        config = dict(zip(keys, combination))
        configs.append(config)

    return configs


class DummyResult:
    def __init__(self, params):
        self.params = params

def print_summary(result, objective, data, spec, param_index):

    import numpy as np
    import pandas as pd
    from scipy import stats
    
    if spec.latent_classes > 1:

        C = spec.latent_classes

        base_spec = replace(spec, latent_classes=1)
        base_index = build_base_index(base_spec)
        K_base = base_index["total_params"]

        params = np.asarray(result.params)

        theta_all = params[:C * K_base].reshape(C, K_base)

        logits = params[C * K_base:]
        logits_full = np.concatenate(([0.0], logits))
        pi = np.exp(logits_full - np.max(logits_full))
        pi /= pi.sum()

        print("\n====================================================")
        print("        LATENT CLASS MIXED MODEL SUMMARY")
        print("====================================================")

        # ---------------------------------------------
        # Print each class separately
        # ---------------------------------------------
        for c in range(C):

            print(f"\n################ CLASS {c+1} ################\n")

            class_result = DummyResult(theta_all[c])
            class_result.params = theta_all[c]

            print_summary(
                result=class_result,
                objective=None,
                data=data,
                spec=base_spec,
                param_index=base_index
            )

        # ---------------------------------------------
        # Print class probabilities
        # ---------------------------------------------
        print("\n================ CLASS PROBABILITIES ================\n")

        for c in range(C):
            print(f"pi_{c+1}: {pi[c]:.6f}")

        print("\n====================================================\n")

        return
    

    params = result.params
    k = len(params)
    n = data["y"].shape[0]

    # ── MLE log-likelihood (upper bound — always reported) ────────────────
    mle_ll = float(-objective(params))

    # ── PARTE regularisation ──────────────────────────────────────────────
    # Apply PARTE shrinkage when a valid param_index is supplied.  The
    # corrected LL (evaluated at PARTE parameters) is always lower than the
    # MLE LL because the MLE maximises the likelihood, but it reflects the
    # actual goodness-of-fit of the parameter vector used for inference and
    # prediction.  AIC / BIC are computed from the corrected LL.
    parte_applied = False
    params_eval = params                    # params used for display & IC
    se_eval      = None

    if objective is not None and param_index is not None:
        try:
            params_parte_j, se_parte_j, parte_result = compute_regularized_estimates(
                params, objective, param_index,
                variant="k3d3", check_multicollinearity=True,
            )
            corrected_ll = float(-objective(params_parte_j))
            params_eval  = np.asarray(params_parte_j)
            se_eval      = np.asarray(se_parte_j)
            parte_applied = True
        except Exception as _e:
            corrected_ll = mle_ll           # fall back silently

    if not parte_applied:
        corrected_ll = mle_ll
        se_eval = np.asarray(compute_standard_errors(params, objective))
        params_eval = np.asarray(params)

    # ICs use the corrected LL so that model comparison reflects the
    # parameter vector that is actually used.
    eval_ll = corrected_ll
    aic = 2*k - 2*eval_ll
    bic = k * np.log(n) - 2*eval_ll

    # z / p for the displayed (PARTE) estimates
    se_eval_safe = np.where(se_eval > 1e-12, se_eval, np.nan)
    z_vals = params_eval / se_eval_safe
    p_vals = 2 * (1 - stats.norm.cdf(np.abs(z_vals)))

    names = []

    # ==============================
    # BUILD PARAMETER NAME LIST
    # ==============================

    # Fixed (Intercept first)
    #names.append("Intercept")
    
    # Fixed
    for name in spec.fixed_names:
        names.append(name)

    # Zero Inflation
    if spec.Kzi > 0:
        for name in spec.zi_names:
            names.append(f"zi({name})")
    
    # Correlated means
    for name in spec.random_cor_names:
        names.append(f"cor_mean({name})")

    # Correlated Cholesky (store but we won't print later)
    chol_names = []
    if spec.Kr_cor > 0:
        corr_cols = spec.random_cor_names
        K = spec.Kr_cor
        for i in range(K):
            for j in range(i + 1):
                nm = f"chol({corr_cols[i]},{corr_cols[j]})"
                names.append(nm)
                chol_names.append(nm)

    # Independent
    for name in spec.random_ind_names:
        names.append(f"mean({name})")
    for name in spec.random_ind_names:
        names.append(f"sd({name})")

    # Grouped
    if spec.Kg > 0:
        for name in spec.grouped_names:
            names.append(f"group_mean({name})")
        for name in spec.grouped_names:
            names.append(f"group_sd({name})")

    # Heterogeneity
    if spec.Kh > 0:
        for rnd in spec.random_cor_names + spec.random_ind_names:
            for z in spec.hetro_names:
                names.append(f"hetro({rnd}|{z})")

    # NB dispersion / Tobit-Gaussian scale
    if spec.model in {"nb", "nb1"}:
        names.append("dispersion")
    elif spec.model in {"lognormal", "gaussian", "tobit", "weibull", "loglogistic", "weibull_ph"}:
        names.append("sigma")

    params_mle_np = np.asarray(params)
    df_cols = {
        "Parameter":        names,
        "Estimate (MLE)":   params_mle_np,
        "Estimate":         params_eval,   # PARTE when applied, otherwise MLE
        "Std.Err":          se_eval,
        "z-value":          z_vals,
        "p-value":          p_vals,
    }
    if parte_applied:
        # Show the shrinkage so the user can see which params moved
        df_cols["Shrinkage"] = params_eval - params_mle_np
    summary_df = pd.DataFrame(df_cols)

    # ==========================================================
    # PRINT CLEAN SECTIONS
    # ==========================================================

    def print_section(df, title):
        if len(df) == 0:
            return
        print(f"\n================ {title} ================\n")
        print(df.to_string(index=False))

    # Remove raw chol from main table
    main_df = summary_df[~summary_df["Parameter"].isin(chol_names)]

    # Split sections
    fixed_df = main_df[
        main_df["Parameter"].isin(spec.fixed_names)
    ]
    
    zi_df = main_df[
    main_df["Parameter"].str.contains("zi\\(")
]

    cor_mean_df = main_df[
        main_df["Parameter"].str.contains("cor_mean")
    ]

    ind_df = main_df[
        main_df["Parameter"].str.contains("mean\\(") &
        ~main_df["Parameter"].str.contains("cor_mean") &
        ~main_df["Parameter"].str.contains("group")
    ]

    sd_df = main_df[
        main_df["Parameter"].str.contains("sd\\(") &
        ~main_df["Parameter"].str.contains("group")
    ]

    group_df = main_df[
        main_df["Parameter"].str.contains("group_")
    ]

    het_df = main_df[
        main_df["Parameter"].str.contains("hetro")
    ]

    het_var_df = main_df[
        main_df["Parameter"].str.contains("hetro_var")
    ]

    disp_df = main_df[
        main_df["Parameter"] == "dispersion"
    ]

    print("\n================ MODEL SUMMARY ================")

    print_section(fixed_df, "FIXED EFFECTS")
    print_section(zi_df, "ZERO INFLATION")
    print_section(cor_mean_df, "CORRELATED RANDOM MEANS")
    print_section(ind_df, "INDEPENDENT RANDOM MEANS")
    print_section(sd_df, "INDEPENDENT RANDOM SDs")
    print_section(group_df, "GROUPED RANDOM EFFECTS")
    print_section(het_df, "HETEROGENEITY IN MEANS")
    print_section(het_var_df, "HETEROGENEITY IN VARIANCES")
    print_section(disp_df, "DISPERSION")

    # ==========================================================
    # COMPUTE & PRINT VAR-COV MATRIX FROM CHOLESKY
    # ==========================================================

    if spec.Kr_cor > 0:

        # Extract chol parameters
        chol_params = summary_df[
            summary_df["Parameter"].isin(chol_names)
        ]["Estimate"].values

        # Rebuild L
        K = spec.Kr_cor
        L = np.zeros((K, K))
        idx = 0
        for i in range(K):
            for j in range(i + 1):
                L[i, j] = chol_params[idx]
                idx += 1

        Sigma = L @ L.T
        std = np.sqrt(np.diag(Sigma))
        Corr = Sigma / np.outer(std, std)

        cols = spec.random_cor_names

        print("\n================ CORRELATED RANDOM VAR-COV ================\n")

        for i in range(K):
            print(f"Var({cols[i]}) = {Sigma[i,i]:.6f}")

        for i in range(K):
            for j in range(i):
                print(f"Cov({cols[i]},{cols[j]}) = {Sigma[i,j]:.6f}")

        print("\n================ CORRELATION MATRIX ================\n")

        for i in range(K):
            for j in range(i):
                print(f"Corr({cols[i]},{cols[j]}) = {Corr[i,j]:.6f}")

    print("\n------------------------------------------------")
    print(f"Log-Likelihood (MLE):              {mle_ll:>14.4f}")
    if parte_applied:
        ll_cost = corrected_ll - mle_ll     # always ≤ 0
        print(f"Log-Likelihood (PARTE-corrected):  {corrected_ll:>14.4f}"
              f"  [d = {ll_cost:+.4f} vs MLE]")
        print(f"  (k = {parte_result.k:.4f},  d = {parte_result.d:.4f},"
              f"  cond = {parte_result.condition_number:.1f})")
        print(f"AIC  (PARTE LL): {float(aic):>14.4f}")
        print(f"BIC  (PARTE LL): {float(bic):>14.4f}")
    else:
        print(f"AIC: {float(aic):>14.4f}")
        print(f"BIC: {float(bic):>14.4f}")
    print("================================================\n")







def generate_panel_data(N_ids=1000, T=4, seed=0):

    import numpy as np
    import pandas as pd
    from scipy.stats import multivariate_normal

    np.random.seed(seed)

    # -----------------------------
    # TRUE PARAMETERS
    # -----------------------------

    beta_0 = -2.5
    beta_shoulder = -0.3
    beta_aadt = 0.4
    beta_length = 0.2

    mu_speed = 0.05
    mu_lanes = 0.2

    sd_speed = 0.03
    sd_lanes = 0.1
    rho = -0.5

    alpha_true = 1.0

    Sigma = np.array([
        [sd_speed**2, rho*sd_speed*sd_lanes],
        [rho*sd_speed*sd_lanes, sd_lanes**2]
    ])

    # -----------------------------
    # RANDOM COEFFICIENTS (ONE PER ID)
    # -----------------------------

    betas = multivariate_normal.rvs(
        mean=[mu_speed, mu_lanes],
        cov=Sigma,
        size=N_ids
    )

    beta_speed_i = betas[:,0]
    beta_lanes_i = betas[:,1]

    # -----------------------------
    # BUILD PANEL
    # -----------------------------

    rows = []

    for i in range(N_ids):
        speed = np.random.uniform(30, 80)
        lanes = np.random.choice([2,3,4])
        shoulder = np.random.uniform(0, 10)
        length = np.random.uniform(0.5, 5)
        aadt = np.random.lognormal(mean=9, sigma=0.6)
        rural = np.random.binomial(1, 0.6)
        curves = np.random.choice([0, 0, 1, 2])
        slope = np.random.choice([0, 0,0,0, 0, 1, 1, 1, 2, 2, 3])
        insig_3 = np.sqrt(np.random.uniform(0, 50))
        insig_4 = np.random.triangular(0, 4, 8)
        for t in range(T):

            
            
            # Dummy example
            
            eta = (
                beta_0
                + beta_shoulder * shoulder
                + beta_aadt * np.log(aadt)
                + beta_length * length
                + beta_speed_i[i] * speed
                + beta_lanes_i[i] * lanes
            )

            mu = np.exp(eta)
            p = mu / (mu + alpha_true)

            y = np.random.negative_binomial(alpha_true, 1 - p)

            rows.append([
                i, y, speed, lanes, shoulder,
                np.log(aadt), length, rural, curves, slope, insig_3, insig_4
            ])

    df = pd.DataFrame(rows, columns=[
        "ID","Y","speed","lanes","shoulder", 
        "log_aadt","length",'rural', 'curves', 'slope', 'insig_1', 'insig_2'
    ])
    true_params = {
        "__INTERCEPT__": beta_0,
        "shoulder": beta_shoulder,
        "log_aadt": beta_aadt,
        "length": beta_length,
        "cor_mean(speed)": mu_speed,
        "cor_mean(lanes)": mu_lanes,
        "sd(speed)": sd_speed,
        "sd(lanes)": sd_lanes,
        "corr(speed,lanes)": rho,
        "dispersion": alpha_true
    }
    

    return df, true_params



def multi_start_estimation(model, n_starts=10, seed=0):

    import jax.numpy as jnp
    from jaxopt import LBFGS

    rng = np.random.default_rng(seed)
    best_ll = np.inf
    best_result = None
    start_reports = []
    scale_levels = (-2.5, -1.0, 0.0, 0.7)

    for s in range(n_starts):
        init = 0.05 * rng.standard_normal(model.param_index["total_params"])
        scale_level = scale_levels[s % len(scale_levels)]
        for pair in _random_mean_scale_pairs(model.spec, model.param_index):
            init[pair["scale_index"]] = scale_level + 0.1 * rng.standard_normal()

        solver = LBFGS(
            fun=model.objective,
            maxiter=2000
        )

        result = solver.run(jnp.asarray(init, dtype=float))

        ll = float(result.state.value)
        diagnostic = random_parameter_convergence_diagnostics(
            result.params,
            model.objective,
            model.spec,
            model.param_index,
            include_hessian=False,
        )
        finite = bool(np.isfinite(ll) and not diagnostic["warnings"]
                      or np.isfinite(ll) and diagnostic["stationary"])
        start_reports.append({
            "start": s,
            "log_sd_start": scale_level,
            "objective": ll,
            "finite": finite,
            "stationary": diagnostic["stationary"],
            "relative_gradient": diagnostic["relative_gradient"],
        })

        print(
            f"Start {s}: objective = {ll:.4f} "
            f"(log-SD start={scale_level:.2f}, "
            f"relative gradient={diagnostic['relative_gradient']:.2e})"
        )

        if finite and ll < best_ll:
            best_ll = ll
            best_result = result

    model.last_multistart_report = start_reports
    if best_result is None:
        raise RuntimeError("All random-parameter starts produced invalid fits")

    print("\nBest objective:", best_ll)

    return best_result



def monte_carlo_recovery(
    n_rep=1,
    N_ids=1000,
    T=4,
    R=200,
    n_starts=1
):

    import numpy as np
    import pandas as pd
    from functools import partial

    all_results = []

    for r in range(n_rep):

        print(f"\n====== Replication {r} ======")

        # --------------------------------------------------
        # 1️⃣ Generate panel data + true parameters
        # --------------------------------------------------

        df, true_params = generate_panel_data(
            N_ids=N_ids,
            T=T,
            seed=r
        )

        # --------------------------------------------------
        # 2️⃣ Manual model specification
        # --------------------------------------------------

        manual_spec = {
            "fixed_terms": [
                "shoulder",
                "log_aadt",
                "length",
                "rural"
            ],
            "rdm_terms": [],
            "rdm_cor_terms": [
                "speed:normal",
                "lanes:normal"
            ],
            "grouped_terms": [],
            "hetro_in_means": [],
            "zi_terms": [],
            "dispersion": 1
        }

        # --------------------------------------------------
        # 3️⃣ Generate Halton draws (PER ID)
        # --------------------------------------------------

        draws_cor = generate_halton_normal(
            N=N_ids,
            K=2,
            R=R,
            seed=r
        )

        # --------------------------------------------------
        # 4️⃣ Build model
        # --------------------------------------------------

        data, spec = build_model_from_manual_spec(
            df=df,
            manual_spec=manual_spec,
            id_col="ID",
            y_col="Y",
            offset_col=None,
            draws_cor=draws_cor,
            R=R
        )

        # Force NB
        spec = replace(spec, model="nb")

        model = CountModel(spec, data)

        # --------------------------------------------------
        # 5️⃣ Multi-start estimation
        # --------------------------------------------------

        result = multi_start_estimation(
            model,
            n_starts=n_starts,
            seed=r
        )

        # --------------------------------------------------
        # 6️⃣ Extract estimates
        # --------------------------------------------------

        objective = partial(mixed_model_loglik,
                            data=data,
                            spec=spec)

        param_index = build_param_index(spec)

        summary_df = print_summary(
            result=result,
            objective=objective,
            data=data,
            spec=spec,
            param_index=param_index,
            return_df=True   # <-- modify your function to allow this
        )

        est = dict(zip(summary_df["Parameter"],
                       summary_df["Estimate"]))

        # --------------------------------------------------
        # 7️⃣ Store recovery results
        # --------------------------------------------------

        for k in true_params:

            if k in est:

                all_results.append({
                    "rep": r,
                    "param": k,
                    "true": true_params[k],
                    "est": est[k]
                })

    # ======================================================
    # 8️⃣ Compute Monte Carlo bias + RMSE
    # ======================================================

    results_df = pd.DataFrame(all_results)

    summary = (
        results_df
        .groupby("param")
        .apply(lambda x: pd.Series({
            "True": x["true"].iloc[0],
            "Mean_Est": x["est"].mean(),
            "Bias": x["est"].mean() - x["true"].iloc[0],
            "RMSE": np.sqrt(np.mean((x["est"] - x["true"])**2))
        }))
    )

    print("\n\n========= MONTE CARLO SUMMARY =========\n")
    print(summary)

    return summary



def run_full_synthetic_recovery_experiment(R=300, seed=42):

    print("\n==============================")
    print("RUNNING FULL SYNTHETIC RECOVERY TEST")
    print("==============================\n")

    
    import numpy as np
    import pandas as pd
    from scipy.stats import multivariate_normal

    np.random.seed(seed)

    print("\n==============================")
    print("MINIMAL CORRELATED RANDOM TEST")
    print("==============================\n")

    # -------------------------------------------------
    # TRUE PARAMETERS
    # -------------------------------------------------

    N = 3000

    beta_0 = -2.0
    beta_shoulder = -0.3

    mu_speed = 0.05
    mu_lanes = 0.2

    sd_speed = 0.03
    sd_lanes = 0.1
    rho = -0.5

    alpha_true = 1.0  # NB dispersion

    Sigma = np.array([
        [sd_speed**2, rho*sd_speed*sd_lanes],
        [rho*sd_speed*sd_lanes, sd_lanes**2]
    ])

    # -------------------------------------------------
    # DATA
    # -------------------------------------------------

    speed = np.random.uniform(30, 80, N)
    lanes = np.random.choice([2,3,4], N)
    shoulder = np.random.uniform(0, 10, N)
    shoulder = np.random.uniform(0, 10, N)

    betas = multivariate_normal.rvs(
        mean=[mu_speed, mu_lanes],
        cov=Sigma,
        size=N
    )

    beta_speed = betas[:,0]
    beta_lanes = betas[:,1]

    eta = (
        beta_0 +
        beta_shoulder * shoulder +
        beta_speed * speed +
        beta_lanes * lanes
    )

    mu = np.exp(eta)

    p = mu / (mu + alpha_true)
    y = np.random.negative_binomial(alpha_true, 1 - p)

    df = pd.DataFrame({
        "ID": np.arange(N),
        "Y": y,
        "speed": speed,
        "lanes": lanes,
        "shoulder": shoulder
    })
    df.to_csv('data/meta_synth_multi.csv')
    # -------------------------------------------------
    # SPEC (MINIMAL)
    # -------------------------------------------------

    manual_spec = {
        "fixed_terms": ["shoulder"],
        "rdm_terms": [],
        "rdm_cor_terms": [
            "speed:normal",
            "lanes:normal"
        ],
        "grouped_terms": [],
        "hetro_in_means": [],
        "zi_terms": [],
        "dispersion": 1
    }

    draws_cor = generate_halton_normal(
        N=N,
        K=2,
        R=R,
        seed=seed
    )

    data, spec = build_model_from_manual_spec(
        df=df,
        manual_spec=manual_spec,
        id_col="ID",
        y_col="Y",
        draws_cor=draws_cor,
        R=R
    )

    spec = replace(spec, model="nb")

    # -------------------------------------------------
    # FIT
    # -------------------------------------------------

    model = CountModel(spec, data)

    # IMPORTANT: random init, not zeros
    key = jax.random.PRNGKey(seed)
    init = 0.01 * jax.random.normal(
        key,
        (model.param_index["total_params"],)
    )

    solver = LBFGS(fun=model.objective, maxiter=2000)
    result = solver.run(init)

    objective = partial(mixed_model_loglik, data=data, spec=spec)
    param_index = build_param_index(spec)

    print_summary(
        result=result,
        objective=objective,
        data=data,
        spec=spec,
        param_index=param_index
    )

    print("\n================ TRUE VALUES ================\n")
    print("Intercept:", beta_0)
    print("Shoulder:", beta_shoulder)
    print("Mean Speed:", mu_speed)
    print("Mean Lanes:", mu_lanes)
    print("SD Speed:", sd_speed)
    print("SD Lanes:", sd_lanes)
    print("Correlation:", rho)
    print("Dispersion:", alpha_true)
    
    



def estimate_latent_class_mixed_example():

    from functools import partial
    from dataclasses import replace
    import numpy as np

    print("\n==============================================")
    print(" ESTIMATING 2-CLASS MIXED NEGATIVE BINOMIAL (EM)")
    print("==============================================\n")

    # --------------------------------------------------
    # 1️⃣ Generate synthetic panel data
    # --------------------------------------------------

    df, _ = generate_panel_data(
        N_ids=800,
        T=3,
        seed=0
    )

    # --------------------------------------------------
    # 2️⃣ Model specification
    # --------------------------------------------------

    manual_spec = {
        "fixed_terms": ["shoulder", "log_aadt", "length"],
        "rdm_terms": [],
        "rdm_cor_terms": [
            "speed:normal",
            "lanes:normal"
        ],
        "grouped_terms": [],
        "hetro_in_means": [],
        "zi_terms": [],
        "dispersion": 1
    }

    # --------------------------------------------------
    # 3️⃣ Halton draws
    # --------------------------------------------------

    draws_cor = generate_halton_normal(
        N=df["ID"].nunique(),
        K=2,
        R=200,
        seed=0
    )

    # --------------------------------------------------
    # 4️⃣ Build data + spec
    # --------------------------------------------------

    data, spec = build_model_from_manual_spec(
        df=df,
        manual_spec=manual_spec,
        id_col="ID",
        y_col="Y",
        draws_cor=draws_cor,
        R=200
    )

    spec = replace(spec, model="nb", latent_classes=2)

    # --------------------------------------------------
    # 5️⃣ Build parameter structure
    # --------------------------------------------------

    base_spec = replace(spec, latent_classes=1)
    base_index = build_param_index(base_spec)
    K_base = base_index["total_params"]

    C = spec.latent_classes

    print("Parameters per class:", K_base)
    print("Total parameters (EM structure):", C * K_base + (C - 1))

    # --------------------------------------------------
    # 6️⃣ INITIALIZATION
    # --------------------------------------------------

    print("\n🔹 Estimating pooled single-class model for initialization...\n")

    # Estimate single class first
    model_single = CountModel(base_spec, data)
    result_single = model_single.fit()

    theta_single = result_single.params

    # Create two slightly perturbed classes
    theta_init = np.concatenate([
        theta_single,
        theta_single + np.random.normal(0, 0.05, size=K_base)
    ])

    logits_init = np.zeros(C - 1)  # equal class shares

    init_params = np.concatenate([theta_init, logits_init])

    # --------------------------------------------------
    # 7️⃣ EM ESTIMATION
    # --------------------------------------------------

    print("\n🚀 Running EM algorithm...\n")

    params_em = fit_em(
        init_params=init_params,
        data=data,
        spec=spec,
        max_iter=50,
        tol=1e-5,
        verbose=True
    )

    print("\n✅ EM Estimation complete.\n")

    # --------------------------------------------------
    # 8️⃣ OPTIONAL: Full MLE polish
    # --------------------------------------------------

    print("🔹 Polishing with full MLE...\n")

    from jaxopt import ScipyMinimize as JaxoptMinimize

    _polish_fn = lambda p: _call_loglik(p, data, spec)
    _polish_solver = JaxoptMinimize(fun=_polish_fn, method="SLSQP", tol=1e-8, maxiter=3000)
    result_final = _polish_solver.run(jnp.array(params_em, dtype=jnp.float64))

    print("Final log-likelihood:", -float(_polish_fn(result_final.params)))

    # --------------------------------------------------
    # 9️⃣ Print summary
    # --------------------------------------------------

    objective = partial(mixed_model_loglik, data=data, spec=spec)

    print_summary(
        result=result_final,
        objective=objective,
        data=data,
        spec=spec,
        param_index=build_param_index(spec)
    )




def print_summary(result, objective, data, spec, param_index):

    import numpy as np
    import pandas as pd
    from scipy import stats

    def positive_scale(x):
        return np.exp(np.clip(x, -12.0, 6.0))

    params = np.array(result.params)
    se = np.array(compute_standard_errors(result.params, objective))

    z_vals = params / se
    p_vals = 2 * (1 - stats.norm.cdf(np.abs(z_vals)))

    final_ll = -objective(result.params)
    k = len(params)
    n = data["y"].shape[0]

    aic = 2*k - 2*final_ll
    bic = k * np.log(n) - 2*final_ll

    names = []

    # ==============================
    # BUILD PARAMETER NAME LIST
    # ==============================

    # Fixed
    for name in spec.fixed_names:
        names.append(name)

    # Zero inflation
    if spec.Kzi > 0:
        for name in spec.zi_names:
            names.append(f"zi({name})")

    # Correlated means
    for name in spec.random_cor_names:
        names.append(f"cor_mean({name})")

    # Correlated Cholesky
    chol_names = []
    if spec.Kr_cor > 0:
        cols = spec.random_cor_names
        K = spec.Kr_cor
        for i in range(K):
            for j in range(i + 1):
                nm = f"chol({cols[i]},{cols[j]})"
                names.append(nm)
                chol_names.append(nm)

    # Independent
    for name in spec.random_ind_names:
        names.append(f"mean({name})")
    for name in spec.random_ind_names:
        names.append(f"sd({name})")

    # Grouped
    if spec.Kg > 0:
        for name in spec.grouped_names:
            names.append(f"group_mean({name})")
        for name in spec.grouped_names:
            names.append(f"group_sd({name})")

    # Heterogeneity
    if spec.Kh > 0:
        for rnd in spec.random_cor_names + spec.random_ind_names:
            for z in spec.hetro_names:
                names.append(f"hetro({rnd}|{z})")

    # Heterogeneity in VARIANCES
    if spec.Kv > 0:
        for rnd in spec.random_cor_names + spec.random_ind_names + spec.grouped_names:
            for z in spec.hetro_var_names:
                names.append(f"hetro_var({rnd}|{z})")

    # Heterogeneity in MEANS of grouped coefficients
    if spec.Kh > 0 and spec.Kg > 0:
        for rnd in spec.grouped_names:
            for z in spec.hetro_names:
                names.append(f"hetro_group({rnd}|{z})")

    # GSE gradient-score loadings
    if getattr(spec, "Kgse", 0) > 0:
        for rnd in spec.random_cor_names + spec.random_ind_names:
            names.append(f"gse({rnd})")

    # NB dispersion / Tobit-Gaussian scale
    if spec.model in {"nb", "nb1"}:
        names.append("dispersion")
    elif spec.model in {"lognormal", "gaussian", "tobit", "weibull", "loglogistic", "weibull_ph"}:
        names.append("sigma")

    summary_df = pd.DataFrame({
        "Parameter": names,
        "Estimate": params,
        "Std.Err": se,
        "z-value": z_vals,
        "p-value": p_vals
    })

    # ==========================================================
    # ✅ TRANSFORM PARAMETERS TO TRUE SCALE
    # ==========================================================

    # Independent SDs
    sd_mask = summary_df["Parameter"].str.contains(r"^sd\(")
    summary_df.loc[sd_mask, "Estimate"] = positive_scale(
        summary_df.loc[sd_mask, "Estimate"]
    )

    # Grouped SDs
    gsd_mask = summary_df["Parameter"].str.contains("group_sd")
    summary_df.loc[gsd_mask, "Estimate"] = positive_scale(
        summary_df.loc[gsd_mask, "Estimate"]
    )

    # NB dispersion
    if spec.model in {"nb", "nb1"}:
        disp_mask = summary_df["Parameter"] == "dispersion"
        summary_df.loc[disp_mask, "Estimate"] = np.exp(
            np.clip(summary_df.loc[disp_mask, "Estimate"], -12.0, 12.0)
        )

    # ==========================================================
    # PRINT SECTIONS
    # ==========================================================

    def print_section(df, title):
        if len(df) == 0:
            return
        print(f"\n================ {title} ================\n")
        print(df.to_string(index=False))

    # Remove raw chol from main display
    main_df = summary_df[~summary_df["Parameter"].isin(chol_names)]

    fixed_df = main_df[
        main_df["Parameter"].isin(spec.fixed_names)
    ]

    zi_df = main_df[
        main_df["Parameter"].str.contains("zi\\(")
    ]

    cor_mean_df = main_df[
        main_df["Parameter"].str.contains("cor_mean")
    ]

    ind_mean_df = main_df[
        main_df["Parameter"].str.contains("mean\\(") &
        ~main_df["Parameter"].str.contains("cor_mean") &
        ~main_df["Parameter"].str.contains("group")
    ]

    sd_df = main_df[
        main_df["Parameter"].str.contains("sd\\(") &
        ~main_df["Parameter"].str.contains("group")
    ]

    group_df = main_df[
        main_df["Parameter"].str.contains("group_")
    ]

    het_df = main_df[
        main_df["Parameter"].str.contains("hetro")
    ]

    het_var_df = main_df[
        main_df["Parameter"].str.contains("hetro_var")
    ]

    disp_df = main_df[
        main_df["Parameter"] == "dispersion"
    ]

    print("\n================ MODEL SUMMARY ================\n")

    print_section(fixed_df, "FIXED EFFECTS")
    print_section(zi_df, "ZERO INFLATION")
    print_section(cor_mean_df, "CORRELATED RANDOM MEANS")
    print_section(ind_mean_df, "INDEPENDENT RANDOM MEANS")
    print_section(sd_df, "INDEPENDENT RANDOM SDs")
    print_section(group_df, "GROUPED RANDOM EFFECTS")
    print_section(het_df, "HETEROGENEITY IN MEANS")
    print_section(het_var_df, "HETEROGENEITY IN VARIANCES")
    print_section(disp_df, "DISPERSION")

    # ==========================================================
    # ✅ REBUILD TRUE VAR-COV FROM CHOLESKY
    # ==========================================================

    if spec.Kr_cor > 0:

        chol_params = params[
            summary_df["Parameter"].isin(chol_names)
        ]

        K = spec.Kr_cor
        L = np.zeros((K, K))

        idx = 0
        for i in range(K):
            for j in range(i + 1):
                val = chol_params[idx]

                # ✅ exponentiate diagonal
                if i == j:
                    val = np.exp(val)

                L[i, j] = val
                idx += 1

        Sigma = L @ L.T
        std = np.sqrt(np.diag(Sigma))
        Corr = Sigma / np.outer(std, std)

        cols = spec.random_cor_names

        print("\n================ CORRELATED RANDOM VAR-COV ================\n")

        for i in range(K):
            print(f"Var({cols[i]}) = {Sigma[i,i]:.6f}")

        for i in range(K):
            for j in range(i):
                print(f"Cov({cols[i]},{cols[j]}) = {Sigma[i,j]:.6f}")

        print("\n================ CORRELATION MATRIX ================\n")

        for i in range(K):
            for j in range(i):
                print(f"Corr({cols[i]},{cols[j]}) = {Corr[i,j]:.6f}")

    print("\n------------------------------------------------")
    print(f"Log-Likelihood: {float(final_ll):.4f}")
    print(f"AIC: {float(aic):.4f}")
    print(f"BIC: {float(bic):.4f}")
    print("================================================\n")


def print_summary(result, objective, data, spec, param_index, se = None, return_df = None):

    import numpy as np
    import pandas as pd
    from scipy import stats
    
    import numpy as np
    import pandas as pd
    from scipy import stats
    
    if spec.latent_classes > 1:

        C = spec.latent_classes

        base_spec = replace(spec, latent_classes=1)
        base_index = build_base_index(base_spec)
        K_base = base_index["total_params"]

        params = np.asarray(result.x)
        if se is None:
            se = compute_standard_errors(params, objective)
        se_all = se[:C * K_base].reshape(C, K_base)
        logit_se = se[C * K_base:]

        theta_all = params[:C * K_base].reshape(C, K_base)

        logits = params[C * K_base:]
        logits_full = np.concatenate(([0.0], logits))
        pi = np.exp(logits_full - np.max(logits_full))
        pi /= pi.sum()

        print("\n====================================================")
        print("        LATENT CLASS MIXED MODEL SUMMARY")
        print("====================================================")

        # ---------------------------------------------
        # Print each class separately
        # ---------------------------------------------
        for c in range(C):

            print(f"\n################ CLASS {c+1} ################\n")

            class_result = DummyResult(theta_all[c])
            class_result.params = theta_all[c]

            print_summary(
                result=class_result,
                objective=None,
                data=data,
                spec=base_spec,
                param_index=base_index,
                se=se_all[c] 
            )

        # ---------------------------------------------
        # Print class probabilities
        # ---------------------------------------------
        print("\n================ CLASS PROBABILITIES ================\n")

        for c in range(C):
            print(f"pi_{c+1}: {pi[c]:.6f}")

        print("\n====================================================\n")
        for c in range(C - 1):
            print(f"logit_{c+2}  SE: {logit_se[c]:.6f}")

        return
    

    def positive_scale(x):
        return np.exp(np.clip(x, -12.0, 6.0))

    def sigmoid(x):
        return 1 / (1 + np.exp(-x))

    params_mle = np.asarray(result.params, dtype=np.float64)

    # ── PARTE shrinkage (post-MLE) ─────────────────────────────────────────
    # When an objective and param_index are available, apply the PARTE
    # adjusted ridge-type estimator (Alghamdi et al. 2026) to the
    # fixed-effect block.  The corrected LL (evaluated at PARTE params)
    # is used for AIC / BIC; the MLE LL is also reported for reference.
    parte_applied = False
    params_raw    = params_mle      # default: show MLE params
    corrected_ll  = None
    se_diagnostics = None

    if objective is not None and param_index is not None and se is None:
        try:
            params_parte_j, se_parte_j, _pr = compute_regularized_estimates(
                result.params, objective, param_index,
                variant="k3d3", check_multicollinearity=True,
            )
            corrected_ll   = float(-objective(params_parte_j))
            params_raw     = np.asarray(params_parte_j, dtype=np.float64)
            se_raw         = np.asarray(se_parte_j,     dtype=np.float64)
            parte_applied  = True
            _parte_result  = _pr
        except Exception:
            pass                    # fall back to MLE

    if not parte_applied:
        params_raw = params_mle
        if se is None:
            se_raw_j, se_diagnostics = compute_standard_errors(
                result.params, objective, return_diagnostics=True
            )
            se_raw = np.asarray(se_raw_j, dtype=np.float64)
        else:
            se_raw = se

    names = []

    # ==============================
    # BUILD PARAMETER NAME LIST
    # ==============================

    for name in spec.fixed_names:
        names.append(name)

    if spec.Kzi > 0:
        for name in spec.zi_names:
            names.append(f"zi({name})")

    for name in spec.random_cor_names:
        names.append(f"cor_mean({name})")

    chol_names = []
    if spec.Kr_cor > 0:
        cols = spec.random_cor_names
        K = spec.Kr_cor
        for i in range(K):
            for j in range(i + 1):
                nm = f"chol({cols[i]},{cols[j]})"
                names.append(nm)
                chol_names.append(nm)

    for name in spec.random_ind_names:
        names.append(f"mean({name})")
    for name in spec.random_ind_names:
        names.append(f"sd({name})")

    if spec.Kg > 0:
        for name in spec.grouped_names:
            names.append(f"group_mean({name})")
        for name in spec.grouped_names:
            names.append(f"group_sd({name})")

    if spec.Kh > 0:
        for rnd in spec.random_cor_names + spec.random_ind_names:
            for z in spec.hetro_names:
                names.append(f"hetro({rnd}|{z})")

    if getattr(spec, "Kv", 0) > 0:
        for rnd in spec.random_cor_names + spec.random_ind_names + spec.grouped_names:
            for z in spec.hetro_var_names:
                names.append(f"hetro_var({rnd}|{z})")

    if spec.Kh > 0 and spec.Kg > 0:
        for rnd in spec.grouped_names:
            for z in spec.hetro_names:
                names.append(f"hetro_group({rnd}|{z})")

    if getattr(spec, "Kgse", 0) > 0:
        for rnd in spec.random_cor_names + spec.random_ind_names:
            names.append(f"gse({rnd})")

    if spec.model in {"nb", "nb1"}:
        names.append("dispersion")
    elif spec.model in {"lognormal", "gaussian", "tobit", "weibull", "loglogistic", "weibull_ph"}:
        names.append("sigma")

    df = pd.DataFrame({
        "Parameter":    names,
        "Estimate_raw": params_raw,       # PARTE if applied, else MLE
        "MLE_raw":      params_mle,       # always the MLE (for shrinkage column)
        "StdErr_raw":   se_raw,
    })

    # ==========================================================
    # ✅ APPLY DELTA METHOD WHERE NEEDED
    # ==========================================================

    df["Estimate"]     = df["Estimate_raw"]
    df["Estimate_MLE"] = df["MLE_raw"]
    df["Std.Err"]      = df["StdErr_raw"]

    for i, row in df.iterrows():

        name = row["Parameter"]
        theta = row["Estimate_raw"]
        se_theta = row["StdErr_raw"]

        # Independent SD
        if name.startswith("sd("):
            phi = positive_scale(theta)
            deriv = phi

        # Grouped SD
        elif name.startswith("group_sd"):
            phi = positive_scale(theta)
            deriv = phi

        # NB dispersion
        elif name == "dispersion":
            phi = np.exp(np.clip(theta, -12.0, 12.0))
            deriv = phi

        # Cholesky diagonal
        elif name.startswith("chol("):
            # detect diagonal terms
            inside = name[5:-1]
            var1, var2 = inside.split(",")
            if var1 == var2:
                phi = positive_scale(theta)
                deriv = phi
            else:
                phi = theta
                deriv = 1.0

        else:
            phi = theta
            deriv = 1.0

        df.at[i, "Estimate"] = float(phi)
        df.at[i, "Std.Err"] = float(se_theta * abs(deriv))

    # ── Back-transform to original predictor scale ────────────────────────
    # If build_jax_data standardised the predictors, undo the standardisation
    # so that every coefficient is interpretable in the original data units.
    _scaler = data.get("scaler", {}) if isinstance(data, dict) else {}
    if _scaler:
        df = unstandardize_summary_df(df, _scaler, spec)

    # Recompute z and p (after possible back-transformation).  A NaN SE
    # means the parameter is not identified in this fit; leave z and p as
    # NaN instead of reporting the misleading p=1.0 produced by z=0.
    _est = pd.to_numeric(df["Estimate"], errors="coerce").to_numpy(dtype=float)
    _se = pd.to_numeric(df["Std.Err"], errors="coerce").to_numpy(dtype=float)
    _z = np.full(_est.shape, np.nan, dtype=float)
    _identified = np.isfinite(_se) & (_se > 1e-15)
    _z[_identified] = _est[_identified] / _se[_identified]
    df["z-value"] = _z
    df["p-value"] = 2 * (1 - stats.norm.cdf(np.abs(_z)))
    # ==========================================================
    # CLEAN DISPLAY (remove raw columns)
    # ==========================================================

    disp_cols = ["Parameter", "Estimate", "Std.Err", "z-value", "p-value"]
    if parte_applied:
        # Show MLE and shrinkage amount alongside the PARTE estimates
        df["Estimate_MLE_display"] = df["Estimate_MLE"]
        df["Shrinkage"] = df["Estimate"] - df["Estimate_MLE_display"]
        disp_cols = ["Parameter", "Estimate (MLE)", "Estimate (PARTE)",
                     "Std.Err", "z-value", "p-value", "Shrinkage"]
        df = df.rename(columns={
            "Estimate_MLE_display": "Estimate (MLE)",
            "Estimate":             "Estimate (PARTE)",
        })
    df_display = df[disp_cols]

    # Remove raw chol from main table
    main_df = df_display[~df_display["Parameter"].isin(chol_names)]

    print("\n================ MODEL SUMMARY ================\n")
    print(main_df.to_string(index=False))

    # ==========================================================
    # ✅ TRUE VAR-COV MATRIX FROM TRANSFORMED CHOLESKY
    # ==========================================================

    if spec.Kr_cor > 0:

        K = spec.Kr_cor
        L = np.zeros((K, K))

        chol_rows = df[df["Parameter"].isin(chol_names)]

        idx = 0
        for i in range(K):
            for j in range(i + 1):
                row = chol_rows.iloc[idx]
                L[i, j] = row["Estimate"]   # already transformed
                idx += 1

        Sigma = L @ L.T
        std = np.sqrt(np.diag(Sigma))
        Corr = Sigma / np.outer(std, std)

        cols = spec.random_cor_names

        print("\n================ CORRELATED RANDOM VAR-COV ================\n")

        for i in range(K):
            print(f"Var({cols[i]}) = {Sigma[i,i]:.6f}")

        for i in range(K):
            for j in range(i):
                print(f"Cov({cols[i]},{cols[j]}) = {Sigma[i,j]:.6f}")

        print("\n================ CORRELATION MATRIX ================\n")

        for i in range(K):
            for j in range(i):
                print(f"Corr({cols[i]},{cols[j]}) = {Corr[i,j]:.6f}")

    # ==========================================================
    # Fit stats
    # ==========================================================
    if objective is not None:

        mle_ll = float(-objective(result.params))
        k = len(result.params)
        n = data["y"].shape[0]

        # Use corrected LL (at PARTE params) for AIC/BIC when available
        eval_ll = corrected_ll if (parte_applied and corrected_ll is not None) else mle_ll
        aic = 2*k - 2*eval_ll
        bic = k * np.log(n) - 2*eval_ll

        # Keep the fit statistics attached to the named DataFrame.  This is
        # what ExperimentBuilder.fit_manual_model() promotes into
        # fit["summary"], so callers can reject non-identified fits instead
        # of treating NaN SEs as p=1.0.
        fit_stats = {
            "loglik": mle_ll,
            "num_parm": k,
            "n_obs": n,
            "aic": 2 * k - 2 * mle_ll,
            "bic": k * np.log(n) - 2 * mle_ll,
        }
        if eval_ll != mle_ll:
            fit_stats["loglik_parte"] = eval_ll
            fit_stats["aic_parte"] = aic
            fit_stats["bic_parte"] = bic
        if se_diagnostics is not None:
            _diag = dict(se_diagnostics)
            _unreliable = list(_diag.get("unreliable_indices", []))
            _diag["unreliable_parameters"] = [
                names[i] for i in _unreliable if 0 <= i < len(names)
            ]
            fit_stats["se_reliable"] = not bool(_unreliable)
            fit_stats["n_unreliable_se"] = len(_unreliable)
            fit_stats["se_diagnostics"] = _diag
            df.attrs["se_diagnostics"] = _diag
        df.attrs["fit_stats"] = fit_stats

        print("\n------------------------------------------------")
        print(f"Log-Likelihood (MLE):              {mle_ll:>14.4f}")
        if parte_applied and corrected_ll is not None:
            ll_delta = corrected_ll - mle_ll
            print(f"Log-Likelihood (PARTE-corrected):  {corrected_ll:>14.4f}"
                  f"  [d = {ll_delta:+.4f} vs MLE]")
            if _parte_result is not None:
                print(f"  (k = {_parte_result.k:.4f},  d = {_parte_result.d:.4f},"
                      f"  cond = {_parte_result.condition_number:.1f})")
            print(f"AIC  (PARTE LL): {float(aic):>14.4f}")
            print(f"BIC  (PARTE LL): {float(bic):>14.4f}")
        else:
            print(f"AIC: {float(aic):>14.4f}")
            print(f"BIC: {float(bic):>14.4f}")
        print("================================================\n")
        if return_df is not None and return_df:
            return df

def compute_mean_prediction(params, data, spec):

    eta = build_eta(params, data, spec)

    if eta.ndim == 2:
        eta = eta[..., None]

    mu = jnp.exp(eta)  # (N,P,R)

    # Average over simulation draws
    mu_mean = jnp.mean(mu, axis=-1)  # (N,P)

    return mu_mean


def evaluate_metrics(params, data, spec, name="DATA"):

    import numpy as np

    mu_hat = compute_mean_prediction(params, data, spec)

    y_true = np.array(data["y"])
    mask = np.array(data["mask"])

    mu_hat = np.array(mu_hat)

    # Ensure correct dimensions
    if y_true.ndim == 3:
        y_true = y_true.squeeze(-1)

    # Flatten everything
    y_true_flat = y_true.reshape(-1)
    mu_hat_flat = mu_hat.reshape(-1)
    mask_flat = mask.reshape(-1)

    # Keep only valid panel entries
    valid = mask_flat == 1

    y_true_flat = y_true_flat[valid]
    mu_hat_flat = mu_hat_flat[valid]

    # ===============================
    # METRICS
    # ===============================

    mse = np.mean((y_true_flat - mu_hat_flat) ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(y_true_flat - mu_hat_flat))

    # Avoid division by zero for MAPE
    nonzero = y_true_flat != 0
    mape = (
        np.mean(
            np.abs((y_true_flat[nonzero] - mu_hat_flat[nonzero])
                   / y_true_flat[nonzero])
        ) * 100
        if np.any(nonzero) else np.nan
    )

    # Poisson deviance
    poisson_dev = 2 * np.mean(
        y_true_flat * np.log((y_true_flat + 1e-12) / (mu_hat_flat + 1e-12))
        - (y_true_flat - mu_hat_flat)
    )

    print(f"\n================ {name} METRICS ================")
    print(f"MSE:   {mse:.6f}")
    print(f"RMSE:  {rmse:.6f}")
    print(f"MAE:   {mae:.6f}")
    print(f"MAPE:  {mape:.6f}")
    print(f"Poisson Deviance: {poisson_dev:.6f}")
    print("===============================================")

    return {
        "mse": mse,
        "rmse": rmse,
        "mae": mae,
        "mape": mape,
        "poisson_deviance": poisson_dev
    }


def generate_master_halton(N, K, R, seed=42,  burn=50, dtype=None):
    sampler = qmc.Halton(d=K, scramble=False, seed=seed)
    sampler.fast_forward(burn)
    u = sampler.random(N * R)
    u = np.clip(u, 1e-12, 1 - 1e-12)
    z = norm.ppf(u)
    z = z.reshape(N, R, K).swapaxes(1, 2)
    return jnp.array(z) if dtype is None else jnp.array(z, dtype=dtype)


def generate_master_sobol(N, K, R, seed=42, dtype=None):
    import math
    sampler = qmc.Sobol(d=K, scramble=True, seed=seed)
    total = N * R
    k = math.ceil(math.log2(max(total, 2)))
    try:
        u = sampler.random_base2(k)[:total]
    except (AttributeError, TypeError):
        u = sampler.random(total)
    u = np.clip(u, 1e-12, 1 - 1e-12)
    z = norm.ppf(u)
    z = z.reshape(N, R, K).swapaxes(1, 2)
    return jnp.array(z) if dtype is None else jnp.array(z, dtype=dtype)


def generate_master_draws(N, K, R, seed=42, draw_method='sobol', burn=50, dtype=None):
    """Unified draw generator: 'halton' or 'sobol'. Returns jnp.array (N, K, R).

    dtype (e.g. "float32") stores the master compactly; callers cast slices
    back to float64 for estimation (see _to_f64) so the likelihood stays in
    float64 while the long-lived master uses half the memory.
    """
    if draw_method == 'sobol':
        return generate_master_sobol(N, K, R, seed, dtype=dtype)
    else:
        return generate_master_halton(N, K, R, seed, burn, dtype=dtype)


def _to_f64(x):
    """Cast a draws slice to float64 for estimation (no-op if already f64)."""
    return jnp.asarray(x, dtype=jnp.float64)


# ─────────────────────────────────────────────────────────────────────────
# GPU out-of-memory recovery
# ─────────────────────────────────────────────────────────────────────────
# Long-running searches JIT-compile many distinct XLA programs (one per
# unique model spec / array shape). Each compiled executable holds on to
# device buffers, and XLA's kernel autotuner needs extra scratch memory to
# benchmark candidate kernel configs. Over hundreds of generations this can
# fill the GPU until even a small new fit can't be compiled, raising
# jax.errors.JaxRuntimeError("... RESOURCE_EXHAUSTED ... CUDA_ERROR_OUT_OF_MEMORY
# ... Failed to pick best config: All configs failed during profiling.").
#
# This helper recognises that failure mode, frees what JAX can free
# (clear_caches + gc), retries on GPU once, and finally falls back to CPU so
# that a GPU memory crunch degrades a fit instead of crashing the whole run.
_OOM_MARKERS = (
    "RESOURCE_EXHAUSTED",
    "CUDA_ERROR_OUT_OF_MEMORY",
    "out of memory",
    "Failed to pick best config",
)


def _is_oom_error(exc: BaseException) -> bool:
    msg = str(exc)
    return any(marker in msg for marker in _OOM_MARKERS)


def run_with_oom_recovery(fn, *args, label="operation", **kwargs):
    """Run fn(*args, **kwargs); recover from GPU OOM instead of crashing.

    On a GPU out-of-memory / autotuning failure, clears JAX's compilation
    caches and retries on the current device, then falls back to the CPU
    backend if the GPU is still exhausted. Non-OOM exceptions propagate
    unchanged.
    """
    try:
        return fn(*args, **kwargs)
    except Exception as exc:  # noqa: BLE001 - re-raised below if not OOM
        if not _is_oom_error(exc):
            raise

        print(f"  [warn] {label}: GPU out-of-memory ({type(exc).__name__}); "
              f"clearing JAX caches and retrying...")
        jax.clear_caches()
        gc.collect()

        try:
            return fn(*args, **kwargs)
        except Exception as exc2:  # noqa: BLE001
            if not _is_oom_error(exc2):
                raise

            print(f"  [warn] {label}: still out of memory on GPU; "
                  f"retrying on CPU (this will be slower).")
            jax.clear_caches()
            gc.collect()
            cpu = jax.devices("cpu")[0]
            with jax.default_device(cpu):
                return fn(*args, **kwargs)


# Jitted linear-predictor builder for post-fit prediction paths.  Calling
# ``build_eta`` eagerly on committed device arrays compiles a tiny kernel per
# primitive; one shared compilation is reused for every prediction call.
_build_eta_jit = jax.jit(build_eta, static_argnames=("spec",))


def _random_mean_scale_pairs(spec, param_index):
    """Return matching mean/log-SD parameter indices for RP diagnostics."""
    if getattr(spec, "latent_classes", 1) > 1 and "class_params" in param_index:
        base_spec = replace(spec, latent_classes=1)
        base_index = build_base_index(base_spec)
        pairs = []
        start, _ = param_index["class_params"]
        for class_number in range(spec.latent_classes):
            class_offset = start + class_number * base_index["total_params"]
            class_pairs = _random_mean_scale_pairs(base_spec, base_index)
            pairs.extend(
                {
                    **pair,
                    "mean_index": pair["mean_index"] + class_offset,
                    "scale_index": pair["scale_index"] + class_offset,
                    "label": f"class {class_number + 1}: {pair['label']}",
                }
                for pair in class_pairs
            )
        return pairs

    pairs = []
    if spec.Kr_cor > 0:
        mean_start, _ = param_index["cor_mean"]
        chol_start, _ = param_index["chol"]
        for k, name in enumerate(spec.random_cor_names):
            pairs.append({
                "label": f"cor_sd({name})",
                "mean_index": mean_start + k,
                "scale_index": chol_start + k * (k + 3) // 2,
            })
    if spec.Kr_ind > 0:
        mean_start, _ = param_index["ind_mean"]
        scale_start, _ = param_index["ind_sd"]
        for k, name in enumerate(spec.random_ind_names):
            pairs.append({
                "label": f"sd({name})",
                "mean_index": mean_start + k,
                "scale_index": scale_start + k,
            })
    if spec.Kg > 0:
        mean_start, _ = param_index["group_mean"]
        scale_start, _ = param_index["group_sd"]
        for k, name in enumerate(spec.grouped_names):
            pairs.append({
                "label": f"group_sd({name})",
                "mean_index": mean_start + k,
                "scale_index": scale_start + k,
            })
    return pairs


def run_lbfgs_with_trace(solver, init_params, *, label="LBFGS"):
    """Run an L-BFGS solver while recording the objective at every iteration.

    ``jaxopt.LBFGS.run`` compiles the update loop and returns only the final
    state, so the optimizer does not otherwise expose a loss trajectory.  This
    helper applies the same ``update`` calls and stopping rule as
    ``LBFGS._run``, but keeps the state values in a Python list.  The trace is
    therefore the actual objective used by the fit, not a post-hoc refit from
    the optimum.

    Returns
    -------
    (result, trace)
        ``result`` is a ``jaxopt.OptStep`` with the final parameters/state;
        ``trace`` is a list of ``{iteration, objective, gradient_norm}``
        dictionaries.  The loop is wrapped in ``run_with_oom_recovery`` so
        GPU OOM handling remains unchanged.
    """
    maxiter = int(solver.maxiter)

    def _run():
        state = solver.init_state(init_params)
        trace = [{
            "iteration": int(state.iter_num),
            "objective": float(state.value),
            "gradient_norm": float(state.error),
        }]

        if maxiter == 0:
            return OptStep(params=init_params, state=state), trace

        # LBFGS._run always performs the first update, even when the initial
        # gradient already satisfies the tolerance.  Mirror that behaviour so
        # the traced fit is numerically identical to solver.run(init).
        step = solver.update(init_params, state)
        trace.append({
            "iteration": int(step.state.iter_num),
            "objective": float(step.state.value),
            "gradient_norm": float(step.state.error),
        })

        for _ in range(maxiter - 1):
            state = step.state
            keep_going = bool(state.error > solver.tol)
            if solver.stop_if_linesearch_fails:
                keep_going = keep_going and not bool(state.failed_linesearch)
            if not keep_going:
                break
            step = solver.update(step.params, state)
            trace.append({
                "iteration": int(step.state.iter_num),
                "objective": float(step.state.value),
                "gradient_norm": float(step.state.error),
            })
        return step, trace

    return run_with_oom_recovery(_run, label=label)


def random_parameter_convergence_diagnostics(
    params,
    objective,
    spec,
    param_index,
    *,
    result=None,
    include_hessian=True,
):
    """Check stationarity, scale boundaries, and mean/scale coupling.

    A random effect is not considered trustworthy merely because an optimizer
    returned.  This reports whether the objective and gradient are finite,
    whether the log-SD is at a barrier, and whether the local Hessian couples
    the random mean and its log-SD strongly enough to make the estimate
    sensitive to joint initialization.
    """
    params_np = np.asarray(params, dtype=float).reshape(-1)
    pairs = _random_mean_scale_pairs(spec, param_index)
    report = {
        "has_random_parameters": bool(pairs),
        "objective": np.nan,
        "max_abs_gradient": np.nan,
        "relative_gradient": np.nan,
        "stationary": False,
        "scales": {},
        "boundary_parameters": [],
        "mean_scale_coupling": {},
        "max_mean_scale_coupling": np.nan,
        "random_hessian_condition": np.nan,
        "warnings": [],
    }
    if not pairs:
        return report

    try:
        objective_value = float(objective(jnp.asarray(params_np)))
        gradient = np.asarray(
            jax.grad(objective)(jnp.asarray(params_np)), dtype=float
        )
    except Exception as exc:
        report["warnings"].append(f"objective/gradient check failed: {exc}")
        return report

    report["objective"] = objective_value
    report["max_abs_gradient"] = float(np.max(np.abs(gradient)))
    report["relative_gradient"] = report["max_abs_gradient"] / max(
        1.0, abs(objective_value)
    )
    report["stationary"] = bool(
        np.isfinite(objective_value)
        and np.isfinite(gradient).all()
        and report["relative_gradient"] <= 1e-5
    )
    if not np.isfinite(objective_value) or not np.isfinite(gradient).all():
        report["warnings"].append("non-finite objective or gradient")
    elif not report["stationary"]:
        report["warnings"].append(
            f"gradient is not stationary (relative max={report['relative_gradient']:.2e})"
        )

    floor = max(float(getattr(spec, "variance_floor", 1e-3)), 1e-12)
    cap = max(float(getattr(spec, "variance_cap", 50.0)), floor)
    for pair in pairs:
        raw_scale = float(params_np[pair["scale_index"]])
        scale = float(np.exp(np.clip(raw_scale, -12.0, 6.0)))
        report["scales"][pair["label"]] = scale
        if scale <= floor * 1.05 or scale >= cap * 0.95:
            report["boundary_parameters"].append(pair["label"])
    if report["boundary_parameters"]:
        report["warnings"].append(
            "random SD at variance boundary: "
            + ", ".join(report["boundary_parameters"])
        )

    # A random coefficient whose mean drifts far outside a plausible scale
    # is the other common boundary/degeneracy failure for GSE fits: the
    # random scale and the mean compensate each other and the likelihood is
    # flat in that direction.  Report these means explicitly instead of
    # letting a finite log-likelihood hide the non-identification.
    report["means"] = {}
    report["divergent_mean_parameters"] = []
    for pair in pairs:
        mean_value = float(params_np[pair["mean_index"]])
        report["means"][pair["label"]] = mean_value
        if not np.isfinite(mean_value) or abs(mean_value) > 10.0:
            report["divergent_mean_parameters"].append(pair["label"])
    if report["divergent_mean_parameters"]:
        report["warnings"].append(
            "random-parameter mean diverged: "
            + ", ".join(report["divergent_mean_parameters"])
        )

    if not include_hessian:
        return report

    try:
        hessian = np.asarray(
            jax.jit(jax.hessian(objective))(jnp.asarray(params_np)),
            dtype=float,
        )
        random_indices = sorted({
            index
            for pair in pairs
            for index in (pair["mean_index"], pair["scale_index"])
        })
        random_hessian = hessian[np.ix_(random_indices, random_indices)]
        if not np.isfinite(random_hessian).all():
            raise ValueError("non-finite random-parameter Hessian")
        singular_values = np.linalg.svd(random_hessian, compute_uv=False)
        if singular_values.size:
            report["random_hessian_condition"] = float(
                singular_values[0] / max(singular_values[-1], 1e-12)
            )
        couplings = []
        for pair in pairs:
            mean_index = pair["mean_index"]
            scale_index = pair["scale_index"]
            denominator = np.sqrt(
                abs(hessian[mean_index, mean_index]
                    * hessian[scale_index, scale_index])
            )
            coupling = float(
                abs(hessian[mean_index, scale_index])
                / max(denominator, 1e-12)
            )
            report["mean_scale_coupling"][pair["label"]] = coupling
            couplings.append(coupling)
        if couplings:
            report["max_mean_scale_coupling"] = float(max(couplings))
        if report["random_hessian_condition"] > 1e8:
            report["warnings"].append(
                "random-parameter Hessian is ill-conditioned "
                f"(condition={report['random_hessian_condition']:.2e})"
            )
        if report["max_mean_scale_coupling"] > 0.95:
            report["warnings"].append(
                "random mean and log-SD are strongly coupled "
                f"(max curvature ratio={report['max_mean_scale_coupling']:.3f})"
            )
    except Exception as exc:
        report["warnings"].append(f"Hessian check failed: {exc}")

    return report


def random_parameter_identification_status(report):
    """Return whether a random-parameter fit is identified and why not.

    A finite log-likelihood is not sufficient evidence that a random-effect
    model is estimable.  A boundary variance, a runaway random mean, a
    near-singular random-parameter Hessian, or strong mean/scale coupling
    means the random-effect block is not identified and must not be
    presented as a clean fit.
    """
    if not report or not report.get("has_random_parameters"):
        return True, ""

    reasons = []
    boundary = list(report.get("boundary_parameters") or [])
    if boundary:
        reasons.append(
            "random SD at boundary: " + ", ".join(map(str, boundary))
        )
    divergent = list(report.get("divergent_mean_parameters") or [])
    if divergent:
        reasons.append(
            "random mean diverged: " + ", ".join(map(str, divergent))
        )

    coupling = report.get("max_mean_scale_coupling")
    try:
        coupling = float(coupling)
    except (TypeError, ValueError):
        coupling = np.nan
    if np.isfinite(coupling) and coupling >= 0.99:
        reasons.append(f"random mean/log-SD coupling={coupling:.3f}")

    condition = report.get("random_hessian_condition")
    try:
        condition = float(condition)
    except (TypeError, ValueError):
        condition = np.nan
    if np.isfinite(condition) and condition >= 1e14:
        reasons.append(f"random Hessian condition={condition:.1e}")

    if not bool(report.get("stationary", False)):
        reasons.append("random-parameter gradient is not stationary")

    return (not reasons), "; ".join(reasons)


class CountModel:

    def __init__(self, spec, data):
        self.spec = spec
        self.data = data
        self.param_index = build_param_index(spec)
        self.params = None
        self.last_de_report = None
        self.last_rp_diagnostics = None
        self.last_multistart_report = None
        self.last_optimization_trace = None

    def objective(self, params):
        return _call_loglik(params, self.data, self.spec)

    def _continuous_de_warm_start(
        self,
        init,
        *,
        maxiter=12,
        popsize=8,
        rel_span=1.5,
        abs_span=1.0,
        seed=0,
    ):
        center_np = np.asarray(init, dtype=float).reshape(-1)
        if center_np.size == 0:
            return jnp.array(center_np), {
                "ran": False,
                "accepted": False,
                "reason": "empty_init",
            }

        center_np = np.where(np.isfinite(center_np), center_np, 0.0)
        center = jnp.array(center_np)
        span = jnp.maximum(float(abs_span), jnp.abs(center) * float(rel_span))
        lower = center - span
        upper = center + span

        n_params = int(center.shape[0])
        n_pop = max(8, int(popsize) * 2)
        n_elite = max(2, n_pop // 4)
        large_val = 1e20

        def _safe_obj(x):
            try:
                value = float(self.objective(x))
            except Exception:
                return large_val
            if not np.isfinite(value):
                return large_val
            return value

        def _eval_pop(pop):
            # Micro-batched vmap: 16x (N x R) at once OOMs for N*R large
            # (e.g. 100k x 200). Batches of 4 give identical values at ~4x
            # lower peak; per-row fallback on any XLA failure.
            try:
                arr = np.asarray(pop, dtype=float)
                micro = 4
                outs = []
                for s in range(0, len(arr), micro):
                    chunk = jnp.asarray(arr[s:s + micro])
                    vals = jax.vmap(self.objective)(chunk)
                    vals = jnp.where(jnp.isfinite(vals), vals, large_val)
                    outs.append(np.asarray(vals, dtype=float))
                return np.concatenate(outs) if outs else np.zeros(0)
            except Exception:
                # Fallback if vectorized evaluation fails for any reason.
                return np.array([_safe_obj(row) for row in np.asarray(pop)], dtype=float)

        incumbent_obj = _safe_obj(center)
        report = {
            "ran": True,
            "accepted": False,
            "seed": int(seed),
            "maxiter": int(maxiter),
            "popsize": int(popsize),
            "start_obj": float(incumbent_obj),
            "de_obj": None,
            "delta_obj": None,
            "reason": "not_improved",
            "method": "jax_population_warm_start",
        }

        try:
            key = jax.random.PRNGKey(int(seed))
            key, sub = jax.random.split(key)
            pop = center + jax.random.normal(sub, (n_pop, n_params)) * span
            pop = jnp.clip(pop, lower, upper)
            pop = pop.at[0].set(center)

            best_x = center
            best_obj = incumbent_obj

            for it in range(int(maxiter)):
                vals = _eval_pop(pop)
                order = np.argsort(vals)

                if vals[order[0]] < best_obj:
                    best_obj = float(vals[order[0]])
                    best_x = pop[order[0]]

                elite_idx = order[:n_elite]
                elite = pop[elite_idx]

                elite_mean = jnp.mean(elite, axis=0)
                elite_std = jnp.std(elite, axis=0)
                anneal = max(0.15, 0.92 ** (it + 1))
                step = jnp.maximum(elite_std, span * 0.05) * anneal

                key, sub = jax.random.split(key)
                noise = jax.random.normal(sub, (n_pop, n_params))
                offspring = elite_mean + noise * step
                offspring = jnp.clip(offspring, lower, upper)
                offspring = offspring.at[0].set(best_x)

                if n_elite > 0:
                    keep = min(n_elite, n_pop - 1)
                    offspring = offspring.at[1:1 + keep].set(elite[:keep])

                pop = offspring

            report["de_obj"] = float(best_obj)
            report["delta_obj"] = float(incumbent_obj - best_obj)

            if np.isfinite(best_obj) and best_obj < incumbent_obj:
                report["accepted"] = True
                report["reason"] = "improved"
                return best_x, report

        except Exception as exc:
            report["reason"] = f"exception: {exc}"

        return center, report

    '''
    def fit(self):
        init = jnp.zeros(self.param_index["total_params"])
        
        key = jax.random.PRNGKey(0)

        n_params = self.param_index["total_params"]

        # Small random normal noise
        init = 0.001 * jax.random.normal(key, shape=(n_params,))
        solver = LBFGS(fun=self.objective, maxiter =2000, tol=1e-7,
        history_size=20)
        result = solver.run(init)
        self.params = result.params
        self.last_rp_diagnostics = random_parameter_convergence_diagnostics(
            result.params,
            self.objective,
            self.spec,
            self.param_index,
            result=result,
        )
        for message in self.last_rp_diagnostics["warnings"]:
            print(f"[RP CHECK] WARNING: {message}")
        return result
    '''
    def fit(
        self,
        use_prefit=False,
        use_continuous_de=False,
        de_maxiter=12,
        de_popsize=8,
        de_rel_span=1.5,
        de_abs_span=1.0,
        de_seed=0,
        lbfgs_maxiter=2000,
        lbfgs_tol=1e-6,
        lbfgs_history_size=20,
    ):

        n_params = self.param_index["total_params"]

        # --------------------------------------------------
        # 1️⃣ INITIALIZATION
        # --------------------------------------------------
        # Check for externally-supplied initial parameters first
        custom_init = getattr(self, "_init_params", None)
        if custom_init is not None:
            init = np.array(custom_init, dtype=float, copy=True)
        else:
            # Build the start vector in NumPy: eager JAX slicing/updates on
            # committed arrays compile one tiny executable per operation.
            # np.array (not asarray) copies: device_get buffers are read-only.
            key = jax.random.PRNGKey(0)
            init = np.array(0.01 * jax.random.normal(key, (n_params,)), copy=True)

            if use_prefit:
                try:
                    pre_beta = np.asarray(fit_simple_poisson_full(self.data, self.spec))

                    cursor_pre = 0  # position inside pre_beta

                    # ✅ Fixed
                    if self.spec.Kf > 0:
                        start, end = self.param_index["fixed"]
                        k = self.spec.Kf
                        init[start:end] = pre_beta[cursor_pre:cursor_pre+k]
                        cursor_pre += k

                    # ✅ Correlated means
                    if self.spec.Kr_cor > 0:
                        start, end = self.param_index["cor_mean"]
                        k = self.spec.Kr_cor
                        init[start:end] = pre_beta[cursor_pre:cursor_pre+k]
                        cursor_pre += k

                    # ✅ Independent means
                    if self.spec.Kr_ind > 0:
                        start, end = self.param_index["ind_mean"]
                        k = self.spec.Kr_ind
                        init[start:end] = pre_beta[cursor_pre:cursor_pre+k]
                        cursor_pre += k

                    # ✅ Grouped means
                    if self.spec.Kg > 0:
                        start, end = self.param_index["group_mean"]
                        k = self.spec.Kg
                        init[start:end] = pre_beta[cursor_pre:cursor_pre+k]
                        cursor_pre += k

                    # Everything else stays zero:
                    # sd's / chol params / heterogeneity / dispersion

                except Exception as e:
                    print("Prefit failed:", e)
                    key = jax.random.PRNGKey(0)
                    init = np.array(0.001 * jax.random.normal(key, (n_params,)), copy=True)

        # Track objective at the optimiser start point for diagnostics.
        try:
            start_obj = float(self.objective(init))
        except Exception:
            start_obj = None

        self.last_de_report = {
            "ran": False,
            "accepted": False,
            "reason": "disabled",
            "start_obj": start_obj,
            "de_obj": None,
            "delta_obj": None,
            "final_obj": None,
        }
        if use_continuous_de:
            init, self.last_de_report = self._continuous_de_warm_start(
                init,
                maxiter=de_maxiter,
                popsize=de_popsize,
                rel_span=de_rel_span,
                abs_span=de_abs_span,
                seed=de_seed,
            )
            # Preserve the raw optimiser start objective for before/after comparisons.
            self.last_de_report["start_obj"] = start_obj

        # --------------------------------------------------
        # 2️⃣ OPTIMIZE
        # --------------------------------------------------
        if getattr(self, "_use_slsqp", False):
            import jaxopt
            solver = jaxopt.ScipyMinimize(
                fun=self.objective, method="SLSQP", maxiter=3000, tol=1e-8
            )
            # SLSQP does not expose the L-BFGS state loop; keep convergence
            # diagnostics but leave the iteration trace unavailable.
            result = run_with_oom_recovery(
                solver.run, init, label="CountModel.fit"
            )
            self.last_optimization_trace = None
        else:
            # The previous default (500 iterations, tol=1e-3) could stop
            # while the GSE random-parameter block was still moving and leave
            # every random SD at the variance floor.  Use the longer settings
            # already documented in this module: 2,000 iterations, tighter
            # gradient tolerance, and a 20-step L-BFGS history.
            solver = LBFGS(
                fun=self.objective,
                maxiter=int(lbfgs_maxiter),
                tol=float(lbfgs_tol),
                history_size=int(lbfgs_history_size),
            )
            # OOM-aware: on a GPU out-of-memory the call is retried after
            # cache clears and finally falls back to CPU.  The trace is the
            # actual objective sequence from the successful L-BFGS run.
            result, self.last_optimization_trace = run_lbfgs_with_trace(
                solver, init, label="CountModel.fit"
            )

        try:
            self.last_de_report["final_obj"] = float(self.objective(result.params))
        except Exception:
            self.last_de_report["final_obj"] = None

        self.params = result.params
        return result
    
    
    def loglik(self):
        return -self.objective(self.params)

    def bic(self):
        n = self.data["y"].shape[0]
        k = len(self.params)
        return -2*self.loglik() + k*np.log(n)

    def predict(self):
        eta = np.asarray(_build_eta_jit(self.params, self.data, self.spec))
        if self.spec.model == "gaussian":
            return eta.mean(axis=-1)
        if self.spec.model == "tobit":
            # E[Y_obs | X] = Phi(z)*eta + sigma*phi(z),  z = eta/sigma
            # Eq. (11) in Chand & Dixit (2018)
            blocks = unpack_params(self.params, self.spec)
            sigma  = float(np.logaddexp(0.0, np.asarray(blocks["sigma"])))
            eta_m  = eta.mean(axis=-1)                  # (N, P)
            z      = eta_m / sigma
            phi_z  = np.exp(-0.5 * z ** 2) / np.sqrt(2.0 * np.pi)
            return stats.norm.cdf(z) * eta_m + sigma * phi_z
        mu = np.exp(eta)
        return mu.mean(axis=-1)

    def scipy_trust(self, seed=0):

        key = jax.random.PRNGKey(seed)
        init = 0.01 * jax.random.normal(key, (self.param_index["total_params"],))
        init = np.array(init)

        def obj_np(p):
            return np.array(self.objective(jnp.array(p)))

        def grad_np(p):
            return np.array(jax.grad(self.objective)(jnp.array(p)))

        result = minimize(
            obj_np,
            init,
            method="trust-constr",
            jac=grad_np,
            options={"maxiter": 3000}
        )

        ll = -obj_np(result.x)

        print("\nSCIPY TRUST-CONSTR LL:", ll)
        print("Iterations:", result.niter)

        return result
    
    def scipy_newton_cg(self, seed=0):

        key = jax.random.PRNGKey(seed)
        init = 0.01 * jax.random.normal(key, (self.param_index["total_params"],))
        init = np.array(init)

        def obj_np(p):
            return np.array(self.objective(jnp.array(p)))

        def grad_np(p):
            return np.array(jax.grad(self.objective)(jnp.array(p)))

        def hessp(p, v):
            return np.array(
                jax.jvp(jax.grad(self.objective),
                        (jnp.array(p),),
                        (jnp.array(v),))[1]
            )

        result = minimize(
            obj_np,
            init,
            method="Newton-CG",
            jac=grad_np,
            hessp=hessp,
            options={"maxiter": 3000}
        )

        ll = -obj_np(result.x)

        print("\nSCIPY NEWTON-CG LL:", ll)

        return result

    def scipy_slsqp(self, seed=0):
        """Optimize using jaxopt.ScipyMinimize with SLSQP. Gradients via JAXopt autodiff."""
        from jaxopt import ScipyMinimize as JaxoptMinimize

        key = jax.random.PRNGKey(seed)
        init = 0.01 * jax.random.normal(key, (self.param_index["total_params"],))
        init = jnp.array(init, dtype=jnp.float64)

        solver = JaxoptMinimize(
            fun=self.objective,
            method="SLSQP",
            maxiter=3000,
            tol=1e-8,
        )

        result = solver.run(init)
        params, state = result.params, result.state

        ll = -float(self.objective(params))
        print("\nJAXOPT SLSQP LL:", ll)
        print("Iterations:", int(state.iter_num))
        print("Success:", bool(state.success))

        return result


    def test_solvers(self, seed=0):

        key = jax.random.PRNGKey(seed)
        n_params = self.param_index["total_params"]
        init = 0.00 * jax.random.normal(key, (n_params,))

        obj = self.objective
        grad = jax.grad(obj)

        results = {}

        solvers = {
            "LBFGS": LBFGS(fun=obj, maxiter=2000, tol=1e-7),
            "BFGS": BFGS(fun=obj, maxiter=2000, tol=1e-7),
            "NonlinearCG": NonlinearCG(fun=obj, maxiter=2000, tol=1e-7),
            "GradientDescent": GradientDescent(fun=obj, maxiter=5000, stepsize=1e-3),
        }

        for name, solver in solvers.items():
            print(f"\nRunning {name}...")
            res = solver.run(init)

            params = res.params
            ll = obj(params)
            gnorm = jnp.linalg.norm(grad(params))

            results[name] = {
                "loglike": float(ll),
                "grad_norm": float(gnorm),
                "iterations": res.state.iter_num,
            }

            print(f"{name} LL: {ll:.6f}")
            print(f"{name} Grad norm: {gnorm:.6e}")
            print(f"{name} Iterations: {res.state.iter_num}")

        return results




def compute_scaler(df, cols, exclude_binary=True):
    """Return {col: (mean, std)} for continuous predictor columns only."""
    scaler = {}
    for col in cols:
        if col == "__INTERCEPT__" or col not in df.columns:
            continue
        vals = df[col].dropna()
        if len(vals) < 2:
            continue
        if exclude_binary:
            unique_vals = set(float(v) for v in vals.unique())
            if unique_vals.issubset({0.0, 1.0}):
                continue
        mu = float(vals.mean())
        sd = float(vals.std())
        if sd < 1e-10:
            continue
        scaler[col] = (mu, sd)
    return scaler


def compute_skewed_transforms(df, cols, skew_threshold=1.5):
    """Detect right-skewed continuous predictors and return {col: 'log1p'}.
    Only columns where >= 95 % of values are non-negative are considered.
    Call ``apply_transforms`` before ``compute_scaler`` and ``apply_scaler``
    so that standardisation operates on the transformed (more Gaussian) scale."""
    try:
        from scipy.stats import skew as _scipy_skew
    except ImportError:
        return {}
    transforms = {}
    for col in cols:
        if col == "__INTERCEPT__" or col not in df.columns:
            continue
        vals = df[col].dropna()
        if len(vals) < 10:
            continue
        # Skip binary columns
        unique_vals = set(float(v) for v in vals.unique())
        if unique_vals.issubset({0.0, 1.0}):
            continue
        neg_frac = float((vals < 0).mean())
        if neg_frac > 0.05:
            continue
        try:
            s = float(_scipy_skew(vals))
        except Exception:
            continue
        if abs(s) < skew_threshold:
            continue
        transforms[col] = "log1p"
    return transforms


def apply_transforms(df, transform_map):
    """Apply per-column transforms (log1p) in a new DataFrame copy."""
    df = df.copy()
    for col in transform_map:
        if col not in df.columns:
            continue
        vals = df[col].to_numpy(dtype=float)
        min_val = float(np.nanmin(vals)) if len(vals) > 0 else 0.0
        if min_val < 0:
            shift = abs(min_val) + 1e-6
            transformed = np.log1p(vals + shift)
        else:
            transformed = np.log1p(np.clip(vals, 0, None))
        if np.all(np.isfinite(transformed)):
            df[col] = transformed
    return df


def apply_scaler(df, scaler):
    """Return a copy of df with columns in scaler standardised to N(0,1)."""
    df = df.copy()
    for col, (mu, sd) in scaler.items():
        if col in df.columns:
            df[col] = (df[col] - mu) / sd
    return df


def unstandardize_summary_df(df_params, scaler, spec):
    """Back-transform summary estimates and SEs to original predictor units."""
    if not scaler:
        return df_params

    df = df_params.copy()
    fixed_set = set(getattr(spec, "fixed_names", ())) - {"__INTERCEPT__"}

    intercept_correction = 0.0
    for _, row in df.iterrows():
        name = row["Parameter"]
        if name in fixed_set and name in scaler:
            mu_k, sigma_k = scaler[name]
            intercept_correction += float(row["Estimate"]) * mu_k / sigma_k

    for i, row in df.iterrows():
        name = row["Parameter"]
        est = float(row["Estimate"])
        se = float(row["Std.Err"])
        nan_se = np.isnan(se)

        if name == "__INTERCEPT__":
            df.at[i, "Estimate"] = est - intercept_correction

        elif name in fixed_set and name in scaler:
            _, s = scaler[name]
            df.at[i, "Estimate"] = est / s
            df.at[i, "Std.Err"] = (se / s) if not nan_se else se

        elif name.startswith("zi("):
            inner = name[3:-1]
            if inner in scaler:
                _, s = scaler[inner]
                df.at[i, "Estimate"] = est / s
                df.at[i, "Std.Err"] = (se / s) if not nan_se else se

        elif name.startswith(("cor_mean(", "mean(", "group_mean(")):
            inner = name.split("(", 1)[1].rstrip(")")
            if inner in scaler:
                _, s = scaler[inner]
                df.at[i, "Estimate"] = est / s
                df.at[i, "Std.Err"] = (se / s) if not nan_se else se

        elif name.startswith(("sd(", "group_sd(")):
            inner = name.split("(", 1)[1].rstrip(")")
            if inner in scaler:
                _, s = scaler[inner]
                df.at[i, "Estimate"] = est / s
                df.at[i, "Std.Err"] = (se / s) if not nan_se else se

    return df


def check_identification(df, id_col, variable_names, min_variance=1e-6, collinearity_tol=1e-4):
    """
    Pre-screen a set of candidate variables for identification problems.

    Returns a set of variable names that are unidentifiable and should be
    excluded from the model specification before attempting estimation.

    Checks performed
    ----------------
    1. Near-constant columns  — variance below *min_variance*.
    2. Perfect / near-perfect collinearity — smallest singular value of the
       mean-centred design matrix is below *collinearity_tol*.
    3. Insufficient unique values — fewer than 2 distinct values (cannot
       contribute information to any likelihood).

    Parameters
    df : pd.DataFrame
        The data used for estimation.
    id_col : str
        Panel / observation ID column (excluded from screening).
    variable_names : list[str]
        Candidate predictor columns to screen.
    min_variance : float
        Variance threshold below which a variable is considered constant.
    collinearity_tol : float
        Singular-value threshold for near-perfect collinearity detection.

    Returns
    -------
    bad_vars : set[str]
        Names of variables that fail at least one identification check.
    reason : dict[str, str]
        Human-readable reason for each excluded variable.
    """
    bad_vars = set()
    reason   = {}

    candidate = [v for v in variable_names if v in df.columns and v != id_col]
    if not candidate:
        return bad_vars, reason

    # ── 1. Per-column checks ────────────────────────────────────────────
    for v in candidate:
        col = df[v].dropna()
        if len(col) == 0:
            bad_vars.add(v); reason[v] = "all-NA column"; continue
        n_unique = col.nunique()
        if n_unique < 2:
            bad_vars.add(v); reason[v] = "only one unique value"; continue
        var = float(col.var())
        if var < min_variance:
            bad_vars.add(v); reason[v] = f"near-constant (var={var:.2e})"; continue

    # ── 2. Collinearity among the surviving candidates ──────────────────
    surviving = [v for v in candidate if v not in bad_vars]
    if len(surviving) >= 2:
        try:
            X = df[surviving].dropna().values.astype(float)
            X_c = X - X.mean(axis=0)
            # Normalise columns to unit scale so different units don't dominate
            col_scale = np.maximum(X_c.std(axis=0), 1e-12)
            X_n = X_c / col_scale
            _, sv, Vt = np.linalg.svd(X_n, full_matrices=False)
            # Find near-zero singular values
            sv_tol = max(sv.max() * collinearity_tol, 1e-8)
            zero_sv_idx = np.where(sv < sv_tol)[0]
            for idx in zero_sv_idx:
                # The right singular vector identifies the collinear combination
                vec = np.abs(Vt[idx])
                # Blame the variable with the highest loading in the null space
                dominant = int(np.argmax(vec))
                v_bad = surviving[dominant]
                if v_bad not in bad_vars:
                    bad_vars.add(v_bad)
                    reason[v_bad] = (
                        f"near-perfect collinearity (sv={sv[idx]:.2e}, "
                        f"dominant loading on '{v_bad}')"
                    )
        except Exception:
            pass  # SVD failure is non-fatal; just skip this check

    return bad_vars, reason


class StructureEvaluator:

    def __init__(
        self,
        df,
        id_col,
        y_col,
        all_variables,
        allowed_roles,
        allowed_distributions,
        mode="single",
        group_id_col=None,
        offset_col=None,
        R=200,
        draw_method='sobol',  # 'halton' or 'sobol' — Sobol is faster & more stable
        draw_dtype="float32",  # storage dtype for the long-lived master draws
    ):

        self.id_col = id_col
        self.y_col = y_col
        self.offset_col=offset_col
        self.vars = all_variables
        self.allowed_roles = allowed_roles
        self.allowed_distributions = allowed_distributions
        self.mode = mode
        self.group_id_col = group_id_col
        self.R = R
        self.draw_method = draw_method
        _draw_dtype = str(draw_dtype).lower()
        if _draw_dtype not in ("float32", "float64"):
            raise ValueError("draw_dtype must be 'float32' or 'float64'.")
        self._draw_dtype = _draw_dtype
        # Group-level master draws, cached per (G, R, K, seed, method) so
        # grouped structures don't regenerate QMC draws on every fitness().
        self._grouped_draw_cache = {}
        self.structure_cache = set()

        if mode == "multi":
            self.df_train, self.df_test, self.df_val = build_datasets(df, id_col, y_col)
        else:
            self.df_train = df
            self.df_test = None

        # ✅ MASTER DRAWS (Halton or Sobol)
        # Created once here and sliced (never rewritten) for the whole search.
        # Stored compactly (default float32); slices are cast back to float64
        # at use time so estimation precision is unchanged.
        self.N_train = self.df_train[id_col].nunique()
        self.master_halton_train = generate_master_draws(
            self.N_train,
            len(all_variables),
            R,
            seed=42,
            draw_method=draw_method,
            dtype=self._draw_dtype,
        )

        if mode == "multi":
            self.N_test = self.df_test[id_col].nunique()
            self.master_halton_test = generate_master_draws(
                self.N_test,
                len(all_variables),
                R,
                seed=123,
                draw_method=draw_method,
                dtype=self._draw_dtype,
            )

        # ✅ Pre-compute unidentifiable variables once so build_spec can
        # reject them cheaply before any likelihood evaluation.
        self._unidentifiable, self._unid_reason = check_identification(
            self.df_train, id_col, all_variables
        )
        if self._unidentifiable:
            import warnings
            warnings.warn(
                f"StructureEvaluator: the following variables will be excluded "
                f"from all model structures because they are unidentifiable "
                f"in the training data:\n"
                + "\n".join(f"  {v}: {self._unid_reason[v]}"
                            for v in sorted(self._unidentifiable)),
                UserWarning,
                stacklevel=2,
            )

        self.cache = {}
        # Bounded result cache.  cache memoises every distinct decision vector
        # ever scored; over a multi-hour chunked search the key space is
        # unbounded, so this plain dict was the dominant long-run RSS growth.
        # We cap it (env MC_MAX_CACHE, default 250000) and evict oldest-first
        # on overflow, always protecting the best-so-far entry so chunked warm
        # starts and callers that scan evaluator.cache for the incumbent still
        # find it.  Eviction only costs recomputation -- fitness() is
        # deterministic in the decision vector -- so a high cap never changes
        # the search result, it only bounds memory.
        self._cache_best_key = None
        self._cache_best_val = None
        try:
            _cap = int(os.environ.get("MC_MAX_CACHE", "250000"))
        except (TypeError, ValueError):
            _cap = 250000
        self._cache_max = _cap if _cap > 0 else None
        self.structure_cache = set()
        self._failed_structures = set()  # structural signatures that failed to converge
        self._last_successful_decision = None   # for progressive variable-ban

    # ----------------------------------------
    # Build Spec
    # ----------------------------------------

    def build_spec(self, decision):

        D = len(self.vars)
        roles = decision[:D]
        dists = decision[D:]
        dispersion_bit = decision[-1]
        use_nb = dispersion_bit % 2 == 1
        fixed, rdm_ind, rdm_cor, grouped = [], [], [], []
        hetero = []
        zi = []
        for i, var in enumerate(self.vars):

            role = roles[i]
            if role not in self.allowed_roles.get(var, [0]):
                return None


            # ── Skip unidentifiable variables regardless of role ─────────
            if var in self._unidentifiable and role != 0:
                return None

            if role == 1:
                fixed.append(var)
            elif role == 2:
                dist = decode_distribution(
                    dists[i],
                    self.allowed_distributions.get(var, ["normal"])
                )
                rdm_ind.append(f"{var}:{dist}")
            elif role == 3:
                dist = decode_distribution(
                    dists[i],
                    self.allowed_distributions.get(var, ["normal"])
                )
                rdm_cor.append(f"{var}:{dist}")
            elif role == 4:
                dist = decode_distribution(
                    dists[i],
                    self.allowed_distributions.get(var, ["normal"])
                )
                grouped.append(f"{var}:{dist}")
            elif role == 5:
                # Heterogeneity in means (no distribution)
                hetero.append(var)

            elif role == 6:
                # zero inflation variable
                zi.append(var)

        if len(rdm_cor) == 1:
            rdm_ind.extend(rdm_cor)
            rdm_cor = []

        return {
            "fixed_terms": fixed,
            "rdm_terms": rdm_ind,
            "rdm_cor_terms": rdm_cor,
            "grouped_terms": grouped,
            "hetro_in_means": hetero,
            "zi_terms": zi,
            "dispersion": 1 if use_nb else 0
        }
    def structural_signature(self, spec_dict):

        total_random = (
            len(spec_dict["rdm_terms"]) +
            len(spec_dict["rdm_cor_terms"]) +
            len(spec_dict["grouped_terms"])
        )

        # Heterogeneity only matters if random parameters exist
        if total_random > 0:
            hetero_effective = tuple(sorted(spec_dict["hetro_in_means"]))
        else:
            hetero_effective = tuple()  # collapse heterogeneity

        return (
            tuple(sorted(spec_dict["fixed_terms"])),
            tuple(sorted(spec_dict["rdm_terms"])),
            tuple(sorted(spec_dict["rdm_cor_terms"])),
            tuple(sorted(spec_dict["grouped_terms"])),
            hetero_effective,
            tuple(sorted(spec_dict["zi_terms"])),
            spec_dict["dispersion"]
        )

    # ----------------------------------------
    # Grouped master draws (cached)
    # ----------------------------------------

    def _grouped_master_draws(self, G, seed=999, draw_method=None):
        """Return cached group-level master draws for G groups.

        Grouped structures previously regenerated a full QMC draw set on
        every fitness() call; the draws only depend on (G, R, K, seed,
        method), so one cached copy per key is exact and reused.
        """
        method = draw_method or getattr(self, "draw_method", "halton")
        key = (int(G), int(self.R), len(self.vars), int(seed), str(method))
        cache = getattr(self, "_grouped_draw_cache", None)
        if cache is None:
            cache = self._grouped_draw_cache = {}
        cached = cache.get(key)
        if cached is None:
            cached = generate_master_draws(
                int(G), len(self.vars), int(self.R),
                seed=int(seed), draw_method=method,
                dtype=getattr(self, "_draw_dtype", "float64"),
            )
            cache[key] = cached
        return cached

    # ----------------------------------------
    # Build Data Fast (Slicing Halton)
    # ----------------------------------------

    def build_data(self, df, spec_dict, master_halton):

        # First build spec only (no draws yet)
        data_tmp, spec = build_model_from_manual_spec(
            df=df,
            manual_spec=spec_dict,
            id_col=self.id_col,
            y_col=self.y_col,
            offset_col=self.offset_col,
            draws_ind=None,
            draws_cor=None,
            draws_g=None,
            R=self.R
        )

        var_index = {v: i for i, v in enumerate(self.vars)}

        ind_idx = [var_index[v] for v in spec.random_ind_names]
        cor_idx = [var_index[v] for v in spec.random_cor_names]
        g_idx   = [var_index[v] for v in spec.grouped_names]

        # ✅ SAFETY CHECKS
        if spec.Kr_ind != len(ind_idx):
            raise ValueError("Mismatch between spec.Kr_ind and ind_idx length")

        if spec.Kr_cor != len(cor_idx):
            raise ValueError("Mismatch between spec.Kr_cor and cor_idx length")

        if spec.Kg != len(g_idx):
            raise ValueError("Mismatch between spec.Kg and g_idx length")

        # ✅ Slice master halton (cast back to float64 for estimation)
        draws_ind = _to_f64(master_halton[:, ind_idx, :]) if spec.Kr_ind > 0 else None
        draws_cor = _to_f64(master_halton[:, cor_idx, :]) if spec.Kr_cor > 0 else None

        # ✅ Grouped draws need their own N (groups, not individuals)
        if spec.Kg > 0:
            if self.group_id_col is None:
                raise ValueError("Grouped effects require group_id_col")

            G = df[self.group_id_col].nunique()

            # Reuse the cached group-level master (was regenerated every eval)
            master_halton_g = self._grouped_master_draws(
                G, seed=999, draw_method="halton")

            draws_g = _to_f64(master_halton_g[:, g_idx, :])
        else:
            draws_g = None

        # ✅ Rebuild full data with correct draws
        data, spec = build_model_from_manual_spec(
            df=df,
            manual_spec=spec_dict,
            id_col=self.id_col,
            y_col=self.y_col,
            offset_col=self.offset_col,
            draws_ind=draws_ind,
            draws_cor=draws_cor,
            draws_g=draws_g,
            R=self.R
        )

        return data, spec

    # ----------------------------------------
    # Bounded result cache
    # ----------------------------------------

    @staticmethod
    def _cache_scalar(value):
        """Reduce a cached fitness value to the scalar used for ranking.

        Single-objective entries are floats; multi-objective entries are
        (bic, rmse) arrays and rank on BIC.  Returns None when the value
        carries no usable ranking (NaN/inf).
        """
        try:
            v = float(np.min(value)) if hasattr(value, "__len__") else float(value)
        except (TypeError, ValueError):
            return None
        return v if np.isfinite(v) else None

    def _cache_put(self, key, value):
        """Store a result, tracking the best-so-far and evicting on overflow.

        The best entry is never evicted so warm starts and callers that scan
        ``evaluator.cache`` for the incumbent keep working across chunks.
        """
        self.cache[key] = value
        v = self._cache_scalar(value)
        if v is not None and v < 1e12:
            if self._cache_best_val is None or v < self._cache_best_val:
                self._cache_best_val = v
                self._cache_best_key = key
        if self._cache_max is not None and len(self.cache) > self._cache_max:
            self._cache_evict()

    def _cache_evict(self):
        """Evict oldest entries down to 90% of the cap (batched, O(batch))."""
        target = int(self._cache_max * 0.9)
        excess = len(self.cache) - target
        if excess <= 0:
            return
        protected = self._cache_best_key
        doomed = []
        for k in self.cache:
            if excess <= 0:
                break
            if k == protected:
                continue
            doomed.append(k)
            excess -= 1
        for k in doomed:
            del self.cache[k]

    # ----------------------------------------
    # Fitness
    # ----------------------------------------

    def fitness(self, decision):

        key = tuple(decision.tolist())

        if key in self.cache:
            return self.cache[key]

        # Every 1e12 return below is indistinguishable to the caller, which
        # is how a broken probe scaffold reported a confident "grouped loses"
        # for every term having fitted nothing. Count the reason for each.
        _fail = np.array([1e12, 1e12]) if self.mode == "multi" else 1e12

        def _note(reason, **kw):
            if not hasattr(self, "_reject_counts"):
                self._reject_counts = {}
            d = self._reject_counts.setdefault(reason, {"count": 0})
            d["count"] += 1
            for k, v in kw.items():
                d[k] = v
            if not hasattr(self, "_last_rejection"):
                self._last_rejection = []
            self._last_rejection.append(
                {"reason": reason, **kw,
                 "variable": self.vars[int(kw["var_index"])]
                 if "var_index" in kw else None}
                if "var_index" in kw else {"reason": reason, **kw})
            if len(self._last_rejection) > 50:
                self._last_rejection = self._last_rejection[-50:]
            return _fail

        spec_dict = self.build_spec(decision)
        if spec_dict is None:
            return _note("build_spec_rejected",
                         detail=str(getattr(self, "last_rejection_reason",
                                            ""))[:200])
        sig = self.structural_signature(spec_dict)

        if sig in self._failed_structures:
            return _note("known_failed_structure")

        if sig in self.structure_cache:
            # structure_cache holds one entry and is cleared on every success,
            # so this only fires for a signature seen within the current
            # step -- a repeat request for the same structure.
            return _note("duplicate_structure_signature")
        
        self.structure_cache.clear()
        self.structure_cache.add(sig)
        try:

            # ✅ TRAIN
            data_train, spec = self.build_data(
                self.df_train,
                spec_dict,
                self.master_halton_train
            )

            model = CountModel(spec, data_train)
            model.fit()
           # print("Expected total params:", model.param_index["total_params"])
           # print("Actual total params:", len(model.params))

            bic = model.bic()

            if self.mode == "single":
                value = float(bic)
                self._cache_put(key, value)
                self._last_successful_decision = decision.copy()
                return value

            # ✅ TEST
            data_test, _ = self.build_data(
                self.df_test,
                spec_dict,
                self.master_halton_test
            )

            model_test = CountModel(spec, data_test)
            model_test.params = model.params

            preds = model_test.predict()
            y_true = np.array(data_test["y"]).squeeze()
            rmse = np.sqrt(np.mean((preds - y_true)**2))

            value = np.array([float(bic), float(rmse)])

            self._cache_put(key, value)
            self._last_successful_decision = decision.copy()
            return value

        except Exception as e:
            print("Fitness error:", e)
            # Blame any variable whose ROLE changed, not only one that went
            # 0 -> non-zero. A variable that fails specifically as Grouped
            # (role 1 -> 4) was already active, so the old 0->non-zero test
            # scored it innocent: the failure was recorded against nobody
            # and the SA simply saw an unexplained 1e12. That is how a whole
            # structural axis (grouped RP) stayed untested across two runs.
            if (sig is not None and self._last_successful_decision is not None
                    and len(decision) >= len(self.vars)
                    and len(self._last_successful_decision) >= len(self.vars)):
                for i in range(len(self.vars)):
                    if int(self._last_successful_decision[i]) != int(decision[i]):
                        var = self.vars[i]
                        if not hasattr(self, "_variable_failure_counts"):
                            self._variable_failure_counts = {}
                        if not hasattr(self, "_banned_variables"):
                            self._banned_variables = set()
                        if not hasattr(self, "_force_included_vars"):
                            self._force_included_vars = {
                                v for v, a in self.allowed_roles.items() if 0 not in a
                            }
                        if not hasattr(self, "_BAN_THRESHOLD"):
                            self._BAN_THRESHOLD = 10
                        if var not in self._force_included_vars:
                            cnt = self._variable_failure_counts.get(var, 0) + 1
                            self._variable_failure_counts[var] = cnt
                            if cnt >= self._BAN_THRESHOLD and var not in self._banned_variables:
                                self._banned_variables.add(var)
                                print(f"  [ban] '{var}' excluded from future"
                                      f" candidates ({cnt} failure{'' if cnt == 1 else 's'}"
                                      f" when newly added); threshold = {self._BAN_THRESHOLD}")
                if len(getattr(self, "_banned_variables", set())) > 50:
                    self._banned_variables.clear()
                    if hasattr(self, "_variable_failure_counts"):
                        self._variable_failure_counts.clear()
            if sig is not None:
                self._failed_structures.add(sig)
                if len(self._failed_structures) > 2000:
                    self._failed_structures.clear()
            _note("fit_exception", detail=f"{type(e).__name__}: {e}"[:200])
            self._cache_put(key, _fail)
            return _fail

    def reject_summary(self):
        """Counts per 1e12 rejection reason, for run-level reporting.

        Lets a caller distinguish "the search tried and failed" from "the
        search never tried" and from "the structure was already known
        broken" -- previously all three looked identical.
        """
        return {
            "counts": dict(getattr(self, "_reject_counts", {})),
            "recent": list(getattr(self, "_last_rejection", []))[-20:],
        }




def generate_draws(dist_name, shape):

    if dist_name == "normal":
        return np.random.normal(size=shape)

    elif dist_name == "lognormal":
        return np.random.lognormal(mean=0, sigma=1, size=shape)

    elif dist_name == "negative_lognormal":
        return -np.random.lognormal(mean=0, sigma=1, size=shape)

    elif dist_name == "triangular":
        return np.random.triangular(-1, 0, 1, size=shape)

    elif dist_name == "uniform":
        return np.random.uniform(-1, 1, size=shape)

    else:
        raise ValueError("Unknown distribution")

def unpack_params(params, spec: ModelSpec, model=None):

        _model = model if model is not None else getattr(spec, 'model', 'poisson')

        idx = 0
        out = {}

        # FIXED
        if spec.Kf > 0:
            out["beta_f"] = params[idx:idx + spec.Kf]
            idx += spec.Kf
        else:
            out["beta_f"] = None
        # Zero INflated
        if spec.Kzi > 0:
            out["beta_zi"] = params[idx:idx + spec.Kzi]
            idx += spec.Kzi
        else:
            out["beta_zi"] = None

        # CORRELATED RANDOM
        if spec.Kr_cor > 0:
            out["mean_cor"] = params[idx:idx + spec.Kr_cor]
            idx += spec.Kr_cor

            Kchol = spec.Kr_cor * (spec.Kr_cor + 1) // 2
            out["chol"] = params[idx:idx + Kchol]
            idx += Kchol
        else:
            out["mean_cor"] = None
            out["chol"] = None

        # INDEPENDENT RANDOM
        if spec.Kr_ind > 0:
            out["mean_ind"] = params[idx:idx + spec.Kr_ind]
            idx += spec.Kr_ind

            out["sd_ind"] = params[idx:idx + spec.Kr_ind]
            idx += spec.Kr_ind
        else:
            out["mean_ind"] = None
            out["sd_ind"] = None

        # GROUPED RANDOM
        if spec.Kg > 0:
            out["mean_g"] = params[idx:idx + spec.Kg]
            idx += spec.Kg

            out["sd_g"] = params[idx:idx + spec.Kg]
            idx += spec.Kg
        else:
            out["mean_g"] = None
            out["sd_g"] = None

        # HETEROGENEITY (MEANS)
        if spec.Kh > 0 and spec.K_random_total > 0:
            Khet = spec.Kh * spec.K_random_total
            gamma = params[idx:idx + Khet]
            idx += Khet

            out["gamma"] = gamma.reshape(spec.Kh, spec.K_random_total)
        else:
            out["gamma"] = None

        # HETEROGENEITY (VARIANCES)
        if spec.Kv > 0 and spec.K_random_total > 0:
            Khet_var = spec.Kv * spec.K_random_total
            gamma_var = params[idx:idx + Khet_var]
            idx += Khet_var

            out["gamma_var"] = gamma_var.reshape(spec.Kv, spec.K_random_total)
        else:
            out["gamma_var"] = None

        # HETEROGENEITY (MEANS OF GROUPED COEFFICIENTS)
        if spec.Kh > 0 and spec.Kg > 0:
            Khet_g = spec.Kh * spec.Kg
            gamma_g = params[idx:idx + Khet_g]
            idx += Khet_g
            out["gamma_g"] = gamma_g.reshape(spec.Kh, spec.Kg)
        else:
            out["gamma_g"] = None

        # GSE GRADIENT-SCORE LOADINGS (one gamma per random coefficient)
        if getattr(spec, "Kgse", 0) > 0 and spec.K_random_total > 0:
            out["gamma_gse"] = params[idx:idx + spec.K_random_total]
            idx += spec.K_random_total
        else:
            out["gamma_gse"] = None

        # NB DISPERSION / SCALE
        if _model in {"nb", "nb1"}:
            out["alpha"] = params[idx]
            idx += 1
        elif _model in {"lognormal", "gaussian", "tobit", "weibull", "loglogistic", "weibull_ph"}:
            out["sigma"] = params[idx]
            idx += 1
        else:
            out["alpha"] = None

        out["final_index"] = idx
        return out
    
    
def decode_best_solution(best_solution, evaluator):

    D = len(evaluator.vars)

    roles = best_solution[:D]
    dists = best_solution[D:]

    print("\n================ BEST MODEL STRUCTURE ================\n")

    for i, var in enumerate(evaluator.vars):

        role = roles[i]

        # Keep in sync with model_constraints._ROLE_LABELS. Codes 7/8 are
        # latent-class membership roles: outside an LC search they are
        # stripped from allowed_roles, so seeing one here means the decision
        # predates that strip (a stale checkpoint warm start) and the variable
        # is NOT a plain outcome term. Flag it rather than printing "Unknown".
        role_map = {
            0: "Excluded",
            1: "Fixed",
            2: "Random Independent",
            3: "Random Correlated",
            4: "Grouped",
            5: "Heterogeneity",
            6: "Zero Inflated",
            7: "Membership Only (non-LC: DROPPED)",
            8: "Membership + Fixed (non-LC: fixed term)",
            9: "Heterogeneity in Variances"
        }

        role_name = role_map.get(role, f"Unknown (role {role})")

        dist = None
        if var in evaluator.allowed_distributions:
            allowed = evaluator.allowed_distributions[var]
            dist = allowed[dists[i] % len(allowed)]

        # ASCII arrow: a cp1252 console cannot encode U+2192 and would raise
        # UnicodeEncodeError here, turning a successful search into a crash.
        print(f"{var:12} -> {role_name:22} | Dist: {dist}")

    print("\n======================================================\n")

def debug_model_pipeline(df, id_col, y_col, group_id_col=None, R=200):

    print("\n================ DEBUGGING MODEL PIPELINE ================\n")

    N = df[id_col].nunique()
    G = df[group_id_col].nunique() if group_id_col else 0

    # -------------------------------------------------------
    # Helper to run one spec
    # -------------------------------------------------------
    def run_spec(name, manual_spec, draws_ind=None, draws_cor=None, draws_g=None):
        print(f"\n--- Testing: {name} ---")

        try:
            data, spec = build_model_from_manual_spec(
                df=df,
                manual_spec=manual_spec,
                id_col=id_col,
                y_col=y_col,
                draws_ind=draws_ind,
                draws_cor=draws_cor,
                draws_g=draws_g,
                R=R
            )

            param_index = build_param_index(spec)
            
            init = jnp.zeros(param_index["total_params"])

            objective = partial(mixed_model_loglik, data=data, spec=spec)
            init = jnp.zeros(param_index["total_params"])

            val = objective(init)

            print("Objective at init:", val)

            if jnp.isnan(val):
                print("❌ Objective already NaN at initialization")
                return

            solver = LBFGS(fun=objective)
            result = solver.run(init)
            print("Expected total params:", param_index["total_params"])
            print("Actual total params:", len(result.params))
            ll = -objective(result.params)

            print("✅ SUCCESS")
            print("LogLik:", float(ll))

        except Exception as e:
            print("❌ FAILED")
            print("Error:", e)

    # =======================================================
    # 1️⃣ Fixed Only
    # =======================================================
    spec_fixed = {
        "fixed_terms": ["CURVES"],
        "rdm_terms": [],
        "rdm_cor_terms": [],
        "grouped_terms": [],
        "hetro_in_means": [],
        "dispersion": 1
    }

    run_spec("Fixed Only", spec_fixed)

    # =======================================================
    # 2️⃣ Independent Random
    # =======================================================
    draws_ind = generate_halton_normal(N=N, K=1, R=R, seed=42)

    spec_ind = {
        "fixed_terms": [],
        "rdm_terms": ["CURVES:normal"],
        "rdm_cor_terms": [],
        "grouped_terms": [],
        "hetro_in_means": [],
        "dispersion": 1
    }

    run_spec("Independent Random", spec_ind, draws_ind=draws_ind)

    # =======================================================
    # 3️⃣ Correlated Random (2 vars)
    # =======================================================
    draws_cor = generate_halton_normal(N=N, K=2, R=R, seed=42)

    spec_cor = {
        "fixed_terms": [],
        "rdm_terms": [],
        "rdm_cor_terms": [
            "CURVES:normal",
            "FRICTION:normal"
        ],
        "grouped_terms": [],
        "hetro_in_means": [],
        "dispersion": 1
    }

    run_spec("Correlated Random", spec_cor, draws_cor=draws_cor)

    # =======================================================
    # 4️⃣ Grouped Random
    # =======================================================
    if group_id_col:

        draws_g = generate_halton_normal(N=G, K=1, R=R, seed=123)

        spec_group = {
            "fixed_terms": ['TRAIN'],
            "rdm_terms": [],
            "rdm_cor_terms": [],
            "grouped_terms": ["TRAIN:normal"],
            "hetro_in_means": [],
            "dispersion": 1,
            "group_id_col": group_id_col
        }

        run_spec("Grouped Random", spec_group, draws_g=draws_g)

    # =======================================================
    # 5️⃣ Heterogeneity (requires random term)
    # =======================================================
    draws_ind = generate_halton_normal(N=N, K=1, R=R, seed=42)

    spec_het = {
        "fixed_terms": [],
        "rdm_terms": ["CURVES:normal"],
        "rdm_cor_terms": [],
        "grouped_terms": [],
        "hetro_in_means": ["INCLANES:normal", 'SPEED:normal'],
        "dispersion": 1
    }

    run_spec("Random + Heterogeneity", spec_het, draws_ind=draws_ind)

    print("\n================ DEBUG COMPLETE ================\n")
    
    
def populate_allowed_roles(all_variables,
                           allowed_roles_partial,
                           default_roles=None, grouped =  True):

    if default_roles is None:
        if grouped:
            default_roles = [0,1,2,3,4,5,6]
        else:
            default_roles = [0,1,2,3,5,6]
                

    full_roles = {}

    for var in all_variables:
        full_roles[var] = allowed_roles_partial.get(
            var,
            default_roles
        )

    return full_roles


def populate_allowed_distributions(all_variables,
                                   allowed_dist_partial,
                                   default_dist=None):

    if default_dist is None:
        default_dist = ["normal", 'uniform', 'lognormal', 'triangular', 'neglognormal']

    full = {}

    for var in all_variables:
        if allowed_dist_partial is None:
            full[var] = default_dist
        else:    
        
            full[var] = allowed_dist_partial.get(
                var,
                default_dist
            )

    return full


def print_from_nsga_result(nsga_result, evaluator):

    solutions = nsga_result["solutions"]
    scores = nsga_result["scores"]

    # SINGLE OBJECTIVE
    if not isinstance(scores, np.ndarray) or scores.ndim == 0:

        best_solution = solutions

        print("\n================ BEST NSGA STRUCTURE ================\n")
        decode_best_solution(best_solution, evaluator)
        refit_and_print(evaluator, best_solution)
        return

    # MULTI OBJECTIVE
    solutions = np.array(solutions)
    scores = np.array(scores)

    best_idx = np.argmin(scores[:, 0])   # e.g., best BIC
    best_solution = solutions[best_idx]

    print("\n================ BEST NSGA STRUCTURE ================\n")
    decode_best_solution(best_solution, evaluator)
    refit_and_print(evaluator, best_solution)

def report_from_result(result, data, spec):
    """
    Print full model summary from an already-fitted result.
    No refitting.
    """

    from functools import partial

    objective = partial(mixed_model_loglik, data=data, spec=spec)

    param_index = build_param_index(spec)

    print_summary(
        result=result,
        objective=objective,
        data=data,
        spec=spec,
        param_index=param_index
    )

def run_stepwise(evaluator, seed):

    np.random.seed(seed)

    solver = StepwiseStructureSolver(
        fitness_function=evaluator.fitness,
        all_variables=evaluator.vars,
        allowed_roles=evaluator.allowed_roles,
        allowed_distributions=evaluator.allowed_distributions,
        max_iter=50
    )

    solution, score = solver.optimize()

    return {
        "algorithm": "Stepwise",
        "seed": seed,
        "solution": solution,
        "score": score
    }

#def run_nsga(evaluator, operator_class, seed, pop_size=30, max_iter=40):
def run_nsga(evaluator, operator, seed, pop_size=30, max_iter=40, n_jobs=1):

    np.random.seed(seed)

    engine = NSGA2Engine(
    evaluator=evaluator,
    operator=operator,
    dimension=2 * len(evaluator.vars)+1,
    pop_size=pop_size,
    max_iter=max_iter,
    n_jobs=n_jobs,
    save_history=True
    )
    

    solutions, scores = engine.optimize()
    engine.save_search_stats_txt(
    algo=operator.__class__.__name__,
    seed=seed,
    config_id=seed
    )
    stats_csv = engine.save_search_stats_csv(
    algo=operator.__class__.__name__,
    seed=seed,
    config_id=seed
    )
    engine.finalize_plots(
    algo=operator.__class__.__name__,
    seed=seed
    )
    return {
        "algorithm": operator.__class__.__name__,
        "seed": seed,
        "solutions": solutions,
        "scores": scores,
        "fitness_history": engine.fitness_history,
        "hypervolume_history": engine.hypervolume_history,
        "pareto_history": engine.pareto_history,
        "search_stats": engine.search_stats,
        "stats_csv": [stats_csv],   # list, for consistency with the sa/hc branch's one-per-restart shape
    }


def run_stepwise(evaluator, seed):

    np.random.seed(seed)

    solver = StepwiseStructureSolver(
        fitness_function=evaluator.fitness,
        all_variables=evaluator.vars,
        allowed_roles=evaluator.allowed_roles,
        allowed_distributions=evaluator.allowed_distributions,
        max_iter=50
    )

    solution, score = solver.optimize()

    return {
        "algorithm": "Stepwise",
        "seed": seed,
        "solution": solution,
        "score": score
    }



def refit_and_print(evaluator, decision):

    # Build spec dictionary
    spec_dict = evaluator.build_spec(decision)
    if spec_dict is None:
        print("Invalid structure.")
        return

    # Build training data
    data_train, spec = evaluator.build_data(
        evaluator.df_train,
        spec_dict,
        evaluator.master_halton_train
    )

    # Fit model
    model = CountModel(spec, data_train)
    result = model.fit()

    # Print summary
    objective = partial(mixed_model_loglik, data=data_train, spec=spec)
    param_index = build_param_index(spec)

    print_summary(
        result=result,
        objective=objective,
        data=data_train,
        spec=spec,
        param_index=param_index
    )
    
def print_from_sa_result(sa_result, evaluator):

    best_solution = sa_result["best_solution"]

    print("\n================ BEST SA STRUCTURE ================\n")
    decode_best_solution(best_solution, evaluator)

    # Optional refit like NSGA
    refit_and_print(evaluator, best_solution)
    
    
def summarize_experiment(result, config, runtime, config_id):

    summary = {}

    summary["timestamp"] = datetime.now().isoformat()
    summary["algorithm"] = result["algorithm"]
    summary["seed"] = result["seed"]
    summary["config_id"] = config_id
    summary["config"] = config
    summary["runtime_seconds"] = runtime

    # -------------------------
    # SINGLE OBJECTIVE
    # -------------------------
    if "best_score" in result:

        summary["best_score"] = float(result["best_score"])
        summary["num_solutions"] = len(result["solutions"])

    # -------------------------
    # MULTI OBJECTIVE (NSGA)
    # -------------------------
    elif "scores" in result:

        scores = np.atleast_1d(np.array(result["scores"]))

        # Single objective case
        if scores.ndim == 1:
            summary["num_solutions"] = scores.shape[0]
            summary["best_score"] = float(np.min(scores))
            return summary

        # Multi-objective case
        summary["num_solutions"] = scores.shape[0]
        summary["pareto_size"] = scores.shape[0]
        summary["best_bic"] = float(np.min(scores[:, 0]))
        summary["best_rmse"] = float(np.min(scores[:, 1]))

        if "hypervolume_history" in result:
            hv = result["hypervolume_history"]
            summary["final_hypervolume"] = (
                float(hv[-1]) if len(hv) > 0 else None
            )

    return summary

def append_experiment_to_csv(summary, filename="results/experiment_log.csv"):

    os.makedirs("results", exist_ok=True)

    df = pd.DataFrame([summary])

    if os.path.exists(filename):
        df.to_csv(filename, mode="a", header=False, index=False)
    else:
        df.to_csv(filename, index=False)

    print("✅ Logged experiment to CSV")




def run_glmulti_experiment(df_train, df_test, vars):
    import subprocess
    import tempfile
    import os

    r_exe = r"C:\Users\ahernz\AppData\Local\Programs\R\R-4.4.1\bin\x64\Rscript.exe"
    r_script = os.path.abspath("glm_multi.R")

    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f_train, \
         tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f_test, \
         tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f_out:

        df_train.to_csv(f_train.name, index=False)
        df_test.to_csv(f_test.name, index=False)
        vars_string = ",".join(vars)
        cmd = [
            r_exe,
            r_script,
            f_train.name,
            f_test.name,
            f_out.name,
            vars_string,
            "OFFSET"  
        ]

        print("Running:", cmd)  # optional debug

        subprocess.run(cmd, check=True)

        result = pd.read_csv(f_out.name)

    return result["bic"].iloc[0], result["rmse"].iloc[0]

def run_r_experiment(df_train, df_test, vars, r_path ='step_aic_r'):
    import subprocess
    import tempfile
    import os
    #step_aic_r, dredge_test, glmnet_poisson
    r_exe = r"C:\Users\ahernz\AppData\Local\Programs\R\R-4.4.1\bin\x64\Rscript.exe"
    r_script = os.path.abspath(f"{r_path}.R")

    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f_train, \
         tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f_test, \
         tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f_out:

        df_train.to_csv(f_train.name, index=False)
        df_test.to_csv(f_test.name, index=False)
        vars_string = ",".join(vars)
        cmd = [
            r_exe,
            r_script,
            f_train.name,
            f_test.name,
            f_out.name,
            vars_string,
            "OFFSET"  
        ]

        print("Running:", cmd)  # optional debug

        subprocess.run(cmd, check=True)

        result = pd.read_csv(f_out.name)
    return result['bic'].iloc[0], result['rmse'].iloc[0]
    return result["train_bic"].iloc[0], result["test_rmse"].iloc[0]

def get_best_index(scores):
    if scores.ndim == 1:
        return np.argmin(scores)
    return np.argmin(scores[:, 0])



def experiment_washington():
    _data_path = _resource_files('metacountregressor') / 'data' / 'Ex-16-3.csv'
    df = pd.read_csv(str(_data_path))
    print("Unique IDs:", df["ID"].nunique())
    print("Total rows:", len(df))
    df['EXPOSE'] = df['LENGTH']*df['AADT']*365/100000000
    df['OFFSET'] = 0
    df.rename(columns={"FREQ": "Y"}, inplace=True)
    all_variables = [
    "INCLANES",
    "DECLANES",
    "WIDTH",
    "SPEED",
    "URB",
    "FC",
    "SINGLE",
    "DOUBLE",
    "TRAIN",
    "PEAKHR",
    "GRADEBR",
    "TANGENT",
    "CURVES",
    "MINRAD",
    "ACCESS",
    "MEDWIDTH",
    "SLOPE",
    "INTECHAG",
    "AVEPRE",
    "AVESNOW",
    "LOWPRE",
    "GBRPM",
    "EXPOSE",
    "INTPM",
    "CPM",
    "HISNOW",
    "FRICTION"
    ]
    
    
    
    

    allowed_distributions = populate_allowed_distributions(
        all_variables, None
      
    )
    #  {"CURVES": ["normal", "lognormal"],
       #  "FRICTION": ["normal", "triangular"]}
    allowed_roles = populate_allowed_roles(all_variables, {"EXPOSE": [1]},
                                                           default_roles=[0,1,2,3,5])

    evaluator = StructureEvaluator(
        df=df,
        id_col="ID",
        y_col="Y",
        offset_col='OFFSET',
        all_variables=all_variables,
        allowed_roles=allowed_roles,
        allowed_distributions=allowed_distributions,
        group_id_col="FC",
        mode="single",
        R=200
    )
    return evaluator, df, all_variables

def experiment_synthetic(seed = 0):
    N_ids = 1000
    T = 4 
    r= seed
    df, true_params = generate_panel_data(
            N_ids=N_ids,
            T=T,
            seed=r
        )
    all_var = df.columns.to_list()
    all_variables = [col for col in all_var if col not in ['ID', 'Y']]
    allowed_distributions = populate_allowed_distributions(
        all_variables, None
    )

    allowed_roles = populate_allowed_roles(all_variables, dict(), default_roles=[0,1,2,3,5])
    evaluator = StructureEvaluator(
        df=df,
        id_col="ID",
        y_col="Y",
        offset_col=None,
        all_variables=all_variables,
        allowed_roles=allowed_roles,
        allowed_distributions=allowed_distributions,
        group_id_col=None,
        mode="multi",
        R=200
    )
    return evaluator, df, all_variables
    

def strip_distribution(spec_dict):

    def strip(terms):
        return sorted([t.split(":")[0] for t in terms])

    return {
        "fixed_terms": sorted(spec_dict["fixed_terms"]),
        "rdm_terms": strip(spec_dict["rdm_terms"]),
        "rdm_cor_terms": strip(spec_dict["rdm_cor_terms"]),
        "grouped_terms": strip(spec_dict["grouped_terms"]),
        "hetro_in_means": sorted(spec_dict["hetro_in_means"]),
        "zi_terms": sorted(spec_dict["zi_terms"]),
        "dispersion": spec_dict["dispersion"]
    }


def main(seed, algo, config, max_iter, n_jobs, config_id, experiment):
    #monte_carlo_recovery()
    start_time = time.time()

    print("\n==============================")
    print("Running experiment:")
    print("Algo:", algo)
    print("Seed:", seed)
    print("Config ID:", config_id)
    print("Config:", config)
    print("Experiment:", experiment)
    print("==============================\n")

    # ------------------------------------------------
    # Build evaluator
    # ------------------------------------------------
    if experiment == "ex_wash":
        evaluator, df, all_variables = experiment_washington()

    elif experiment == "ex_synth":
        evaluator, df, all_variables = experiment_synthetic(seed=seed)

    else:
        raise ValueError("Unknown experiment")

    # ==========================================================
    # 🔵 MULTI-OBJECTIVE (NSGA2)
    # ==========================================================
    if algo in ["de", "hs"]:

        if algo == "de":
            operator = AdaptiveDE(
                F=config["F"],
                CR=config["CR"]
            )

        elif algo == "hs":
            operator = DynamicHarmony(
                hmcr=config["hmcr"],
                par_min=config["par_min"],
                par_max=config["par_max"],
                bw_min=config["bw_min"],
                bw_max=config["bw_max"]
            )

        result = run_nsga(
            evaluator=evaluator,
            operator=operator,
            seed=seed,
            pop_size=config["population_size"],
            max_iter=max_iter,
            n_jobs=n_jobs
        )
        print_from_nsga_result(result, evaluator)
        if evaluator.mode == "multi":
            solutions = np.array(result["solutions"])
            scores = np.array(result["scores"])

            # Recompute Pareto just to be safe
            pareto_solutions, pareto_scores = extract_pareto_front(
                solutions,
                scores
            )

            print("\n================ NSGA FINAL PARETO FRONT ================\n")

            for i in range(len(pareto_solutions)):
                print(
                    f"{i} | BIC={pareto_scores[i][0]:.4f} "
                    f"| RMSE={pareto_scores[i][1]:.4f}"
                )

            save_pareto_front(
                pareto_solutions,
                pareto_scores,
                evaluator,
                algo,
                seed,
                config_id
            )

            result = {
                "algorithm": algo,
                "seed": seed,
                "solutions": pareto_solutions,
                "scores": pareto_scores
            }
            # --------------------------------------------
            # ✅ TRUE STRUCTURE CHECK (only synthetic)
            # --------------------------------------------
            if experiment == "ex_synth":

                # define the TRUE synthetic structure
                true_spec_dict = {
                    "fixed_terms": ["shoulder", "log_aadt", "length", "rural"],
                    "rdm_terms": [],
                    "rdm_cor_terms": [
                        "speed:normal",
                        "lanes:normal"
                    ],
                    "grouped_terms": [],
                    "hetro_in_means": [],
                    "zi_terms": [],
                    "dispersion": 1
                }

                recovered, idx = check_structure_recovery(
                    pareto_solutions,
                    evaluator,
                    true_spec_dict
                )

                save_structure_recovery_file(
                    recovered,
                    algo,
                    seed,
                    config_id
                )

                if recovered:
                    print("\n✅ TRUE STRUCTURE FOUND IN PARETO FRONT")

                    true_decision = pareto_solutions[idx]

                    refit_and_save_true_model(
                        evaluator,
                        true_decision,
                        algo,
                        seed,
                        config_id
                    )

    # ==========================================================
    # 🔴 SINGLE OBJECTIVE (MultiStartSA)
    # ==========================================================
    elif algo in ["sa", "hc"]:

        solver = MultiStartSA(
            evaluator=evaluator,
            dimension=2 * len(evaluator.vars) + 1,
            **config
        )

        solutions, scores = solver.optimize()

        solutions = np.array(solutions)
        scores = np.array(scores)

        # --------------------------------------------
        # MULTI OBJECTIVE
        # --------------------------------------------
        if evaluator.mode == "multi":

            pareto_solutions, pareto_scores = extract_pareto_front(
                solutions,
                scores
            )

            print("\n================ SA FINAL PARETO FRONT ================\n")

            for i in range(len(pareto_solutions)):
                print(
                    f"{i} | BIC={pareto_scores[i][0]:.4f} "
                    f"| RMSE={pareto_scores[i][1]:.4f}"
                )

            save_pareto_front(
                pareto_solutions,
                pareto_scores,
                evaluator,
                algo,
                seed,
                config_id
            )

            result = {
                "algorithm": algo,
                "seed": seed,
                "solutions": pareto_solutions,
                "scores": pareto_scores
            }

        # --------------------------------------------
        # SINGLE OBJECTIVE
        # --------------------------------------------
        else:

            best_idx = np.argmin(scores)
            best_solution = solutions[best_idx]
            best_score = scores[best_idx]

            print("\n================ BEST SA STRUCTURE ================\n")
            decode_best_solution(best_solution, evaluator)
            print("Best Score:", best_score)

            refit_and_print(evaluator, best_solution)

            result = {
                "algorithm": algo,
                "seed": seed,
                "solutions": solutions,
                "scores": scores,
                "best_solution": best_solution,
                "best_score": best_score
            }

    else:
        raise ValueError("Unknown algorithm")

    # ------------------------------------------------
    # Save + log
    # ------------------------------------------------
    runtime = time.time() - start_time

    summary = summarize_experiment(
        result=result,
        config=config,
        runtime=runtime,
        config_id=config_id
    )

    append_experiment_to_csv(summary)

    return result



def main_old(seed, algo, pop_size, max_iter, n_jobs, config_id, experiment):
#def main(seed, algo, config, max_iter, n_jobs, config_id, experiment):
    
    start_time = time.time()
    print("Running experiment:")
    print("Algo:", algo)
    print("Config:", config_id)
    print("Seed:", seed)

    # ----------------------------
    # Generate grids
    # ----------------------------

    HS_GRID = {
        "population_size": [30, 40, 20],
        "hmcr": [0.75, 0.9, 0.98, 0.6],
        "par_min": [0.05, 0.1],
        "par_max": [0.5, 0.8],
        "bw_min": [1],
        "bw_max": [2, 3, 4, 5],
    }

    DE_GRID = {
        "population_size": [20, 30, 10],
        "F": [0.3, 0.5, 0.8],
        "CR": [0.5, 0.7, 0.9],
    }

    SA_GRID = {
        "max_iter": [max_iter],
        "mutation_rate": [0.1, 0.3, 0.6],
        "step_size": [1, 2, 3],
        "alpha": [0.99, 0.99, 0.9],
        "n_starts": [1, 2]
    }

    HC_GRID = {
        "mutation_rate": [0.5],
        "step_size": [1],
        "min_changes": [1],
        "max_changes": [1],
        "n_starts": [1]
    }

    ALL_CONFIGS = {
    "de": generate_configs(DE_GRID),
    "hs": generate_configs(HS_GRID),
    "sa": generate_configs(SA_GRID),
    "hc": generate_configs(HC_GRID)
    }

    
    # =====================================================
    # SELECT CONFIG
    # =====================================================
    if algo in ALL_CONFIGS:
        configs = ALL_CONFIGS[algo]

        if config_id >= len(configs):
            raise ValueError("config_id out of range")

        config = configs[config_id]
        print(f"\nUsing config {config_id}: {config}\n" )
    else:
        configs = None
    
    
    
    
    

 
    
    # ----------------------------
    # Build evaluator
    # ----------------------------
    if experiment == 'ex_wash':
        evaluator, df, all_variables = experiment_washington()
    elif experiment == 'ex_synth':
        evaluator, df, all_variables = experiment_synthetic()
    elif experiment == 'testing':
        monte_carlo_recovery()
        run_full_synthetic_recovery_experiment()
    '''
    df = pd.read_csv('./data/Ex-16-3.csv')
    print("Unique IDs:", df["ID"].nunique())
    print("Total rows:", len(df))
    df['EXPOSE'] = df['LENGTH']*df['AADT']*365/100000000
    df['OFFSET'] = 0
    df.rename(columns={"FREQ": "Y"}, inplace=True)
    all_variables = [
    "INCLANES",
    "DECLANES",
    "WIDTH",
    "SPEED",
    "URB",
    "FC",
    "SINGLE",
    "DOUBLE",
    "TRAIN",
    "PEAKHR",
    "GRADEBR",
    "TANGENT",
    "CURVES",
    "MINRAD",
    "ACCESS",
    "MEDWIDTH",
    "SLOPE",
    "INTECHAG",
    "AVEPRE",
    "AVESNOW",
    "LOWPRE",
    "GBRPM",
    "EXPOSE",
    "INTPM",
    "CPM",
    "HISNOW",
    "FRICTION"
    ]
    
    
    
    

    allowed_distributions = populate_allowed_distributions(
        all_variables,
        {"CURVES": ["normal", "lognormal"],
         "FRICTION": ["normal", "triangular"]}
    )

    allowed_roles = populate_allowed_roles(all_variables, {"EXPOSE": [1],
                                                           "CPM":[6], 'SPEED':[6]
                                                           })

    evaluator = StructureEvaluator(
        df=df,
        id_col="ID",
        y_col="Y",
        offset_col='OFFSET',
        all_variables=all_variables,
        allowed_roles=allowed_roles,
        allowed_distributions=allowed_distributions,
        group_id_col="FC",
        mode="single",
        R=1000
    )
    '''

    # ----------------------------
    # Select config
    # ----------------------------

    # =====================================================
    # ROUTING
    # =====================================================

    # ---------------------------
    # MULTI-OBJECTIVE (NSGA2)
    # ---------------------------
    if algo in ["de", "hs"]:

        if algo == "de":
            op_config = {k: v for k, v in config.items() if k != "population_size"}
            operator = AdaptiveDE(**op_config)

        elif algo == "hs":
            op_config = {k: v for k, v in config.items() if k != "population_size"}
            operator = DynamicHarmony(**op_config)

        result = run_nsga(
            evaluator=evaluator,
            operator=operator,
            seed=seed,
            pop_size=config['population_size'],
            max_iter=max_iter,
            n_jobs=n_jobs
        )

        print_from_nsga_result(result, evaluator)
        # pick best solution
        
        
        #return result

    # ---------------------------
    # SINGLE-OBJECTIVE (SA / HC)
    # ---------------------------
    elif algo in ["sa", 'hc']:

        solver = MultiStartSA(
            evaluator=evaluator,
            dimension=2 * len(evaluator.vars)+1,
            **config
        )
      
        all_solutions, all_scores= solver.optimize()
       
        best_idx = np.argmin(all_scores)
        best_solution = all_solutions[best_idx]
        best_score = all_scores[best_idx]

        print("\n================ BEST SA STRUCTURE ================\n")
        decode_best_solution(best_solution, evaluator)
        print("Best Score:", best_score)
        refit_and_print(evaluator, best_solution)

        save_run_summary_to_txt(
            evaluator=evaluator,
            decision=best_solution,
            algo=algo,
            seed=seed,
            config_id=config_id
        )

        runtime = time.time() - start_time

        summary = summarize_experiment(
            result={
                "solutions": all_solutions,
                "scores": all_scores,
                "algorithm": algo,
                'seed':seed
            },
            config=config,
            runtime=runtime,
            config_id=config_id
        )

        append_experiment_to_csv(summary)

        return {
            "algorithm": "SA",
            "seed": seed,
            "solutions": all_solutions,
            "scores": all_scores,
            "best_solution": best_solution,
            "best_score": best_score,
            "convergence": solver.results}
    elif algo == 'glmulti':
        df_train, df_test, df_val = build_datasets(df, "ID", "Y")

        train_bic, test_rmse = run_glmulti_experiment(df_train, df_test, all_variables)

        runtime = time.time() - start_time

        summary = {
            "algorithm": "glmulti",
            "seed": seed,
            "train_bic": float(train_bic),
            "test_rmse": float(test_rmse),
            "runtime_seconds": runtime
        }

        append_experiment_to_csv(summary)

        print("\n================ GLMULTI RESULTS ================\n")
        print("Train BIC:", train_bic)
        print("Test RMSE:", test_rmse)

        return summary
    if algo == "nlogit_replicate":
        run_nlogit_ex16_model(df, R=200)
        return
        

    # ----------------------------
    # Run NSGA
    # ----------------------------
    runtime = time.time() - start_time
    result = run_nsga(
        evaluator=evaluator,
        operator=operator,
        seed=seed,
        pop_size=pop_size,
        max_iter=max_iter,
        n_jobs=n_jobs
    )

    print_from_nsga_result(result, evaluator)
    runtime = time.time() - start_time
    
    summary = summarize_experiment(
    result=result,
    config=config,
    runtime=runtime,
    config_id=config_id
    )

    append_experiment_to_csv(summary)

    save_experiment(result, config)
    
    return result


def benchmarks(seed = 0, case = 1):
    
    start_time = time.time()
    evaluator, df, all_variables = experiment_washington()
    df_train, df_test, df_val = build_datasets(df, "ID", "Y")
    if case == 0:
        train_bic, test_rmse = run_glmulti_experiment(df, df_test, all_variables)
    else:
        
        ## STEP AIC
        train_bic, test_rmse = run_r_experiment(df, df_test, all_variables)
    
        runtime = time.time() - start_time

        summary = {
                "algorithm": "step_aic",
                "seed": seed,
                "train_bic": float(train_bic),
                "test_rmse": float(test_rmse),
                "runtime_seconds": runtime
            }

        append_experiment_to_csv(summary)
        print("\n================ step bic ================\n")
        print("BIC:", train_bic)
        ###  DREDDGE
        train_bic, test_rmse = run_r_experiment(df, df_test, all_variables, 'glmnet_poisson')
    
        runtime = time.time() - start_time

        summary = {
                "algorithm": "step_aic",
                "seed": seed,
                "train_bic": float(train_bic),
                "test_rmse": float(test_rmse),
                "runtime_seconds": runtime
            }

        append_experiment_to_csv(summary)

        print("\n================ s DREDDGE ================\n")
        print("BIC:", train_bic)
        
        
        ###  glmnet
        train_bic, test_rmse = run_glmulti_experiment(df, df_test, all_variables)
        #train_bic, test_rmse = run_r_experiment(df, df_test, all_variables, 'dlmnet_poisson')
    
        runtime = time.time() - start_time

        summary = {
                "algorithm": "step_aic",
                "seed": seed,
                "train_bic": float(train_bic),
                "test_rmse": float(test_rmse),
                "runtime_seconds": runtime
            }

        append_experiment_to_csv(summary)

        print("\n================ s DREDDGE ================\n")
        print("BIC:", train_bic)
        

    

def run_nlogit_ex16_model(df, R=800, seed=42):
    """
    Reproduces the NLOGIT Ex16-2 random-parameter NB model:

    Fixed:
        LOWPRE, GBRPM, FRICTION

    Random (independent normal):
        EXPOSE, INTPM, CPM, HISNOW

    Negative binomial
    200 Halton draws
    """

    print("\n================ RUNNING NLOGIT EQUIVALENT MODEL ================\n")

    # ----------------------------------------------------
    # 1️⃣ Define manual spec exactly matching NLOGIT
    # ----------------------------------------------------

    manual_spec = {
        "fixed_terms": [
            "LOWPRE",
            "GBRPM",
             "HISNOW",
            "FRICTION",
        ],
        "rdm_terms": [
            "EXPOSE:normal",
            "INTPM:normal",
            "CPM:normal",
        ],
        "rdm_cor_terms": [],
        "grouped_terms": [],
        "hetro_in_means": [],
        "zi_terms": [],
        "dispersion": 1  # Negative Binomial
    }

    # ----------------------------------------------------
    # 2️⃣ Generate Halton draws
    # ----------------------------------------------------

    N = df["ID"].nunique()
    K_random = 3

    draws_ind = generate_halton_normal(
        N=N,
        K=K_random,
        R=R,
        seed=seed
    )

    # ----------------------------------------------------
    # 3️⃣ Build JAX data + spec
    # ----------------------------------------------------

    data, spec = build_model_from_manual_spec(
        df=df,
        manual_spec=manual_spec,
        id_col="ID",
        y_col="Y",           # already renamed in your main
        offset_col=None,     # EXPOSE is a regressor, not offset
        draws_ind=draws_ind,
        draws_cor=None,
        draws_g=None,
        R=R
    )

    # ----------------------------------------------------
    # 4️⃣ Fit model
    # ----------------------------------------------------

    model = CountModel(spec, data)
    result = model.fit()
    #solver_results = model.test_solvers(seed=seed)
    
    

# Pick best solver automatically
    #best_solver = min(solver_results, key=lambda k: solver_results[k]["loglike"])

    #print(f"\n✅ Best solver: {best_solver}")
    #print(f"Best LogLik: {solver_results[best_solver]['loglike']:.6f}")
    #result = model.fit()

    #print("\n✅ Model estimation complete.")

    # ----------------------------------------------------
    # 5️⃣ Print full summary
    # ----------------------------------------------------

    objective = partial(mixed_model_loglik, data=data, spec=spec)
    param_index = build_param_index(spec)

    print_summary(
        result=result,
        objective=objective,
        data=data,
        spec=spec,
        param_index=param_index
    )

    # ----------------------------------------------------
    # 6️⃣ Return everything
    # ----------------------------------------------------

    return result, spec, data


def save_run_summary_to_txt(evaluator, decision, algo, seed, config_id, folder="results"):

    os.makedirs(folder, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    filename = f"{algo}_seed{seed}_config{config_id}_{timestamp}.txt"
    filepath = os.path.join(folder, filename)

    with open(filepath, "w", encoding="utf-8") as f:
        with redirect_stdout(f):

            print("======================================================")
            print("EXPERIMENT SUMMARY")
            print("======================================================")
            print("Algorithm:", algo)
            print("Seed:", seed)
            print("Config ID:", config_id)
            print("Timestamp:", timestamp)
            print("======================================================\n")

            # Print structure
            decode_best_solution(decision, evaluator)

            # Refit and print full model summary
            refit_and_print(evaluator, decision)

    print(f"✅ Summary saved to {filepath}")

def save_experiment(result, config, folder="results"):

    os.makedirs(folder, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    algo = result["algorithm"]
    seed = result["seed"]

    base_name = f"{algo}_seed{seed}_{timestamp}"

    # ✅ Save full result (pickle)
    with open(os.path.join(folder, base_name + ".pkl"), "wb") as f:
        pickle.dump(result, f)

    # ✅ Save config (json)
    with open(os.path.join(folder, base_name + "_config.json"), "w") as f:
        json.dump(config, f, indent=4)

    print(f"\n✅ Saved experiment to {folder}/{base_name}")


def log_nsga_result(result, filename):

    log_data = {
        "timestamp": datetime.now().isoformat(),
        "algorithm": result["algorithm"],
        "seed": result["seed"],
        "num_solutions": len(result["solutions"]),
        "scores": np.array(result["scores"]).tolist(),
        "solutions": np.array(result["solutions"]).tolist()
    }

    with open(filename, "w") as f:
        json.dump(log_data, f, indent=4)

    print(f"\n✅ NSGA results logged to {filename}")


def fit_simple_poisson_full(data, spec):
    """
    Prefit Poisson treating ALL regressors
    (fixed + random + grouped) as fixed.
    """

    blocks = []

    if spec.Kf > 0:
        blocks.append(data["Xf"])

    if spec.Kr_cor > 0:
        blocks.append(data["Xr_cor"])

    if spec.Kr_ind > 0:
        blocks.append(data["Xr_ind"])

    if spec.Kg > 0:
        blocks.append(data["Xg"])

    if len(blocks) == 0:
        return None

    X_all = jnp.concatenate(blocks, axis=2)

    y = data["y"]
    mask = data["mask"]

    K_total = X_all.shape[2]

    # Flatten
    X_flat = X_all.reshape(-1, K_total)
    y_flat = y.reshape(-1)
    mask_flat = mask.reshape(-1)

    valid = mask_flat == 1
    X_flat = X_flat[valid]
    y_flat = y_flat[valid]

    def poisson_objective(beta):
        eta = X_flat @ beta
        mu = jnp.exp(jnp.clip(eta, -15, 15))
        ll = y_flat * jnp.log(mu + 1e-12) - mu - jsp.special.gammaln(y_flat + 1)
        return -jnp.sum(ll)

    init = jnp.zeros(K_total)

    solver = LBFGS(fun=poisson_objective, maxiter=500)
    result = solver.run(init)

    return result.params

def fit_simple_poisson(data, spec):
    """
    Prefit Poisson using only fixed effects (Xf).
    Does NOT rebuild spec.
    """

    Xf = data["Xf"]            # (N, P, Kf)
    y = data["y"]              # (N, P, 1)
    mask = data["mask"]        # (N, P)

    Kf = spec.Kf

    # Flatten panel
    Xf_flat = Xf.reshape(-1, Kf)
    y_flat = y.reshape(-1)
    mask_flat = mask.reshape(-1)

    valid = mask_flat == 1
    Xf_flat = Xf_flat[valid]
    y_flat = y_flat[valid]

    def poisson_objective(beta):
        eta = Xf_flat @ beta
        mu = jnp.exp(jnp.clip(eta, -15, 15))
        ll = y_flat * jnp.log(mu + 1e-12) - mu - jsp.special.gammaln(y_flat + 1)
        return -jnp.sum(ll)

    init = jnp.zeros(Kf)

    solver = LBFGS(fun=poisson_objective, maxiter=500)
    result = solver.run(init)

    return result.params


def build_master_grid(seeds):

    HS_GRID = {
        "population_size": [30, 40, 20],
        "hmcr": [0.75, 0.9, 0.98, 0.6],
        "par_min": [0.05, 0.1],
        "par_max": [0.5, 0.8],
        "bw_min": [1],
        "bw_max": [2, 3, 4, 5],
    }

    DE_GRID = {
        "population_size": [20, 30, 10],
        "F": [0.3, 0.5, 0.8],
        "CR": [0.5, 0.7, 0.9],
    }

    SA_GRID = {
        "max_iter": [7000],
        "mutation_rate": [0.5, 0.3, 0.6],
        "step_size": [5, 2, 3],
        "alpha": [0.99, 0.9],
        "n_starts": [1, 2]
    }

    HC_GRID = {
        "mutation_rate": [0.5],
        "step_size": [1],
        "min_changes": [1],
        "max_changes": [1],
        "n_starts": [1]
    }

    ALL_GRIDS = {
        "sa": SA_GRID,
        "de": DE_GRID,
        "hs": HS_GRID,
        "hc": HC_GRID
    }

    experiments = ["ex_wash", "ex_synth"]

    master = []

    for exp in experiments:
        for algo, grid in ALL_GRIDS.items():
            configs = generate_configs(grid)
            for config_id, config in enumerate(configs):
                for seed in seeds:
                    master.append({
                        "experiment": exp,
                        "algorithm": algo,
                        "config_id": config_id,
                        "config": config,
                        "seed": seed
                    })

    return master


def e_step(params, data, spec):

    C = spec.latent_classes
    base_spec = replace(spec, latent_classes=1)

    base_index = build_base_index(base_spec)
    K = base_index["total_params"]

    params = np.asarray(params)

    theta_all = params[:C*K].reshape(C, K)

    logits = params[C*K:]
    logits_full = np.concatenate(([0.0], logits))
    pi = np.exp(logits_full - np.max(logits_full))
    pi /= pi.sum()

    N = data["N_ids"]

    logL = np.zeros((N, C))

    for c in range(C):

        logL[:, c] = mixed_model_loglik_individual(
            theta_all[c],
            data,
            base_spec
        )

    # log posterior numerator
    log_num = logL + np.log(pi)

    # stabilize
    max_log = log_num.max(axis=1, keepdims=True)
    w = np.exp(log_num - max_log)
    w /= w.sum(axis=1, keepdims=True)

    return w, pi

def weighted_objective(theta, data, spec, weights):

    logL_i = mixed_model_loglik_individual(theta, data, spec)

    return -np.sum(weights * logL_i)

import numpy as np
from scipy.optimize import minimize
import jax
import jax.numpy as jnp
import jax.scipy as jsp
from dataclasses import replace


def fit_em(init_params, data, spec, max_iter=100, tol=1e-6, verbose=True):

    assert spec.latent_classes > 1, "EM only needed for latent classes"

    C = spec.latent_classes
    base_spec = replace(spec, latent_classes=1)

    # Build param index once
    base_index = build_param_index(base_spec)
    K_base = base_index["total_params"]

    params = np.array(init_params)
    test_ll = _call_loglik(
    params[:K_base],
    data,
    base_spec,
    indivi=True
    )
    
    N = test_ll.shape[0]

    for iteration in range(max_iter):

        params_old = params.copy()

        # ==========================================================
        # E-STEP
        # ==========================================================

        theta_all = params[:C * K_base].reshape(C, K_base)
        logits = params[C * K_base:]

        logits_full = np.concatenate(([0.0], logits))
        pi = np.exp(logits_full - np.max(logits_full))
        pi /= pi.sum()

        logL = np.zeros((N, C))

        for c in range(C):

            ll_ind = _call_loglik(
                theta_all[c],
                data,
                base_spec,
                indivi=True
            )

            logL[:, c] = np.array(ll_ind)
        #todo bug here, in FIT_EM
        log_num = logL + np.log(pi)

        # stabilize
        max_log = log_num.max(axis=1, keepdims=True)
        w = np.exp(log_num - max_log)
        w /= w.sum(axis=1, keepdims=True)

        # ==========================================================
        # M-STEP
        # ==========================================================

        # ✅ Update class probabilities
        pi_new = w.mean(axis=0)

        logits_new = np.log(pi_new[1:] / pi_new[0])

        # ✅ Update class-specific parameters
        theta_new = []

        for c in range(C):

            weights_c = w[:, c]

            def weighted_objective(theta_c):

                ll_ind = _call_loglik(
                    theta_c,
                    data,
                    base_spec,
                    indivi=True
                )

                return -np.sum(weights_c * np.array(ll_ind))

            result = minimize(
                weighted_objective,
                theta_all[c],
                method="SLSQP"
            )

            theta_new.append(result.x)

        theta_new = np.concatenate(theta_new)

        params = np.concatenate([theta_new, logits_new])

        # ==========================================================
        # Convergence Check
        # ==========================================================

        diff = np.max(np.abs(params - params_old))

        if verbose:
            total_ll = _call_loglik(params, data, spec)
            print(f"EM iter {iteration:3d} | max Δ = {diff:.3e} | LL = {-total_ll:.6f}")

        if diff < tol:
            if verbose:
                print(f"\n✅ EM converged in {iteration} iterations\n")
            break

    return params

def evaluate_true_spec_synthetic(
    N_ids=1000,
    T=4,
    R=200,
    seed=0
):
    """
    1) Generate synthetic data from true DGP
    2) Perform panel-level train/test split
    3) Estimate TRUE model specification on train
    4) Compute:
        - Train BIC
        - Test RMSE
    """

    from functools import partial
    from dataclasses import replace
    import numpy as np

    print("\n===================================================")
    print(" TRUE SPEC EVALUATION (SYNTHETIC DATA)")
    print("===================================================\n")

    # ==========================================================
    # 1️⃣ Generate synthetic panel data
    # ==========================================================

    df, true_params = generate_panel_data(
        N_ids=N_ids,
        T=T,
        seed=seed
    )

    print("Generated data shape:", df.shape)
    print("Unique individuals:", df["ID"].nunique())

    # ==========================================================
    # 2️⃣ Panel train/test split (stratified)
    # ==========================================================

    df_train, df_test, df_val = build_datasets(
        df,
        id_col="ID",
        y_col="Y"
    )

    print("\nSplit sizes:")
    print("Train IDs:", df_train["ID"].nunique())
    print("Test IDs :", df_test["ID"].nunique())
    print("Val IDs  :", df_val["ID"].nunique())

    # ==========================================================
    # 3️⃣ TRUE SPECIFICATION
    # ==========================================================

    manual_spec = {
        "fixed_terms": [
            "shoulder",
            "log_aadt",
            "length",
            "rural"
        ],
        "rdm_terms": [],
        "rdm_cor_terms": [
            "speed:normal",
            "lanes:normal"
        ],
        "grouped_terms": [],
        "hetro_in_means": [],
        "zi_terms": [],
        "dispersion": 1
    }

    # ==========================================================
    # 4️⃣ Generate Halton draws
    # ==========================================================

    N_train = df_train["ID"].nunique()
    N_test  = df_test["ID"].nunique()

    draws_train = generate_halton_normal(
        N=N_train,
        K=2,
        R=R,
        seed=seed
    )

    draws_test = generate_halton_normal(
        N=N_test,
        K=2,
        R=R,
        seed=seed
    )

    # ==========================================================
    # 5️⃣ Build training model
    # ==========================================================

    data_train, spec = build_model_from_manual_spec(
        df=df_train,
        manual_spec=manual_spec,
        id_col="ID",
        y_col="Y",
        draws_cor=draws_train,
        R=R
    )

    spec = replace(spec, model="nb")

    model = CountModel(spec, data_train)

    print("\nEstimating TRUE model on training data...\n")

    result = model.fit()
    param_index = build_param_index(spec)
    
   
    # ==========================================================
    # 6️⃣ Compute Train BIC
    # ==========================================================

    objective = partial(mixed_model_loglik, data=data_train, spec=spec)
    print_summary(
    result=result,
    objective=objective,
    data=data_train,
    spec=spec,
    param_index=param_index
    )  
    
    
    train_ll = -objective(result.params)
    k = len(result.params)
    n_train = data_train["y"].shape[0]

    train_bic = float(k * np.log(n_train) - 2 * train_ll)

    print("Train LogLik:", float(train_ll))
    print("Train BIC:", train_bic)

    # ==========================================================
    # 7️⃣ Test Evaluation
    # ==========================================================

    data_test, _ = build_model_from_manual_spec(
        df=df_test,
        manual_spec=manual_spec,
        id_col="ID",
        y_col="Y",
        draws_cor=draws_test,
        R=R
    )
     

    model_test = CountModel(spec, data_test)
    model_test.params = result.params

    preds = model_test.predict()
    y_true = np.array(data_test["y"]).squeeze()

    test_rmse = float(np.sqrt(np.mean((preds - y_true)**2)))

    print("Test RMSE:", test_rmse)

    print("\n===================================================")
    print(" FINAL RESULTS")
    print("===================================================")
    print("Train BIC :", train_bic)
    print("Test RMSE :", test_rmse)
    print("===================================================\n")
    print("\n===================================================")
    print(" FINAL RESULTS")
    print("===================================================")
    print("Train BIC :", train_bic)
    print("Test RMSE :", test_rmse)
    print("===================================================\n")

    # ==========================================================
    # 9️⃣ Print TRUE parameter values for comparison
    # ==========================================================

    print("\n================ TRUE PARAMETERS ================\n")
    for k, v in true_params.items():
        print(f"{k:20s}: {v}")

    print("\n=================================================\n")
    
    
    return {
        "train_bic": train_bic,
        "test_rmse": test_rmse,
        "train_loglik": float(train_ll)
    }


def run_lognormal_duration_full_demo(
    N_ids=800,
    T=3,
    R=200,
    seed=0
):
    """
    FULLY INTEGRATED PIPELINE

    1) Generate synthetic duration panel data
    2) Build mixed lognormal model
    3) Estimate model
    4) Compute predictions
    5) Print fit statistics
    6) Plot Actual vs Predicted
    """

    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import jax
    import jax.numpy as jnp
    from functools import partial
    from dataclasses import replace

    np.random.seed(seed)

    print("\n===================================================")
    print("   MIXED LOGNORMAL DURATION MODEL - FULL DEMO")
    print("===================================================\n")

    # ==========================================================
    # 1️⃣ DATA GENERATION
    # ==========================================================

    def generate_data():

        beta_0 = 1.0
        beta_income = 0.03
        beta_distance = -0.15

        mu_speed = 0.02
        sd_speed = 0.05

        sigma_true = 0.4

        rows = []

        for i in range(N_ids):

            beta_speed_i = np.random.normal(mu_speed, sd_speed)

            income = np.random.normal(50, 10)
            distance = np.random.uniform(1, 20)

            for t in range(T):

                speed = np.random.uniform(30, 80)

                eta = (
                    beta_0
                    + beta_income * income
                    + beta_distance * distance
                    + beta_speed_i * speed
                )

                duration = np.exp(
                    np.random.normal(eta, sigma_true)
                )

                rows.append([
                    i,
                    duration,
                    income,
                    distance,
                    speed
                ])

        df = pd.DataFrame(rows, columns=[
            "ID",
            "DURATION",
            "income",
            "distance",
            "speed"
        ])

        true_params = {
            "Intercept": beta_0,
            "Income": beta_income,
            "Distance": beta_distance,
            "Mean Speed": mu_speed,
            "SD Speed": sd_speed,
            "Sigma": sigma_true
        }

        return df, true_params

    df, true_params = generate_data()

    print("Generated data shape:", df.shape)

    # ==========================================================
    # 2️⃣ MODEL SPECIFICATION
    # ==========================================================

    manual_spec = {
        "fixed_terms": ["income", "distance"],
        "rdm_terms": ["speed:normal"],
        "rdm_cor_terms": [],
        "grouped_terms": [],
        "hetro_in_means": [],
        "zi_terms": [],
        "dispersion": 0
    }

    draws_ind = generate_halton_normal(
        N=N_ids,
        K=1,
        R=R,
        seed=seed
    )

    data, spec = build_model_from_manual_spec(
        df=df,
        manual_spec=manual_spec,
        id_col="ID",
        y_col="DURATION",
        draws_ind=draws_ind,
        R=R
    )

    spec = replace(spec, model="lognormal")

    # ==========================================================
    # 3️⃣ ESTIMATE MODEL
    # ==========================================================

    model = CountModel(spec, data)
    result = model.fit()

    objective = partial(mixed_model_loglik, data=data, spec=spec)
    param_index = build_param_index(spec)

    print_summary(
        result=result,
        objective=objective,
        data=data,
        spec=spec,
        param_index=param_index
    )

    # ==========================================================
    # 4️⃣ PREDICTION FUNCTION
    # ==========================================================

    def compute_predictions(result, data, spec):

        params = result.params
        blocks = unpack_params(params, spec)

        beta = blocks["beta_f"]

        eta = data["Xf"] @ beta

        # Add mean random component
        if blocks["mean_ind"] is not None:
            eta += data["Xr_ind"] @ blocks["mean_ind"]

        if blocks.get("mean_cor") is not None and data.get("Xr_cor") is not None:
            eta += data["Xr_cor"] @ blocks["ean_cor"]
        
        sigma = jax.nn.softplus(blocks["sigma"])

        # ✅ Proper mean of lognormal
        pred_mean = jnp.exp(eta + 0.5 * sigma**2)

        return np.array(pred_mean)

    # ==========================================================
    # 5️⃣ EVALUATION
    # ==========================================================

    y_actual = np.array(data["y"])
    y_pred = compute_predictions(result, data, spec)[:,:, None]

    rmse = np.sqrt(np.mean((y_actual - y_pred)**2))
    mae = np.mean(np.abs(y_actual - y_pred))
    corr = np.corrcoef(y_actual, y_pred)[0, 1]

    print("\n================ MODEL FIT =================\n")
    print(f"RMSE : {rmse:.4f}")
    print(f"MAE  : {mae:.4f}")
    print(f"Corr : {corr:.4f}")

    comparison_df = pd.DataFrame({
        "Actual": y_actual[:10],
        "Predicted": y_pred[:10]
    })

    print("\nFirst 10 Observations:")
    print(comparison_df)

    # ==========================================================
    # 6️⃣ PLOT
    # ==========================================================

    plt.figure(figsize=(6,6))
    plt.scatter(y_actual, y_pred, alpha=0.4)

    min_val = min(y_actual.min(), y_pred.min())
    max_val = max(y_actual.max(), y_pred.max())

    plt.plot([min_val, max_val],
             [min_val, max_val],
             'r--')

    plt.xlabel("Actual Duration")
    plt.ylabel("Predicted Duration")
    plt.title("Actual vs Predicted (Mixed Lognormal)")
    plt.tight_layout()
    plt.show()
    plt.close()

    # ==========================================================
    # 7️⃣ TRUE PARAMS PRINT
    # ==========================================================

    print("\n================ TRUE PARAMETERS ================\n")
    for k, v in true_params.items():
        print(f"{k:15s}: {v}")

    print("\n===================================================\n")

    return result, spec, data, y_pred




def run_lognormal_duration_demo(N_ids=800, T=3, R=200, seed=0):
    """
    FULL PIPELINE:
    1) Generate synthetic duration panel data
    2) Build mixed lognormal duration model
    3) Estimate
    4) Print results
    """

    import numpy as np
    import pandas as pd
    from functools import partial
    from dataclasses import replace

    np.random.seed(seed)

    print("\n==============================================")
    print("RUNNING LOGNORMAL DURATION MODEL DEMO")
    print("==============================================\n")

    # ==========================================================
    # TRUE PARAMETERS
    # ==========================================================

    beta_0 = 1.0
    beta_income = 0.03
    beta_distance = -0.15

    mu_speed = 0.02
    sd_speed = 0.05

    sigma_true = 0.4   # lognormal variance

    # ==========================================================
    # GENERATE PANEL DATA
    # ==========================================================

    rows = []

    for i in range(N_ids):

        # random coefficient per individual
        beta_speed_i = np.random.normal(mu_speed, sd_speed)

        income = np.random.normal(50, 10)
        distance = np.random.uniform(1, 20)

        for t in range(T):

            speed = np.random.uniform(30, 80)

            eta = (
                beta_0
                + beta_income * income
                + beta_distance * distance
                + beta_speed_i * speed
            )

            # lognormal duration
            duration = np.exp(
                np.random.normal(eta, sigma_true)
            )

            rows.append([
                i,
                duration,
                income,
                distance,
                speed
            ])

    df = pd.DataFrame(rows, columns=[
        "ID",
        "DURATION",
        "income",
        "distance",
        "speed"
    ])

    print("Generated data shape:", df.shape)

    # ==========================================================
    # MODEL SPECIFICATION
    # ==========================================================

    manual_spec = {
        "fixed_terms": ["income", "distance"],
        "rdm_terms": ["speed:normal"],
        "rdm_cor_terms": [],
        "grouped_terms": [],
        "hetro_in_means": [],
        "zi_terms": [],
        "dispersion": 0
    }

    # ==========================================================
    # HALTON DRAWS
    # ==========================================================

    draws_ind = generate_halton_normal(
        N=N_ids,
        K=1,
        R=R,
        seed=seed
    )

    # ==========================================================
    # BUILD MODEL
    # ==========================================================

    data, spec = build_model_from_manual_spec(
        df=df,
        manual_spec=manual_spec,
        id_col="ID",
        y_col="DURATION",
        draws_ind=draws_ind,
        R=R
    )

    # 🔥 IMPORTANT: Set model to lognormal
    spec = replace(spec, model="lognormal")

    # ==========================================================
    # FIT MODEL
    # ==========================================================

    model = CountModel(spec, data)
    result = model.fit()

    # ==========================================================
    # PRINT SUMMARY
    # ==========================================================

    objective = partial(mixed_model_loglik, data=data, spec=spec)
    param_index = build_param_index(spec)

    print_summary(
        result=result,
        objective=objective,
        data=data,
        spec=spec,
        param_index=param_index
    )

    # ==========================================================
    # PRINT TRUE VALUES
    # ==========================================================

    print("\n================ TRUE PARAMETERS ================\n")
    print("Intercept:", beta_0)
    print("Income:", beta_income)
    print("Distance:", beta_distance)
    print("Mean Speed (random):", mu_speed)
    print("SD Speed:", sd_speed)
    print("Sigma (lognormal):", sigma_true)

    print("\n==============================================\n")

    return result, spec, data

if __name__ == '__main__':
    estimate_latent_class_mixed_example()
    #evaluate_true_spec_synthetic()
    #run_lognormal_duration_full_demo()
    #benchmarks()
    parser = argparse.ArgumentParser()
    parser.add_argument("--job_index", type=int, default=0)
    args = parser.parse_args()

    SEEDS = [0]

    master_grid = build_master_grid(SEEDS)
    print("Total jobs:", len(master_grid))
    job = master_grid[args.job_index]

    print("\n================================================")
    print("Running job:", args.job_index)
    print(job)
    print("================================================\n")
    main(
    seed=job["seed"],
    algo=job["algorithm"],
    config=job["config"],
    max_iter=7000,
    n_jobs=8,
    config_id=job["config_id"],
    experiment=job["experiment"]
    
    )



'''
    main(
        seed=job["seed"],
        algo=job["algorithm"],
        pop_size=job["config"].get("population_size", 20),
        max_iter=6000,
        n_jobs=8,
        config_id=job["config_id"],
        experiment=job["experiment"])
        '''
    
    
    
'''

if __name__ == "__main__":
    #
  
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--config_id", type=int, default=8)
    parser.add_argument("--algo", type=str, default="hs") #glmulti, nlogit_replicate
    parser.add_argument("--pop_size", type=int, default=20)
    parser.add_argument("--max_iter", type=int, default=2000)
    parser.add_argument("--n_jobs", type=int, default=1)
    parser.add_argument("--experiment", type=str, default='ex_wash') #ex_wash ex_synth

    args = parser.parse_args()

    main(args.seed, args.algo, args.pop_size, args.max_iter,args.n_jobs, args.config_id, args.experiment)
    

    
    D = len(all_variables) * 2  # roles + dists

    engine = NSGA2Engine(
    evaluator=evaluator,
    operator=DynamicHarmony(),
    dimension=D,
    pop_size=30,
    max_iter=40,
    n_jobs=1
)

    solutions, scores = engine.optimize()
    engine.plot_convergence()
    engine.plot_pareto_front()
    engine.plot_pareto_evolution()

    engine.save_history("experiment1.pkl")
    #best_solution, best_score = hs.optimize()
    
'''
    
   











